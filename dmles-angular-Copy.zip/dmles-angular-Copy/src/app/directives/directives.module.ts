import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DmlesElementCheckerDirective} from './dmles-element-checker.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DmlesElementCheckerDirective],
  exports: [DmlesElementCheckerDirective]
})
export class DirectivesModule { }
