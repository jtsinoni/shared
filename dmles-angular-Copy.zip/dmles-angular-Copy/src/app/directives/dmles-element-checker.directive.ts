import {Directive, Input, TemplateRef, ViewContainerRef} from '@angular/core';
import {LoggerService} from '../services/logger/logger.service';
import {PermissionService} from '../services/permission.service';

@Directive({
  selector: '[dmlesElementChecker]'
})
export class DmlesElementCheckerDirective {

  constructor(
    private logger: LoggerService,
    private permissionService: PermissionService,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef) { }

  @Input() set dmlesElementChecker(elementName: string) {
    if (elementName){
      const canAccess: boolean = this.permissionService.checkElements(elementName);
      this.logger.warn('Hi canAccess: %s', canAccess);
      if (canAccess) {
        this.viewContainer.createEmbeddedView(this.templateRef);
      } else {
        this.viewContainer.clear();
      }
    }

  }

}
