import {TestBed, inject} from '@angular/core/testing';
import { DmlesElementCheckerDirective } from './dmles-element-checker.directive';
import {LoggerService} from '../services/logger/logger.service';
import {PermissionService} from '../services/permission.service';
import {TemplateRef, ViewContainerRef} from '@angular/core';
import {HttpTestModule} from '../common-components/test/http-test.module';

describe('DmlesElementCheckerDirective', () => {
  TestBed.configureTestingModule({
    imports: [HttpTestModule.forRoot()],
    providers: [LoggerService, PermissionService]
  });
  beforeEach(() => {
    let logger: LoggerService;
    let permissionService: PermissionService;
    let templateRef: TemplateRef<any> = null;
    let viewContainer: ViewContainerRef = null;

    it('should create an instance', () => {
    logger = TestBed.get(LoggerService);
    permissionService = TestBed.get(PermissionService);
    templateRef = TestBed.get(TemplateRef);
    viewContainer = TestBed.get(ViewContainerRef);

    const directive = new DmlesElementCheckerDirective(logger, permissionService, templateRef, viewContainer);
      this.viewContainer.createEmbeddedView(this.templateRef);
    expect(directive).toBeTruthy();
  });


});
});
