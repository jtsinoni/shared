import {Injector} from '@angular/core';

export let AppInjector: Injector;

// Use AppInjector to get instance of service without constructor injection, because in some cases we don't want to
// inject the service on all of the derivative components.
//
export function setAppInjector(injector: Injector) {
    if (AppInjector) {
        // Should not happen
        console.error('Programming error: AppInjector was already set');
    } else {
        AppInjector = injector;
    }
}
