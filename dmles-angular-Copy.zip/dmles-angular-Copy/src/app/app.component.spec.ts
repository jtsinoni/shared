import {TestBed, async} from '@angular/core/testing';
import {AppComponent} from './app.component';
import {RouterTestingModule} from '@angular/router/testing';
import {HeaderShellComponent} from './header-shell.component';
import {FooterShellComponent} from './footer-shell.component';
import {HomeFooterComponent} from './home/home-footer/home-footer.component';
import {HomeHeaderComponent} from './home/home-header/home-header.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {AppHeaderService} from './services/app-header.service';
import {LoggerService} from './services/logger/logger.service';
import {PipesModule} from './pipes/pipes.module';
import {UtilService} from './services/util.service';
import {CurrencyPipe} from '@angular/common';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, PipesModule],
      declarations: [
        AppComponent, HeaderShellComponent,
        FooterShellComponent, HomeFooterComponent,
        HomeHeaderComponent
      ],
      providers: [AppHeaderService, LoggerService, UtilService, CurrencyPipe],
      schemas: [NO_ERRORS_SCHEMA],
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
