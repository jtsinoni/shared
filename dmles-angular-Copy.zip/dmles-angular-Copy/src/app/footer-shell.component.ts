import {Component, OnInit} from '@angular/core';
import {AppHeaderService} from './services/app-header.service';

@Component({
  selector: 'app-footer-shell',
  template: `
    <ng-container *ngIf="appHeaderService.showFooter; then homeFooter"></ng-container>
    <ng-template #homeFooter>
    </ng-template>
  `
})
export class FooterShellComponent implements OnInit {
  // <!--<app-home-footer></app-home-footer>-->
  constructor(public appHeaderService: AppHeaderService) {
  }

  ngOnInit() {
  }

}
