import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmlesLoadingIconComponent } from './dmles-loading-icon.component';

describe('DmlesLoadingIconComponent', () => {
  let component: DmlesLoadingIconComponent;
  let fixture: ComponentFixture<DmlesLoadingIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmlesLoadingIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmlesLoadingIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
