import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dmles-loading-icon',
  templateUrl: './dmles-loading-icon.component.html',
  styleUrls: ['./dmles-loading-icon.component.scss']
})
export class DmlesLoadingIconComponent implements OnInit {

  public loadingMsg: String = 'Loading...';

  constructor() { }

  ngOnInit() {
  }

}
