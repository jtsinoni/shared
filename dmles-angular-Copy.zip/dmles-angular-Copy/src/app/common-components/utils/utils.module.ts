import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DmlesLoadingIconComponent } from './dmles-loading-icon.component';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    DmlesLoadingIconComponent
  ],
  exports: [
    DmlesLoadingIconComponent
  ]
})
export class UtilsModule { }
