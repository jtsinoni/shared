import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LcYesNoCellComponent } from './lc-yes-no-cell.component';

describe('LcYesNoCellComponent', () => {
  let component: LcYesNoCellComponent;
  let fixture: ComponentFixture<LcYesNoCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LcYesNoCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcYesNoCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
