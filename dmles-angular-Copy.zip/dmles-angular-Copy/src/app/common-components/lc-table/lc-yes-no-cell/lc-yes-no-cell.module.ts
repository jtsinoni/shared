import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcYesNoCellComponent } from './lc-yes-no-cell.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LcYesNoCellComponent]
})
export class LcYesNoCellModule { }
