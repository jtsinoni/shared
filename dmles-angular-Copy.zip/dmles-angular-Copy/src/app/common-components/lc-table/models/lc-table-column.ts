export class LcTableColumn {
  public title: string;
  public class: string;
  public width: string;
  public type: string;
  public filter: boolean = true;
  public editable: boolean;
  public sort: boolean = true;
  public addable: boolean;
  public sortDirection: string;  // 'asc', 'desc'
  public renderComponent: any;
  public onComponentInitFunction: any;

  constructor(title?: string) {
    this.title = title && title || '';
  }
}
