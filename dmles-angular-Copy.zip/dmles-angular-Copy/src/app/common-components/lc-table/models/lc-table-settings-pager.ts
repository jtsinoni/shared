export class LcTableSettingsPager {
  public display: boolean = true;
  public perPage: number = 10;
}
