export class LcTableSettingsEdit {
  public inputClass: string = '';
  public editButtonContent: string = 'Edit';
  public saveButtonContent: string = 'Update';
  public cancelButtonContent: string = 'Cancel';
  public confirmSave: boolean = false;
}
