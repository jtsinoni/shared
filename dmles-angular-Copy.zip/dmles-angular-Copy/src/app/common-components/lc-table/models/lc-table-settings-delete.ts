export class LcTableSettingsDelete {
  public deleteButtonContent: string = 'Delete';
  public confirmDelete: boolean = false;
}
