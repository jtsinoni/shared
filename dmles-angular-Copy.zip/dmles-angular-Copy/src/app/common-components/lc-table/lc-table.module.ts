import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LcTableComponent } from './lc-table.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { LcYesNoCellModule } from './lc-yes-no-cell/lc-yes-no-cell.module';
import { LcLinkCellModule } from './lc-link-cell/lc-link-cell.module';
import { LcDateCellModule } from './lc-date-cell/lc-date-cell.module';

@NgModule({
  imports: [
    CommonModule,
    Ng2SmartTableModule,
    LcYesNoCellModule,
    LcLinkCellModule,
    LcDateCellModule
  ],
  declarations: [LcTableComponent],
  exports : [LcTableComponent]
})
export class LcTableModule { }
