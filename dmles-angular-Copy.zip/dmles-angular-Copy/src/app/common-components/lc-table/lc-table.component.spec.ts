import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {CUSTOM_ELEMENTS_SCHEMA, EventEmitter} from '@angular/core';

import {LcTableComponent} from './lc-table.component';
import {LoggerService} from '../../services/logger/logger.service';
import {NotificationService} from '../../services/notification.service';
import {ToastrModule} from 'ngx-toastr';
import {LcTableSettings} from './models/lc-table-settings';
import {UtilService} from '../../services/util.service';
import {CurrencyPipe} from '@angular/common';

describe('LcTableComponent', () => {
  let component: LcTableComponent;
  let fixture: ComponentFixture<LcTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ToastrModule.forRoot()],
      declarations: [LcTableComponent],
      providers: [LoggerService, NotificationService, UtilService, CurrencyPipe],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LcTableComponent);
    component = fixture.componentInstance;
    component.lcTableColumns = {};
    component.lcTableSettings = new LcTableSettings();
    component.lcTableData = [];
    component.lcOnRefresh = new EventEmitter<string>();

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
