///<reference path="../../../node_modules/ngx-bootstrap/accordion/accordion.module.d.ts"/>
import {NgModule} from '@angular/core';
import {DmlesLabelValueComponent} from './formOther/dmles-label-value.component';
import {DmlesAdvancedFileUploadComponent} from './fileUpload/dmles-advanced-file-upload.component';
import {UtilsModule} from './utils/utils.module';
import {MainNavService} from '../home/main-nav/main-nav.service';
import {LoggerService} from '../services/logger/logger.service';
import {LoginService} from '../services/login.service';
import {MockComponent} from './test/mock.component';
import {BreadcrumbComponent} from './breadcrumb/breadcrumb.component';
import {RouterModule} from '@angular/router';
import {
  AccordionModule, AlertModule, BsDatepickerModule, BsDropdownModule, ButtonsModule,
  TypeaheadModule, CollapseModule, DatepickerModule, ModalModule, PaginationModule, PopoverModule, ProgressbarModule,
  RatingModule,
  SortableModule, TabsModule, TimepickerModule, TooltipModule, PaginationConfig
} from 'ngx-bootstrap';
import { LeftSidePanelComponent } from './panels/left-side-panel/left-side-panel.component';
import { RightSidePanelComponent } from './panels/right-side-panel/right-side-panel.component';
import {LcTableModule} from './lc-table/lc-table.module';
import {CommonModule} from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
    UtilsModule,
    RouterModule,
    LcTableModule,
    AccordionModule.forRoot(),
    AlertModule.forRoot(),
    ButtonsModule.forRoot(),
    BsDatepickerModule.forRoot(),
    BsDropdownModule.forRoot(),
    CollapseModule.forRoot(),
    DatepickerModule.forRoot(),
    ModalModule.forRoot(),
    PaginationModule.forRoot(),
    PopoverModule.forRoot(),
    ProgressbarModule.forRoot(),
    RatingModule.forRoot(),
    SortableModule.forRoot(),
    TabsModule.forRoot(),
    TimepickerModule.forRoot(),
    TooltipModule.forRoot(),
    TypeaheadModule.forRoot()
  ],
  declarations: [
    DmlesLabelValueComponent,
    DmlesAdvancedFileUploadComponent,
    MockComponent,
    BreadcrumbComponent,
    LeftSidePanelComponent,
    RightSidePanelComponent,
  ],
  // Since this is shared module we need to export modules or components (without forRoot())
  exports: [
    UtilsModule,
    BreadcrumbComponent,
    LeftSidePanelComponent,
    RightSidePanelComponent,
    BsDatepickerModule,
    LcTableModule
  ],
  providers: [
    MainNavService,
    LoggerService,
    LoginService,
    PaginationConfig
  ]
})
export class CommonComponentsModule {
}
