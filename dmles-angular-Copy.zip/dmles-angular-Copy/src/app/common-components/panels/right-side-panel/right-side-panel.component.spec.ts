import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {RightSidePanelComponent} from './right-side-panel.component';
import {SidePanelService} from '../../../services/side-panel.service';
import {LoggerService} from '../../../services/logger/logger.service';

describe('RightSidePanelComponent', () => {
  let component: RightSidePanelComponent;
  let fixture: ComponentFixture<RightSidePanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RightSidePanelComponent ],
      providers: [ LoggerService, SidePanelService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RightSidePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
