import { Component, OnInit, OnChanges, SimpleChanges, Input } from '@angular/core';
import { SidePanelService } from '../../../services/side-panel.service';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
  selector: 'right-side-panel',
  templateUrl: './right-side-panel.component.html'
})
export class RightSidePanelComponent implements OnInit, OnChanges {

  @Input('isOpen') public isOpen: boolean;
  @Input('panelWidth') public panelWidth: string;

  constructor(public sidePanelService: SidePanelService, private logger: LoggerService) { }

  public ngOnInit() {
    this.onParametersChanged();
  }

  public ngOnChanges(changes: SimpleChanges): void {
    this.onParametersChanged();
  }

  private onParametersChanged(): void {
    if (this.panelWidth) {
      this.sidePanelService.rightPanelWidthOpened = this.panelWidth;
    }

    if (this.isOpen) {
      this.sidePanelService.toggleRightPanel();
    }
  }
}
