import { Component, OnInit, OnChanges, Input, SimpleChanges } from '@angular/core';
import { SidePanelService } from '../../../services/side-panel.service';
import { LoggerService } from '../../../services/logger/logger.service';

@Component({
  selector: 'left-side-panel',
  templateUrl: './left-side-panel.component.html'
})
export class LeftSidePanelComponent implements OnInit, OnChanges {

  @Input('isOpen') public isOpen: boolean;
  @Input('panelWidth') public panelWidth: string;

  constructor(public sidePanelService: SidePanelService, private logger: LoggerService) { }

  public ngOnInit() {
    this.onParametersChanged();
  }

  public ngOnChanges(changes: SimpleChanges): void {
    this.onParametersChanged();
  }

  private onParametersChanged(): void {
    if (this.panelWidth) {
      this.sidePanelService.leftPanelWidthOpened = this.panelWidth;
    }

    if (this.isOpen) {
      this.sidePanelService.toggleLeftPanel();
    }
  }
}
