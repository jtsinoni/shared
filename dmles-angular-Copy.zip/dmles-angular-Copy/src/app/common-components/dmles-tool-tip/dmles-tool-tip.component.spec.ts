import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmlesToolTipComponent} from './dmles-tool-tip.component';
import {PopoverModule} from 'ngx-bootstrap';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';

describe('DmlesToolTipComponent', () => {
  let component: DmlesToolTipComponent;
  let fixture: ComponentFixture<DmlesToolTipComponent>;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmlesToolTipComponent ],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [PopoverModule.forRoot()],
      providers: [LoggerService]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmlesToolTipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it(`tip should be undefined`, async(() => {
    const dmlesToolTip = fixture.debugElement.componentInstance;
    expect(dmlesToolTip.tip).toBeUndefined();
  }));
  it(`delay should default to 500`, async(() => {
    const dmlesToolTip = fixture.debugElement.componentInstance;
    expect(dmlesToolTip.delay).toEqual('500');
  }));
  it(`position should default to bottom`, async(() => {
    const dmlesToolTip = fixture.debugElement.componentInstance;
    expect(dmlesToolTip.position).toEqual('bottom');
  }));

});
