import {Component, OnInit} from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';


@Component({
  selector: 'app-dmles-tool-tip',
  templateUrl: './dmles-tool-tip.component.html',
  styleUrls: ['./dmles-tool-tip.component.scss']
})
export class DmlesToolTipComponent implements OnInit {

  private componentName: string = 'DmlesToolTipComponent';

  public delay: string;
  public position: string;
  public tip: string;


  constructor(private logger: LoggerService) {
  }

  ngOnInit() {
    this.logger.debug('%s - Start', this.componentName);

    if (!this.delay) {
      this.delay = '500';
    }

    if (!this.position) {
      this.position = 'bottom';
    }

    this.logger.debug(this.componentName + ' - delay: %s', this.delay);
    this.logger.debug(this.componentName + ' - position: %s', this.position);
    this.logger.debug(this.componentName + ' - tip: %s', this.tip);

  }

}
