import {ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule, CurrencyPipe} from '@angular/common';
import {LoggerService} from '../../services/logger/logger.service';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {AuthenticationService} from '../../services/authentication.service';
import {StorageService} from '../../services/storage.service';
import {WindowService} from '../../services/window.service';
import {UtilService} from '../../services/util.service';
import {Base64Service} from '../../services/base64.service';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import {OAuthService} from '../../services/oauth.service';

@NgModule({
  imports: [
    CommonModule, HttpClientModule, HttpClientTestingModule
  ],
})
export class HttpTestModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: HttpTestModule,
      providers: [
        HttpClient,
        Base64Service,
        StorageService,
        UtilService,
        LoggerService,
        WindowService,
        AuthenticationService,
        CurrencyPipe,
        OAuthService
      ]
    };
  }

}
