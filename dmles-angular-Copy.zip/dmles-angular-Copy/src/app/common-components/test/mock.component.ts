import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mock',
  template: `
    <p>
      mock works!
    </p>
  `
})
export class MockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
