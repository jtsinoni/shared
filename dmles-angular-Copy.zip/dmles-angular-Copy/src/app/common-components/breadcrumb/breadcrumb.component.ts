import {Component, OnInit} from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';
import { ActivatedRoute, Router, NavigationEnd} from '@angular/router';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/distinctUntilChanged';

interface IBreadcrumb {
  label: string;
  // params: Params;
  url: string;
  route: string;
  parent: string;
}

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss'],
})
export class BreadcrumbComponent implements OnInit {

  private static readonly BREADCRUMB: string = 'breadcrumb';
  private static readonly ROUTE: string = 'route';
  private static readonly PARENT: string = 'parent';
  public breadcrumbs: Array<IBreadcrumb>;


  constructor(private logger: LoggerService,
              private router: Router,
              private activatedRoute: ActivatedRoute) {

    this.router.events
      .filter(event => event instanceof NavigationEnd)
      .distinctUntilChanged()
      .map(event => this.buildBreadcrumbs(this.activatedRoute.root)).subscribe((bc) => {
      this.breadcrumbs = bc;
    });

  }

  ngOnInit() {
  }

  buildBreadcrumbs(route: ActivatedRoute, url: string = '',
                  breadcrumbs: Array<IBreadcrumb> = []): Array<IBreadcrumb> {

        let newBreadcrumbs: Array<IBreadcrumb>;
        const label = route.snapshot.data[BreadcrumbComponent.BREADCRUMB];
        const path = route.snapshot.url;
        const parent = route.snapshot.data[BreadcrumbComponent.PARENT];
        const rt = route.snapshot.data[BreadcrumbComponent.ROUTE];
        const nextUrl = `${url}${path}/`;
        const breadcrumb = {
          label: label,
          url: nextUrl,
          // params: route.params,
          route: rt,
          parent: parent
        };

        this.logger.debug(`adding breadcrumb: ${breadcrumb.label}`);
        if (breadcrumb.label) {
          newBreadcrumbs = [...breadcrumbs, breadcrumb];
        } else {
          newBreadcrumbs = [...breadcrumbs];
        }
        if (route.firstChild
          && route.firstChild.snapshot
          && route.firstChild.snapshot.data) {
          return this.buildBreadcrumbs(route.firstChild, nextUrl, newBreadcrumbs);
        }
        return newBreadcrumbs;
  }


}
