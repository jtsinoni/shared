import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {BreadcrumbComponent} from './breadcrumb.component';
import {LoggerService} from '../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {LoginService} from '../../services/login.service';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {MockComponent} from '../test/mock.component';
import {CommonComponentsModule} from '../common-components.module';

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonComponentsModule, RouterTestingModule.withRoutes(
        [
          {path: 'security', component: MockComponent},
          {path: 'login', component: MockComponent, data: { breadcrumb: 'Login'}},
          {
            path: 'home', component: MockComponent,  data: { breadcrumb: 'Home'}, canActivate: [LoginService],
            children: [
              {path: 'about', component: MockComponent,  data: { breadcrumb: 'About'}},
              {path: 'help', component: MockComponent,  data: { breadcrumb: 'Help'}}]
          },
          {path: '', redirectTo: 'security', pathMatch: 'full'},
          {path: '**', component: MockComponent},
        ],
      )],
      declarations: [ ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [LoggerService, LoginService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(`breadcrumbs array should be undefined`, async(() => {
    const breadcrumbComponent = fixture.debugElement.componentInstance;
    expect(breadcrumbComponent.breadcrumbs).toBeUndefined();
  }));
});
