import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmlesAdvancedFileUploadComponent } from './dmles-advanced-file-upload.component';

describe('DmlesAdvancedFileUploadComponent', () => {
  let component: DmlesAdvancedFileUploadComponent;
  let fixture: ComponentFixture<DmlesAdvancedFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmlesAdvancedFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmlesAdvancedFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
