import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dmles-label-value',
  templateUrl: './dmles-label-value.component.html',
  styleUrls: ['./dmles-label-value.component.scss']
})
export class DmlesLabelValueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
