import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmlesLabelValueComponent } from './dmles-label-value.component';

describe('DmlesLabelValueComponent', () => {
  let component: DmlesLabelValueComponent;
  let fixture: ComponentFixture<DmlesLabelValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmlesLabelValueComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmlesLabelValueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
