import {BrowserModule} from '@angular/platform-browser';
import {NgModule, Injector} from '@angular/core';
import {CurrencyPipe} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {AppComponent} from './app.component';
import {AppConfig} from './app.config';
import {setAppInjector} from './app.injector';
import {AppRouterModule} from './app-router.module';
import {ServicesModule} from './services/services.module';
import {CommonComponentsModule} from './common-components/common-components.module';
import {PipesModule} from './pipes/pipes.module';
import {LoginModule} from './login/login.module';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import {DirectivesModule} from './directives/directives.module';
import * as $ from 'jquery';
import {NavigationService} from './services/navigation.service';

@NgModule({
  imports: [
    // CommonModule,  this should not be imported, since BrowserModule re exports CommonModule
    BrowserModule,
    BrowserAnimationsModule,
    NoopAnimationsModule,
    AppRouterModule,
    HttpClientModule,
    ServicesModule.forRoot(),
    FormsModule,
    CommonComponentsModule,
    PipesModule.forRoot(),
    DirectivesModule,
    LoginModule,
    ToastrModule.forRoot({
      closeButton: true,
      maxOpened: 5,
      preventDuplicates: true,
      progressAnimation: 'increasing',
      progressBar: true,
      timeOut: 10000
    })
  ],
  declarations: [
    AppComponent
  ],
  exports: [
    BrowserAnimationsModule,
    NoopAnimationsModule,
    ToastrModule,
    DirectivesModule],
  providers: [NavigationService],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(injector: Injector) {
    setAppInjector(injector);
  }
}
