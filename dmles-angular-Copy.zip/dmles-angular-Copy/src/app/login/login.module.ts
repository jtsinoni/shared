import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {LoginComponent} from './login.component';
import {CommonComponentsModule} from '../common-components/common-components.module';
import {RouterModule} from '@angular/router';
import {AccessibilityModule} from './accessibility/accessibility.module';
import {InvitationModule} from './invitation/invitation.module';
import {UpdatePkiDnModule} from './update-pki-dn/update-pki-dn.module';
import {FormsModule} from '@angular/forms';
import {ChooseProfileComponent} from './choose-profile/choose-profile.component';
import {PipesModule} from '../pipes/pipes.module';

@NgModule({
  imports: [
    CommonModule, CommonComponentsModule, RouterModule, AccessibilityModule, InvitationModule, UpdatePkiDnModule, FormsModule, PipesModule
  ],
  declarations: [LoginComponent, ChooseProfileComponent],
  exports: [LoginComponent]
})
export class LoginModule {
}
