import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import {RouterTestingModule} from '@angular/router/testing';
import {ChooseProfileComponent} from './choose-profile.component';
import {PipesModule} from '../../pipes/pipes.module';
import {HttpTestModule} from '../../common-components/test/http-test.module';
import {LoginService} from '../../services/login.service';
import {MainNavService} from '../../home/main-nav/main-nav.service';
import {LoggerService} from '../../services/logger/logger.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {NotificationService} from '../../services/notification.service';
import {CurrentUserProfile } from '../../models/current-user-profile.model';
import { ToastrModule } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';
import {NavigationService} from '../../services/navigation.service';
import {PermissionService} from '../../services/permission.service';

describe('ChooseProfileComponent', () => {
  let component: ChooseProfileComponent;
  let fixture: ComponentFixture<ChooseProfileComponent>;
  let profileApiService: ProfileApiService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, PipesModule,  HttpTestModule.forRoot(), ToastrModule.forRoot()],
      declarations: [ ChooseProfileComponent ],
      providers: [LoggerService, MainNavService, ProfileApiService, NotificationService, LoginService,
        NavigationService, PermissionService],
      schemas: [NO_ERRORS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChooseProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    profileApiService = TestBed.get(ProfileApiService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select new profile if userProfileStatus equals ACTIVE', () => {
    const currentUserProfile: CurrentUserProfile = new CurrentUserProfile();
    currentUserProfile.userProfileStatus = 'ACTIVE';
    currentUserProfile.id = '1234567';

    spyOn(profileApiService, 'setCurrentProfile').and.returnValue(Observable.of(new CurrentUserProfile()));
    component.selectProfile(currentUserProfile);
    expect(profileApiService.setCurrentProfile).toHaveBeenCalledWith(currentUserProfile.id);
  });
});
