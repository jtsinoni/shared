import {Component, OnInit, AfterViewInit, ViewChild, ElementRef} from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/finally';

import {LoggerService} from '../../services/logger/logger.service';
import {LoginService} from '../../services/login.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {CurrentUserProfile} from '../../models/current-user-profile.model';
import {StateConstants} from '../../constants/state.constants';
import {ContentConstants} from '../../constants/content.constants';
import {NotificationService} from '../../services/notification.service';
import {NavigationService} from "../../services/navigation.service";

@Component({
  selector: 'app-choose-profile',
  templateUrl: './choose-profile.component.html',
})
export class ChooseProfileComponent implements OnInit, AfterViewInit {
  public profileTableData: any[];
  public isProfileDataLoading: boolean = false;

  @ViewChild('filterProfiles')
  filterProfilesElement: ElementRef;

  constructor(
    private logger: LoggerService,
    private loginService: LoginService,
    private profileApiService: ProfileApiService,
    private router: Router,
    private notificationService: NotificationService,
    private navigationService: NavigationService) {}

  ngOnInit() {
    this.loadProfiles();
  }

  ngAfterViewInit() {
    this.filterProfilesElement.nativeElement.focus();
  }

  private loadProfiles() {
    this.isProfileDataLoading = true;

    const pkiDn: string = this.loginService.pkiDn;
    this.profileApiService.getUserProfilesByPkiDn(pkiDn)
      .finally(() => {
        this.isProfileDataLoading = false;
      })
      .subscribe(
        data => {
          this.profileTableData = data;
          // this.logger.debug(`profileTableData => ${JSON.stringify(this.profileTableData)}`);
        },
        error => {
          this.logger.error(`Error retrieving profile list: ${error}`);
        },
      );
  }

  public selectProfile(userProfile: CurrentUserProfile) {
    // this.logger.debug(`Profile data: ${JSON.stringify(userProfile)}`);
    if (userProfile.userProfileStatus.toUpperCase() === 'ACTIVE') {
      this.changeMyProfile(userProfile);
    }
  }

  private changeMyProfile(userProfile: CurrentUserProfile) {
    this.profileApiService.setCurrentProfile(userProfile.id)
      .subscribe(
        response => {
          this.loginService.currentUser = response;
          this.login();
        },
        error => {
          const errorMessage: string = `Error changing User Profile: ${error}`;
          this.notificationService.errorMsg(errorMessage);
          this.logger.error(errorMessage);
        }
      );
  }

  private login() {
    this.loginService.signIn()
      .subscribe(
        signInData => {
          if (!signInData || signInData.pkiDn === ContentConstants.UNREGISTERED_USER) {
            this.notificationService.errorMsg(`There was a problem processing your request. If the problem persists please contact application support personnel`);
          } else {
            if (signInData.userProfileStatus.toUpperCase() === 'ACTIVE') {
              this.goToHome();
            }else {
                this.loadProfiles();
            }
          }
        },
        error => {
          this.notificationService.errorMsg(ContentConstants.SIGN_IN_ERR_MSG);
          this.logger.error(ContentConstants.SIGN_IN_ERR_MSG);
        }
      );
  }

  private goToHome() {
    // this.router.navigate(StateConstants.createLink(StateConstants.MY_DASHBOARD));
    this.navigationService.navigateTo(this.router, StateConstants.HOME_ROOT);
  }
}
