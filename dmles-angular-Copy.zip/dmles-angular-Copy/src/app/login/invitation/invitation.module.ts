import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvitationComponent } from './invitation.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [InvitationComponent],
  exports: [InvitationComponent]
})
export class InvitationModule { }
