import { Component, OnInit } from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';
import {Router} from '@angular/router';
import {StateConstants} from '../../constants/state.constants';
import {UserProfile} from '../../models/user-profile.model';
import {NavigationService} from '../../services/navigation.service';

@Component({
  selector: 'app-update-pki-dn',
  templateUrl: './update-pki-dn.component.html',
  styleUrls: ['./update-pki-dn.component.scss']
})
export class UpdatePkiDnComponent implements OnInit {
  private componentName: string = ' Update Pki Dn Component';

//  public userProfile: UserProfile = new UserProfile();


  constructor(private logger: LoggerService,
              private router: Router,
              private navigationService: NavigationService) { }

  ngOnInit() {
  }

  private checkUpdate() {
    // TODO complete
  }

  private goToLogin() {
    this.logger.info(`${this.componentName} - Go to Login`);
    this.navigationService.navigateTo(this.router, StateConstants.LOGIN);
    // this.router.navigate(StateConstants.createLink(StateConstants.LOGIN));

  }

  public updatePkiDn() {

  }

  public cancelPkiDnUpdate() {

  }


}
