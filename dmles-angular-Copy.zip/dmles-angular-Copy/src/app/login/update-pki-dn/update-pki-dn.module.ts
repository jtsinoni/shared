import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdatePkiDnComponent } from './update-pki-dn.component';
import { RequestPkiDnUpdateComponent } from './request-pki-dn-update.component';
import {FormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule, FormsModule
  ],
  declarations: [UpdatePkiDnComponent, RequestPkiDnUpdateComponent],
  exports: [UpdatePkiDnComponent]
})
export class UpdatePkiDnModule { }
