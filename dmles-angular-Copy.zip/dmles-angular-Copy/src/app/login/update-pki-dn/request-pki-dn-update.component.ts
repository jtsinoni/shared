import { Component, OnInit } from '@angular/core';
import {StateConstants} from '../../constants/state.constants';
import {LoggerService} from '../../services/logger/logger.service';
import {Router} from '@angular/router';
import {NavigationService} from '../../services/navigation.service';

@Component({
  selector: 'app-request-pki-dn-update',
  templateUrl: './request-pki-dn-update.component.html',
  styleUrls: ['./request-pki-dn-update.component.scss']
})
export class RequestPkiDnUpdateComponent implements OnInit {

  private componentName: string = 'RequestPkiDnUpdate Component';

  public credentials: any = {};
  public userEmail: string;

  constructor(private logger: LoggerService,
              private router: Router,
              private navigationService: NavigationService) { }

  ngOnInit() {
  }

  private goToLogin() {
    this.logger.info(`${this.componentName} - Go to Login`);
    // this.router.navigate(StateConstants.createLink(StateConstants.LOGIN));
    this.navigationService.navigateTo(this.router, StateConstants.LOGIN);

  }

  public onSubmit() {
    if (this.userEmail === null || this.userEmail === '') {
      this.logger.info('TODO Validate email here... more than if it exists...?');
    }
    //   this.NotificationService.errorMsg("User's e-mail is required to request a CAC/PIV update.");
    //   document.getElementById("userEmail").focus();
    // } else {
    //   this.OAuthService.getNewToken(this.credentials.dn);
    //   this.ProfileApiService.requestPkiDnUpdate(this.userEmail).then((response: IHttpPromiseCallbackArg<UserProfile>) => {;
    //     this.NotificationService.successMsg("Successfully submitted request for CAC/PIV update.");
    //     this.goToDmlesLogin();
    //   }, (errResponse: any) => {
    //     this.NotificationService.errorMsg(this.ContentConstants.REQUEST_UPDATE_ERR_MSG);
    //   });
    // }
  }

}
