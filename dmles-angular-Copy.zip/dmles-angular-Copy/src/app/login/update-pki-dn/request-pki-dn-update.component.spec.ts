import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestPkiDnUpdateComponent } from './request-pki-dn-update.component';
import {RouterTestingModule} from '@angular/router/testing';
import {LoggerService} from '../../services/logger/logger.service';
import {FormsModule} from '@angular/forms';
import {NavigationService} from '../../services/navigation.service';
import {PermissionService} from '../../services/permission.service';
import {LoginService} from '../../services/login.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';

describe('RequestPkiDnUpdateComponent', () => {
  let component: RequestPkiDnUpdateComponent;
  let fixture: ComponentFixture<RequestPkiDnUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule, HttpTestModule.forRoot()],
      declarations: [ RequestPkiDnUpdateComponent ],
      providers: [LoggerService, NavigationService,
        PermissionService, LoginService, ProfileApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestPkiDnUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
