import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePkiDnComponent } from './update-pki-dn.component';
import {LoggerService} from '../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {NavigationService} from '../../services/navigation.service';
import {PermissionService} from '../../services/permission.service';
import {LoginService} from '../../services/login.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';

describe('UpdatePkiDnComponent', () => {
  let component: UpdatePkiDnComponent;
  let fixture: ComponentFixture<UpdatePkiDnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpTestModule.forRoot()],
      declarations: [ UpdatePkiDnComponent ],
      providers: [LoggerService, NavigationService,
        PermissionService, LoginService, ProfileApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePkiDnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
