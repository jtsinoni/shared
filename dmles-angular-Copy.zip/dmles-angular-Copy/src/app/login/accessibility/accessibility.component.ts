import { Component, OnInit } from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';
import {Router} from '@angular/router';
import {StateConstants} from '../../constants/state.constants';
import {NavigationService} from '../../services/navigation.service';

@Component({
  selector: 'app-accessibility',
  templateUrl: './accessibility.component.html'
})
export class AccessibilityComponent implements OnInit {

  private componentName: string =  'AccessibilityComponent';

  constructor(private logger: LoggerService,
              private router: Router,
              private navigationService: NavigationService) { }

  ngOnInit() {
  }

  public goBack() {
    this.logger.debug('%s - Go back to login', this.componentName);
    this.navigationService.navigateTo(this.router, StateConstants.LOGIN);
    // this.router.navigate(StateConstants.createLink(StateConstants.LOGIN));
  }

}
