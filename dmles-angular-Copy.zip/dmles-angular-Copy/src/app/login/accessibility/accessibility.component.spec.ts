import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessibilityComponent } from './accessibility.component';
import {LoggerService} from '../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {NavigationService} from '../../services/navigation.service';
import {PermissionService} from '../../services/permission.service';
import {LoginService} from '../../services/login.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';

describe('AccessibilityComponent', () => {
  let component: AccessibilityComponent;
  let fixture: ComponentFixture<AccessibilityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpTestModule.forRoot()],
      declarations: [ AccessibilityComponent ],
      providers: [LoggerService, NavigationService,
        PermissionService, LoginService, ProfileApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccessibilityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
