import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccessibilityComponent } from './accessibility.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [AccessibilityComponent],
  exports: [AccessibilityComponent]
})
export class AccessibilityModule { }
