import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { LoginComponent } from './login.component';
import { OAuthService } from '../services/oauth.service';
import { LoggerService } from '../services/logger/logger.service';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';
import { StorageService } from '../services/storage.service';
import { WindowService } from '../services/window.service';
import { UtilService } from '../services/util.service';
import { CurrencyPipe } from '@angular/common';
import { Base64Service } from '../services/base64.service';
import { AppConfig } from '../app.config';
import { LoginService } from '../services/login.service';
import { ProfileApiService } from '../services/profile-api.service';
import { MainNavService } from '../home/main-nav/main-nav.service';
import { CurrentUserProfile } from '../models/current-user-profile.model';
import {NavigationService} from '../services/navigation.service';
import {PermissionService} from '../services/permission.service';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let logger: LoggerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, RouterTestingModule],
      providers: [OAuthService, LoggerService, HttpClient, LoginService, AuthenticationService,
                  Base64Service, StorageService, WindowService, MainNavService,
                  ProfileApiService, UtilService, CurrencyPipe, NavigationService, PermissionService],
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    logger = TestBed.get(LoggerService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create profileInfo', () => {
    const profileInfo = component.profileInfo(true, new CurrentUserProfile(), 'an app error', 'a js error');
    logger.debug(`profileInfo => ${JSON.stringify(profileInfo)}`);
  });
  // fit('should do a CAC login', () => {
  //   component.onCacLogin();
  //   // expect(component).toBeTruthy();
  // });
});
