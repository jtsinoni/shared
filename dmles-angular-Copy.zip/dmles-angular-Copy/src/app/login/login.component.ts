import {Component, OnInit, AfterViewInit, ViewChild, ElementRef, ChangeDetectorRef} from '@angular/core';
import {Router} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {OAuthService} from '../services/oauth.service';
import {LoggerService} from '../services/logger/logger.service';
import {StateConstants} from '../constants/state.constants';
import {ContentConstants} from '../constants/content.constants';
import {LoginService} from '../services/login.service';
import {CurrentUserProfile} from '../models/current-user-profile.model';
import {ProfileApiService} from '../services/profile-api.service';
import {NavigationService} from '../services/navigation.service';

interface ProfileInfo {
  currentUserProfile: CurrentUserProfile;
  isUserProfileStatusActive: boolean;
  appError: any;
  jsError: any;
}

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit, AfterViewInit {
  private componentName: String = 'Login Component';
  public credentials: any = {};
  public isLoading: boolean = false;

  @ViewChild('loginButton')
  loginButtonElement: ElementRef;

  @ViewChild('okButton')
  okButtonElement: ElementRef;

  constructor(
    private oAuthService: OAuthService,
    private router: Router,
    private logger: LoggerService,
    private loginService: LoginService,
    private profileApiService: ProfileApiService,
    private navigationService: NavigationService,
    private changeDetectorRef: ChangeDetectorRef) {}

  ngOnInit() {
    this.credentials = {
      dn: ''
    };
  }

  ngAfterViewInit() {
    if (this.loginService.securityAccepted){
      this.loginButtonElement.nativeElement.focus();
    } else {
      this.okButtonElement.nativeElement.focus();
    }
  }

  public goToLogin() {
    this.loginService.securityAccepted = true;

    // in this particular case we are changing the DOM to include the loginCard vs the securityCard, therefore we need to
    // do a change detection in order to focus on the "loginButton"
    this.changeDetectorRef.detectChanges();
    this.loginButtonElement.nativeElement.focus();
  }

  public showAccessibilityDetails() {
    this.logger.info(`${this.componentName} - show Accessibility Details`);
    // this.router.navigate(StateConstants.createLink(StateConstants.ACCESSIBILITY));
    this.navigationService.navigateTo(this.router, StateConstants.ACCESSIBILITY);
  }

  public requestPkiDnUpdate() {
    this.logger.info(`${this.componentName} - request Pki Dn Update`);
    // this.router.navigate(StateConstants.createLink(StateConstants.REQUEST_PKI_DN_UPDATE));
    this.navigationService.navigateTo(this.router, StateConstants.REQUEST_PKI_DN_UPDATE);
  }

  public goToChooseProfile() {
    this.logger.info(`${this.componentName} - choose profile`);
    // this.router.navigate(StateConstants.createLink(StateConstants.CHOOSE_PROFILE));
    this.navigationService.navigateTo(this.router, StateConstants.CHOOSE_PROFILE);
  }

  private goToHome() {
      this.logger.debug(`${this.componentName} - Go to home`);
      // this.router.navigate(StateConstants.createLink(StateConstants.MY_DASHBOARD));
      this.navigationService.navigateFromHomeTo(this.router, StateConstants.MY_DASHBOARD);
  }

  profileInfo(isUserProfileStatusActive: boolean,
                     currentUserProfile?: CurrentUserProfile,
                     appError?: string,
                     jsError?: any): ProfileInfo | any {
    const profile: ProfileInfo  = { isUserProfileStatusActive: false, currentUserProfile: undefined,
                                    appError: undefined, jsError: undefined};

    if (currentUserProfile) { profile.currentUserProfile = currentUserProfile; }
    if (isUserProfileStatusActive) { profile.isUserProfileStatusActive = isUserProfileStatusActive; }
    if (appError) { profile.appError = appError; }
    if (jsError) { profile.jsError = jsError; }

    return profile;
  }

  public onCacLogin() {
    this.logger.info(`${this.componentName} - Performing CAC login`);
    this.isLoading = true;

    const newToken = () => {
      this.isLoading = false;
      return this.oAuthService.getNewToken(this.credentials.dn)
        .catch(error => {
          // this.notificationService.throwError(this.componentName, ContentConstants.ERR_MSG, error);
           throw this.profileInfo(false, null, ContentConstants.SIGN_IN_ERR_MSG, error);
        });
    };

    const chooseProfile = (currentUserProfile: CurrentUserProfile) => {
      this.isLoading = false;
      return this.profileApiService.getCntActiveUserProfiles(currentUserProfile.pkiDn)
        .map(activeData => {
          if (activeData > 0) {
              this.loginService.pkiDn = currentUserProfile.pkiDn;
              this.goToChooseProfile();
          } else {
              // this.notificationService.errorMsg(currentUserProfile.reason);
          }
          return this.profileInfo(false, currentUserProfile);
        })
        .catch(error => {
          // this.notificationService.throwError(this.componentName, ContentConstants.SIGN_IN_ERR_MSG, error);

          throw this.profileInfo(false, currentUserProfile, ContentConstants.SIGN_IN_ERR_MSG, error);
        });
    };

    const signIn = () => {
      let isUserProfileStatusActive: boolean = false;
      let currentUserProfile: CurrentUserProfile;
      this.isLoading = false;
      return this.loginService.signIn()
        .map(signInData => {
          currentUserProfile = signInData;
          if (signInData.userProfileStatus === 'ACTIVE') {
            isUserProfileStatusActive = true;
            this.goToHome();
          }
          return this.profileInfo(isUserProfileStatusActive, currentUserProfile);
        })
        .catch(error => {
          const appError: string = `CAC not found`;
          // this.notificationService.errorMsg(appError);

          throw this.profileInfo(isUserProfileStatusActive, currentUserProfile, appError, error);
        });
    };

    // 1.  Call newToken method to get Token from server
    // 2.  Call signIn method to check for userProfileStatus, if active, falls thru to subscribe, else calls chooseProfile
    // Note:  flatMap is used because the returned object from the methods: signIn and chooseProfile is an object which
    //        needs to flattened or parsed to its raw data
    newToken()
      .flatMap(signIn)
      .filter(profileInfo => profileInfo.isUserProfileStatusActive === false)
      .flatMap(profileInfo => chooseProfile(profileInfo.currentUserProfile))
      .subscribe(
        data => {
          // this.logger.debug(`data => ${JSON.stringify(data)}`);
        },
        error => {
          this.logger.error(JSON.stringify(error.jsError));
        }
      );
  }
}
