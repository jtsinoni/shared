import {Component, OnInit} from '@angular/core';
import {ViewModeType} from '../jmlfdc-admin/abi-staging/models/view-mode-type.enum';
import {LoggerService} from '../../services/logger/logger.service';
import {ActivatedRoute, Router} from '@angular/router';
import {StateConstants} from '../../constants/state.constants';
import {ProfileStatusConstants} from '../../constants/profile-status.constants';
import {SystemNotificationService} from '../jmlfdc-admin/system-notification/services/system-notification.service';
import {DashboardService} from './services/dashboard.service';
import {SystemNotificationApiService} from '../jmlfdc-admin/system-notification/services/system-notification-api.service';
import {ResourceConstants} from '../../constants/resource.constants';
import {NavigationService} from "../../services/navigation.service";

@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  providers: [SystemNotificationService, SystemNotificationApiService, DashboardService]
})
export class MyDashboardComponent implements OnInit {

  public elementRequestService: string = ResourceConstants.EQUIP_REQUESTS_VIEW;
  public elementEquipRecords: string = ResourceConstants.EQUIP_RECORDS_VIEW;
  public elementManageAbiStaging: string = ResourceConstants.MANAGE_ABI_STAGING;
  public elementUserProfileManagement: string = ResourceConstants.USER_PROFILE_MANAGEMENT;

  constructor(private logger: LoggerService, private router: Router, private activatedRoute: ActivatedRoute,
              public systemNotificationService: SystemNotificationService,
              public dashboardService: DashboardService,
              private navigationService: NavigationService) {}

  ngOnInit() {
    this.logger.debug(`what is the DASHBOARD router outlet: ${this.activatedRoute.outlet}`);
  }

  public isActionable(newClass: string, count: number){
    let useClass: string = 'badge-dark';
    if (count > 0){
      useClass = newClass;
    }
    return useClass;
  }

  public canCreateRequests(): boolean {
    const canCreate: boolean = false;
    // TODO add permissionservice
    // if(this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_CREATE)){
    //   canCreate = true;
    // }
    return canCreate;
  }

  public goToSystemNotifications() {
    // TODO used?

  }

  public canReviewRequests(): boolean {
    const canReview: boolean = false;
    // if(this.PermissionService.checkElements(this.ResourceConstants.EQUIP_REQUESTS_REVIEW)){
    //   canReview = true;
    // }
    return canReview;
  }

  public goToABiManagementIncomplete() {
    return this.goToABiStagingViewState(ViewModeType.ShowIncomplete);
  }

  public goToABiManagementMerging() {
    return this.goToABiStagingViewState(ViewModeType.ShowMerging);
  }

  public goToABiManagementPendingApproval() {
    return this.goToABiStagingViewState(ViewModeType.ShowPendingApproval);
  }

  public goToABiManagementApproved() {
    return this.goToABiStagingViewState(ViewModeType.ShowApproved);
  }

  public goToABiManagementPublished() {
    return this.goToABiStagingViewState(ViewModeType.ShowPublished);
  }

  public goToABiManagementStaging() {
    return this.goToABiStagingViewState(ViewModeType.ShowAll);
  }

  public goToABiManagementInUse() {
    return this.goToABiStagingViewState(ViewModeType.ShowInUse);
  }

  public goToABiManagementMerged() {
    return this.goToABiStagingViewState(ViewModeType.ShowMerged);
  }

  public goToABiStagingViewState(viewModeType: ViewModeType) {
    this.logger.info('going to ABi Staging');

    // TODO add ABiStagingManagementService
    // this.ABiStagingManagementService.setLastViewModeByViewModeType(viewModeType);
    // this.ABiStagingManagementService.lastSearchFilter = "";

    return this.navigationService.navigateDirectlyTo(this.router, StateConstants.ABI_STAGING_VIEW);

  }

  public goToInvitationsList() {
    return this.navigationService.navigateDirectlyTo(this.router, StateConstants.ADMIN_USER_PROFILE_MNG);
  }

  public goToActiveUserList() {
    this.navigationService.navigateDirectlyTo(this.router, StateConstants.ADMIN_USER_PROFILE_MNG);
  }

  public goToAuthorizedUserList() {
    return this.navigationService.navigateDirectlyTo(this.router, StateConstants.ADMIN_USER_PROFILE_MNG);
  }

  public goToInactiveUserList() {
    return this.navigateToAdminUserProfileManagement(ProfileStatusConstants.STATUS_INACTIVE);
  }

  public goToLockedUserList() {
    return this.navigateToAdminUserProfileManagement(ProfileStatusConstants.STATUS_LOCKED);

  }

  public goToRelockedUserList() {
    return this.navigateToAdminUserProfileManagement(ProfileStatusConstants.STATUS_RELOCKED);

  }

  public goToSuspendedUserList() {
    return this.navigateToAdminUserProfileManagement(ProfileStatusConstants.STATUS_SUSPENDED);


  }

  private navigateToAdminUserProfileManagement(profileStatus: string) {
    // this.UserProfileManagementService.setInitialProfileFilter({ userProfileStatus: profileStatus });
    return this.navigationService.navigateDirectlyTo(this.router, ( StateConstants.JMLFDC_ADMIN_SHELL + '/' +
      StateConstants.NOTIFICATIONS_VIEW));
  }

  public goToMyEquipmentRequests() {
    return this.navigationService.navigateDirectlyTo(this.router, StateConstants.EQUIP_REQUEST_MY_REQUESTS);
  }

  public goToEquipmentRecordSearch() {
    return this.navigationService.navigateDirectlyTo(this.router, StateConstants.EQUIP_RECORD_SEARCH);
  }


}
