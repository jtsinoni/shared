import { TestBed, inject } from '@angular/core/testing';

import { DashboardService } from './dashboard.service';
import {HttpTestModule} from '../../../common-components/test/http-test.module';

describe('DashboardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpTestModule.forRoot()],
      providers: [DashboardService ]
    });
  });

  it('should be created', inject([DashboardService], (service: DashboardService) => {
    expect(service).toBeTruthy();
  }));
});
