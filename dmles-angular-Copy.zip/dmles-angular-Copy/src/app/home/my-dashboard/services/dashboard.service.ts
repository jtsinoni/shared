import {Injectable} from '@angular/core';
import {LoggerService} from '../../../services/logger/logger.service';
import {ApiService} from '../../../services/api.service';
import {HttpClient} from '@angular/common/http';
import {AuthenticationService} from '../../../services/authentication.service';
import {ApiConstants} from '../../../constants/api.constants';

@Injectable()
export class DashboardService extends ApiService {

  private serviceName: string = 'Dashboard Service';

  public activeUsers: number = 0;
  public inactiveUsers: number = 0;
  public deletedUsers: number = 0;
  public expiredUsers: number = 0;
  public lockedUsers: number = 0;
  public relockedUsers: number = 0;
  public pendingUsers: number = 0;
  public suspendedUsers: number = 0;

  public myRequests: number = 0;
  public myOrgsRequests: number = 0;
  public actionRequired: number = 0;
  public reviewMyOrg: number = 0;

  public abiStagingIncompleteCount = 0;
  public abiStagingMergingCount = 0;
  public abiStagingPendingApprovalCount = 0; // abiCatalogStatistics.pendingApprovalCount;
  public abiStagingApprovedRecordsCount = 0;
  public abiStagingPublishedRecordsCount = 0;
  public abiStagingRecordCount = 0;
  public abiStagingInUseCount = 0;
  public abiStagingMergedRecordsCount = 0;

  public equipmentRecordTotalActiveRecordsCount = 0;
  public equipmentRecordTotalActiveAccountableRecordCount = 0;
  public equipmentRecordTotalActiveMaintenanceRequiredRecordCount = 0;
  public equipmentRecordTotalActiveEquipmentRecordCost = '$0.00';


  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService) {
    super(ApiConstants.USER_API, logger, http, authenticationService);

    this.logger.debug('%s - Start', this.serviceName);
  }

  public getUserDashboardStats() {
    this.activeUsers = 0;
    this.inactiveUsers = 0;
    this.deletedUsers = 0;
    this.expiredUsers = 0;
    this.lockedUsers = 0;
    this.relockedUsers = 0;
    this.pendingUsers = 0;
    this.suspendedUsers = 0;
    return this.get('getUserDashboardStats').map((response: any) => {
      this.activeUsers = response.data.activeUsers;
      this.inactiveUsers = response.data.inactiveUsers;
      this.deletedUsers = response.data.deletedUsers;
      this.expiredUsers = response.data.expiredUsers;
      this.lockedUsers = response.data.lockedUsers;
      this.relockedUsers = response.data.relockedUsers;
      this.pendingUsers = response.data.pendingUsers;
      this.suspendedUsers = response.data.suspendedUsers;
    });
  }

  public getEquipmentRequestCounts() {
    // return this.get("getEquipmentRequestDashboard",  ApiConstants.EQUIPMENT_API).then((response: any) => {
    //   this.myRequests = response.data.myRequests;
    //   this.myOrgsRequests = response.data.myOrgsRequests;
    //   this.actionRequired = response.data.actionRequired;
    //   this.reviewMyOrg = response.data.reviewMyOrg;
    // }, (errResponse: any) => {
    //   this.$log.error("Error retrieving number of active, new, pending equipment requests");
    //   this.NotificationService.errorMsg("Unable to retrieve equipment request statistics");
    // });
  }

  public getAbiStagingStats() {
    // this.ABiStagingManagementService.getStatistics().then((response: any) => {
    //   var abiStagingCatalogStatistics: any = response.data;
    //   this.abiStagingIncompleteCount = abiStagingCatalogStatistics.incompleteCount;
    //   this.abiStagingMergingCount = abiStagingCatalogStatistics.mergingCount;
    //   this.abiStagingPendingApprovalCount = abiStagingCatalogStatistics.pendingApprovalCount;
    //   this.abiStagingApprovedRecordsCount = abiStagingCatalogStatistics.approvedCount;
    //   this.abiStagingPublishedRecordsCount = abiStagingCatalogStatistics.publishedCount;
    //
    //   this.abiStagingRecordCount = abiStagingCatalogStatistics.stagingRecordCount;
    //   this.abiStagingInUseCount = abiStagingCatalogStatistics.inUseCount;
    //   this.abiStagingMergedRecordsCount = abiStagingCatalogStatistics.mergedRecordsCount;
    //
    // }, (errResponse: any) => {
    //   this.$log.error("Error retrieving ABi Staging statistics");
    //   this.NotificationService.errorMsg("Unable to retrieve ABi Staging statistics");
    // });
  }

  public getEquipmentRecordStats() {
    // this.EquipmentRecordService.getDashboardStatistics().then((response: any) => {
    //   var equipmentRecordStatistics: any = response.data;
    //   this.equipmentRecordTotalActiveRecordsCount = equipmentRecordStatistics.totalActiveRecordCount;
    //   this.equipmentRecordTotalActiveAccountableRecordCount = equipmentRecordStatistics.totalActiveAccountableRecordCount;
    //   this.equipmentRecordTotalActiveMaintenanceRequiredRecordCount = equipmentRecordStatistics.totalActiveMaintenanceRequiredRecordCount;
    //   if (equipmentRecordStatistics.totalActiveEquipmentRecordCost != null) {
    //     this.equipmentRecordTotalActiveEquipmentRecordCost = this.$filter('currency')(equipmentRecordStatistics.totalActiveEquipmentRecordCost);
    //   }
    //
    // }, (errResponse: any) => {
    //   this.$log.error("Error retrieving Equipment Record statistics");
    //   this.NotificationService.errorMsg("Unable to retrieve Equipment Record statistics");
    // });
  }

}
