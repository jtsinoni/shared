import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyDashboardComponent } from './my-dashboard.component';
import {LoggerService} from '../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../../common-components/test/http-test.module';
import {SystemNotificationApiService} from '../jmlfdc-admin/system-notification/services/system-notification-api.service';
import {PermissionService} from '../../services/permission.service';
import {DirectivesModule} from '../../directives/directives.module';
import {LoginService} from '../../services/login.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {NavigationService} from '../../services/navigation.service';

describe('MyDashboardComponent', () => {
  let component: MyDashboardComponent;
  let fixture: ComponentFixture<MyDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyDashboardComponent ],
      providers: [LoggerService, LoginService, SystemNotificationApiService, PermissionService, ProfileApiService,
        NavigationService, PermissionService, LoginService],
      imports: [HttpTestModule.forRoot(), RouterTestingModule, DirectivesModule],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should return boolean from canCreateRequests()', () => {
    expect(component.canCreateRequests()).toEqual(false);
  });
  it('should return boolean from canReviewRequests()', () => {
    expect(component.canReviewRequests()).toEqual(false);
  });

  it('should navigate to ABiManagementIncomplete', () => {
    expect(component.goToABiManagementIncomplete().then).toBeDefined();
  });
  it('should navigate to ABiManagementMerging', () => {
    expect(component.goToABiManagementMerging().then).toBeDefined();
});
  it('should navigate to goToABiManagementPendingApproval()', () => {
    expect(component.goToABiManagementPendingApproval().then).toBeDefined();
  });
  it('should navigate to goToABiManagementApproved()', () => {
    expect(component.goToABiManagementApproved().then).toBeDefined();
  });
  it('should navigate to goToABiManagementPublished()', () => {
    expect(component.goToABiManagementPublished().then).toBeDefined();
  });
  it('should navigate to goToABiManagementStaging()', () => {
    expect(component.goToABiManagementStaging().then).toBeDefined();
  });
  it('should navigate to goToABiManagementInUse()', () => {
    expect(component.goToABiManagementInUse().then).toBeDefined();
  });





});
