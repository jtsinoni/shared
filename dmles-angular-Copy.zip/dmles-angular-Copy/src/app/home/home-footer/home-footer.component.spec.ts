import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeFooterComponent } from './home-footer.component';
import {AlertModule} from 'ngx-bootstrap';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {DmlesDateTimePipe} from '../../pipes/dmles-date-time.pipe';
import {MainNavComponent} from '../main-nav/main-nav.component';
import {LoggerService} from '../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';
import {LoginService} from '../../services/login.service';

describe('HomeFooterComponent', () => {
  let component: HomeFooterComponent;
  let fixture: ComponentFixture<HomeFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeFooterComponent, DmlesDateTimePipe, MainNavComponent ],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [AlertModule.forRoot(), RouterTestingModule, HttpTestModule.forRoot()],
      providers: [LoggerService, ProfileApiService, LoginService]

    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  // TODO -unable to currently mock, spyon or substitute LoginService as current user calls out to API endpoint
  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
