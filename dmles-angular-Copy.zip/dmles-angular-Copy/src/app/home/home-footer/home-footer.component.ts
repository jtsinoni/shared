import { Component, OnInit } from '@angular/core';
import {LoginService} from '../../services/login.service';
import {LoggerService} from '../../services/logger/logger.service';

@Component({
  selector: 'app-home-footer',
  templateUrl: './home-footer.component.html'
})
export class HomeFooterComponent implements OnInit {

  public loginDateTime: Date;
  public lastLoginIP: string;
  public showLastLoginInfo: boolean;
  public logiColeAnimation: string = 'slideInUp';

  constructor(private logger: LoggerService, private loginService: LoginService) {}

  ngOnInit() {
    if (this.loginService.currentUser.previousLoginDate) {
      this.showLastLoginInfo = true;
      this.loginDateTime = this.loginService.currentUser.lastLoginDate;
      this.lastLoginIP = this.loginService.currentUser.lastLoginIP;
      setTimeout(() => this.hideLoginPane(), 10000);
    } else {
      this.showLastLoginInfo = false;
    }
  }

  public hideLoginPane(){
    this.logiColeAnimation = 'slideOutDown';
  }
}
