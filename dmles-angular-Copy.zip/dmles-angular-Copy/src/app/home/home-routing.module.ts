import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {MyDashboardComponent} from './my-dashboard/my-dashboard.component';
import {LoadingComponent} from './home-components/loading.component';
import {MyProfileComponent} from './home-components/my-profile.component';
import {AboutComponent} from './home-components/about.component';
import {HelpComponent} from './home-components/help.component';
import {HomeComponent} from './home.component';
import {RouteConstants} from '../constants/route.constants';
import {MyProfileEditComponent} from './home-components/my-profile-edit.component';
import {NavigationService} from '../services/navigation.service';

const homeRoutes: Routes = [
  {
    path: '', component: HomeComponent, canActivate: [NavigationService],
    data: {breadcrumb : RouteConstants.HOME_ROOT.breadcrumb}, children: [

    {
      path: RouteConstants.MY_DASHBOARD.route,
      component: MyDashboardComponent,
      data: {breadcrumb: RouteConstants.MY_DASHBOARD.breadcrumb},
      canActivate: [NavigationService]
    },
    {
      path:  RouteConstants.ABOUT.route,
      component: AboutComponent,
      data: {breadcrumb: RouteConstants.ABOUT.breadcrumb},
      canActivate: [NavigationService]
    },
    {
      path:  RouteConstants.HELP.route,
      component: HelpComponent,
      data: {breadcrumb: RouteConstants.HELP.breadcrumb},
      canActivate: [NavigationService]
    },
    {
      path:  RouteConstants.LOADING.route,
      component: LoadingComponent,
    },
    {
      path: RouteConstants.USER_PROFILE.route,
      component: MyProfileComponent,
      data: {
        breadcrumb: RouteConstants.USER_PROFILE.breadcrumb
      },
      canActivateChild: [NavigationService]
    },
    {
      path: RouteConstants.USER_PROFILE_EDIT_GEN_INFO.route,
      component: MyProfileEditComponent,
      data: {
        breadcrumb: RouteConstants.USER_PROFILE_EDIT_GEN_INFO.breadcrumb
      },
      canActivateChild: [NavigationService]
    },
    {
      path: RouteConstants.JMLFDC_ADMIN.route,
      loadChildren: 'app/home/jmlfdc-admin/jmlfdc-admin.module#JmlfdcAdminModule',
      canActivate: [NavigationService]
    },
    {
      path: RouteConstants.INVENTORY.route,
      loadChildren: 'app/home/inventory/inventory.module#InventoryModule',
      canActivate: [NavigationService]
    },
    {
      path: RouteConstants.ACCESS.route,
      loadChildren: 'app/home/access/access.module#AccessModule',
      canActivate: [NavigationService]
    },
    {path: '', redirectTo: RouteConstants.MY_DASHBOARD.route}
  ]
  },
  {path: '', redirectTo: RouteConstants.HOME_ROOT.route} // this must be present to prevent child navigation from falling through

];

@NgModule({
  imports: [RouterModule.forChild(homeRoutes)],
  exports: [RouterModule]
})
export class HomeRoutingModule {
}
