import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyProfileComponent } from './my-profile.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {PipesModule} from '../../pipes/pipes.module';
import {LoggerService} from '../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {ProfileService} from '../../services/profile.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';
import {MainNavService} from '../main-nav/main-nav.service';
import {LoginService} from '../../services/login.service';
import {CurrentUserProfile} from '../../models/current-user-profile.model';

describe('MyProfileComponent', () => {
  let component: MyProfileComponent;
  let fixture: ComponentFixture<MyProfileComponent>;
  let loginService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [PipesModule, RouterTestingModule, HttpTestModule.forRoot()],
      declarations: [ MyProfileComponent ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        LoggerService,
        ProfileService,
        ProfileApiService,
        LoginService,
        MainNavService]
    })
    .compileComponents().then(() => {
    loginService = TestBed.get(LoginService);
      spyOn(loginService, 'currentUser').and.returnValue(new CurrentUserProfile());
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // TODO -unable to currently mock, spyon or substitute LoginService as current user calls out to API endpoint

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
