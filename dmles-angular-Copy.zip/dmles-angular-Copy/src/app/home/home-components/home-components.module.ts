import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutComponent } from './about.component';
import { HelpComponent } from './help.component';
import { MyProfileComponent } from './my-profile.component';
import { LoadingComponent } from './loading.component';
import { TooltipModule} from 'ngx-bootstrap';
import {PipesModule} from '../../pipes/pipes.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MyProfileEditComponent } from './my-profile-edit.component';

@NgModule({
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule,
    TooltipModule.forRoot(), PipesModule
  ],
  declarations: [AboutComponent, HelpComponent, MyProfileComponent, LoadingComponent, MyProfileEditComponent ],
  exports: [AboutComponent, HelpComponent, MyProfileComponent, LoadingComponent, MyProfileEditComponent]
})
export class HomeComponentsModule { }
