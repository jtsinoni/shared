import {Component, DoCheck, OnInit} from '@angular/core';
import {LoginService} from '../../services/login.service';
import {ProfileService} from '../../services/profile.service';
import {LoggerService} from '../../services/logger/logger.service';
import {ActivatedRoute, Router} from '@angular/router';
import {StateConstants} from '../../constants/state.constants';
import {NavigationService} from '../../services/navigation.service';
import {RouteConstants} from '../../constants/route.constants';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  providers: [ProfileService, LoginService]
})
export class MyProfileComponent implements OnInit, DoCheck {

  constructor(private logger: LoggerService,
              public loginService: LoginService,
              public profileService: ProfileService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private navigationService: NavigationService) {
  }

  ngOnInit() {
    this.profileService.getProfileData(false);
  }

  ngDoCheck(): void {
    const currentUser = this.loginService.currentUser;
  }


  // public changeAccess(): void {
  //   this.navigationService.navigateTo(this.router, RouteConstants.LOADING.route);
  //     this.navigationService.navigateTo(this.router, RouteConstants.MY_DASHBOARD.route);
  //   this.profileService.changeAccess().subscribe(() => {
  //   });
  // }
  //
  // public changeProfile(): void {
  //   this.navigationService.navigateTo(this.router, RouteConstants.LOADING.route);
  //   this.profileService.changeProfile().subscribe(() => {
  //     this.navigationService.navigateTo(this.router, RouteConstants.MY_DASHBOARD.route);
  //   });
  // }

  public changeAccess(): void {
    this.profileService.changeAccess(true);
    this.navigationService.navigateTo(this.router, RouteConstants.LOADING.route);
  }

  public changeProfile(): void {
    this.profileService.changeProfile(true);
    this.navigationService.navigateTo(this.router, RouteConstants.MY_DASHBOARD.route);
  }


  public goToEditProfile(): void {
    this.navigationService.navigateRelativeTo(this.router, RouteConstants.USER_PROFILE_EDIT_GEN_INFO.route, this.activatedRoute);
  }

}
