import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {UserProfile} from '../../models/user-profile.model';
import {LoggerService} from '../../services/logger/logger.service';
import {LoginService} from '../../services/login.service';
import {NotificationService} from '../../services/notification.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {ActivatedRoute, Router} from '@angular/router';
import {StateConstants} from '../../constants/state.constants';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NavigationService} from '../../services/navigation.service';

@Component({
  selector: 'app-my-profile-edit',
  templateUrl: './my-profile-edit.component.html'
})
export class MyProfileEditComponent implements OnInit, OnChanges {

  public userProfileGeneralInfoChanged: boolean = false;

  @Input() userProfile: UserProfile;

  public profileExpirationDate: Date;
  public profileUpdateDate: Date;
  public updatedBy: String;
  private phoneNumber: any = {phoneNumberType: '', value: '' };

  public userProfileEditGenInfoForm: FormGroup;

  constructor(private logger: LoggerService, private loginService: LoginService,
              private profileApiService: ProfileApiService,
              private notificationService: NotificationService,
              private router: Router,
              private formBuilder: FormBuilder,
              private activatedRoute: ActivatedRoute,
              private navigationService: NavigationService) {

    this.createForm();
    this.setUserProfile();

  }

  createForm() {
    this.userProfileEditGenInfoForm = this.formBuilder.group({

      profileNameControl: ['', Validators.required],
      firstNameControl: ['', Validators.required],
      lastNameControl: ['', Validators.required],
      emailControl: ['', Validators.required],
      firstPhoneNumberControl: ['', Validators.required]
    });

    this.userProfileEditGenInfoForm.valueChanges.subscribe(data => {
      this.userProfileGeneralInfoChanged = true;
    });

 }

  setUserProfile() {

    this.profileApiService.getUserProfile()
      .subscribe(
        response => {
          this.userProfile = response;
          this.userProfileEditGenInfoForm.setValue({
            profileNameControl: this.userProfile.profileName,
            firstNameControl: this.userProfile.firstName,
            lastNameControl: this.userProfile.lastName,
            emailControl: this.userProfile.email,
            firstPhoneNumberControl: this.userProfile.phoneNumbers[0].value,

          });
          this.profileExpirationDate = response.profileExpirationDate;
          this.profileUpdateDate = response.updatedDate;
          this.updatedBy = response.updatedBy;
          this.phoneNumber = this.userProfile.phoneNumbers[0];

          this.userProfileGeneralInfoChanged = false;
        },
        error => {
          const errorMessage: string = `Error getting User Profile: ${error}`;
          this.notificationService.errorMsg(errorMessage);
          this.logger.error(errorMessage);
        }
      );
  }

  ngOnInit() {
  }


  ngOnChanges(changes: SimpleChanges): void {
    if (!changes) { // revert
      this.userProfileEditGenInfoForm.reset({
        profileNameControl: this.userProfile.profileName,
        firstNameControl: this.userProfile.firstName,
        lastNameControl: this.userProfile.lastName,
        emailControl: this.userProfile.email,
        firstPhoneNumberControl: this.userProfile.phoneNumbers[0].value
      });
    }
  }

  public revert() {
    this.ngOnChanges(null);
  }

  public onSubmit() {
    this.updateUserProfile();
    this.saveProfile();
  }

  private saveProfile() {
    this.logger.debug('saving the profile');
    this.profileApiService.updateMyProfileInfo(this.userProfile).subscribe((uProfile) => {
      this.userProfile = {...uProfile};
      this.loginService.updateCurrentUser(this.userProfile);
      this.notificationService.successMsg('Profile Updated');
      this.userProfileGeneralInfoChanged = false;
    });
  }

  private updateUserProfile()  {

    const model = this.userProfileEditGenInfoForm.value;

    this.phoneNumber.value =  model.firstPhoneNumberControl as string;
    this.userProfile.phoneNumbers = this.userProfile.phoneNumbers.splice(0, 1, this.phoneNumber);

    this.userProfile.profileName = model.profileNameControl as string;
    this.userProfile.firstName = model.firstNameControl as string;
    this.userProfile.lastName = model.lastNameControl as string;
    this.userProfile.email = model.emailControl as string;

  }

  private goToUserProfileView(): void {
    this.navigationService.navigateRelativeTo(this.router, StateConstants.USER_PROFILE, this.activatedRoute);
    // this.router.navigate(StateConstants.createRelativeChildLink(StateConstants.USER_PROFILE), {relativeTo: this.activatedRoute});
  }


}
