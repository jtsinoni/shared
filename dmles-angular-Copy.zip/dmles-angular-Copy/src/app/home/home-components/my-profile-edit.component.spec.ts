import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyProfileEditComponent } from './my-profile-edit.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {PipesModule} from '../../pipes/pipes.module';
import {LoggerService} from '../../services/logger/logger.service';
import {LoginService} from '../../services/login.service';
import {RouterTestingModule} from '@angular/router/testing';
import {ProfileService} from '../../services/profile.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';
import {MainNavService} from '../main-nav/main-nav.service';
import {NotificationService} from '../../services/notification.service';
import {ToastrModule, ToastrService} from 'ngx-toastr';
import {NavigationService} from '../../services/navigation.service';
import {PermissionService} from '../../services/permission.service';

describe('MyProfileEditComponent', () => {
  let component: MyProfileEditComponent;
  let fixture: ComponentFixture<MyProfileEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, PipesModule, RouterTestingModule, HttpTestModule.forRoot(),
        ToastrModule.forRoot()],
      declarations: [ MyProfileEditComponent ],
      providers: [LoggerService, LoginService, ProfileService, ProfileApiService,
        MainNavService, NotificationService, ToastrService, NavigationService, PermissionService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyProfileEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
