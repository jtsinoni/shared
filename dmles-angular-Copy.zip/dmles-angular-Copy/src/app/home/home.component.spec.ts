import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import {RouterTestingModule} from '@angular/router/testing';
import {HomeHeaderComponent} from './home-header/home-header.component';
import {HomeFooterComponent} from './home-footer/home-footer.component';
import {ProfileApiService} from '../services/profile-api.service';
import {HttpTestModule} from '../common-components/test/http-test.module';
import {ToastrModule} from 'ngx-toastr';
import {PipesModule} from '../pipes/pipes.module';
import {BreadcrumbComponent} from '../common-components/breadcrumb/breadcrumb.component';
import {MainNavService} from './main-nav/main-nav.service';
import {LoginService} from '../services/login.service';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, PipesModule, ToastrModule.forRoot(), HttpTestModule.forRoot()],
      declarations: [ HomeComponent, HomeHeaderComponent, HomeFooterComponent, BreadcrumbComponent],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [ProfileApiService, MainNavService, LoginService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // TODO fix this test
  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
