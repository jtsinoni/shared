import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {NavigationService} from '../../services/navigation.service';
import {RouteConstants} from "../../constants/route.constants";
import {InventoryComponent} from './inventory.component';

const inventoryRoutes: Routes = [
  {
    path: '',
    component: InventoryComponent,
    canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.INVENTORY.breadcrumb},
    children: [
      {
        path: RouteConstants.INVENTORY_SEARCH.route,
        loadChildren: 'app/home/inventory/inventory-search/inventory-search.module#InventorySearchModule',
      },
    ]
  },
  {
    path: '',
    redirectTo: RouteConstants.INVENTORY.route
  }
];

@NgModule({
  imports: [RouterModule.forChild(inventoryRoutes)],
  exports: [RouterModule]
})
export class InventoryRoutingModule {
}
