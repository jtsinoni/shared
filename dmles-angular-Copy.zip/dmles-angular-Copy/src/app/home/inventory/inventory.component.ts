import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {LoggerService} from '../../services/logger/logger.service';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html'
})
export class InventoryComponent implements OnInit {

  constructor(private activatedRoute: ActivatedRoute,
              private logger: LoggerService,
              private router: Router) {
  }

  ngOnInit() {
  }

}
