import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {CommonComponentsModule} from '../../common-components/common-components.module';

import {InventoryRoutingModule} from './inventory-routing.module';
import {InventoryComponent} from './inventory.component';
import {InventorySearchModule} from './inventory-search/inventory-search.module';
import {InventoryService} from './services/inventory.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
    InventorySearchModule,
    InventoryRoutingModule
  ],
  declarations: [
    InventoryComponent
  ],
  exports: [
    InventorySearchModule
  ],
  providers: [
    InventoryService
  ]
})
export class InventoryModule {
}
