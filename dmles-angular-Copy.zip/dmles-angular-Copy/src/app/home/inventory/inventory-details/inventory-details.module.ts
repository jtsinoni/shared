import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {CommonComponentsModule} from '../../../common-components/common-components.module';

import {InventoryDetailsComponent} from './inventory-details.component';
import {InventoryDetailsRoutingModule} from './inventory-details-routing.module';
import {InventoryItemEditModule} from '../inventory-item-edit/inventory-item-edit.module';
import {InventoryService} from "../services/inventory.service";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule,
    InventoryDetailsRoutingModule,
    InventoryItemEditModule
  ],
  declarations: [
    InventoryDetailsComponent
  ],
  exports: [
    InventoryDetailsComponent,
    InventoryDetailsRoutingModule
  ],
  providers: [
    InventoryService
  ]
})
export class InventoryDetailsModule {
}
