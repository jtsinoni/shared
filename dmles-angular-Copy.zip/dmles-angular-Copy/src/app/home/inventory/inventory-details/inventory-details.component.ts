import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {RouteConstants} from '../../../constants/route.constants';
import {LoggerService} from '../../../services/logger/logger.service';

import {ActivatedRoute} from '@angular/router';
import {Location} from '@angular/common';
import {NavigationService} from '../../../services/navigation.service';

import {InventoryService} from '../services/inventory.service';
import {InventoryRecord} from '../models/inventory-record.model';

@Component({
  selector: 'app-inventory-details',
  templateUrl: './inventory-details.component.html',
  styleUrls: ['./inventory-details.component.scss']
})
export class InventoryDetailsComponent implements OnInit {
  private componentName: string = 'Inventory Details Component';
  inventoryRecord: InventoryRecord;

  productImagePath: string = '/assets/images/imageNotAvailable.jpg';

  locations: any[] = [
    {
      'id': '1',
      'orgName': 'W33BRA-LOG',
      'locName': 'Location 1',
      'locType': 'Standard',
      'storageArea': 'ST-DAA01-001',
      'locResale': 'No',
      'locCount': '200',
      'locLevelQty': '10',
      'locRopQty': '5',
      'locActive': 'Active',
    },
    {
      'id': '2',
      'orgName': 'W33BRA-LOG',
      'locName': 'Location 2',
      'locType': 'POU',
      'storageArea': 'ST-DAA01-001',
      'locResale': 'No',
      'locCount': '12',
      'locLevelQty': '50',
      'locRopQty': '25',
      'locActive': 'Active',
    },
    {
      'id': '3',
      'orgName': 'W33BRA-LOG',
      'locName': 'Location 3',
      'locType': 'Standard',
      'storageArea': 'ST-DAA01-001',
      'locResale': 'Yes',
      'locCount': '120',
      'locLevelQty': '70',
      'locRopQty': '20',
      'locActive': 'Active',
    }
  ];

  constructor(private router: Router, private logger: LoggerService,
              private activatedRoute: ActivatedRoute, private navigationService: NavigationService,
              private inventoryService: InventoryService, private location: Location) {
    this.logger.info(`${this.componentName} - Start`);
  }

  ngOnInit() {
    this.getInventoryRecord();
  }

  getInventoryRecord(): void {
    const selectedInventoryRecord: InventoryRecord = this.inventoryService.getSelectedInventoryRecord();
      this.inventoryService.getInventoryRecord(selectedInventoryRecord.itemId)
        .subscribe(inventoryRecord => this.inventoryRecord = inventoryRecord);
  }

  goBack(): void {
    this.location.back();
  }

  public goToEditInventoryItem(): void {
    this.navigationService.navigateRelativeTo(this.router, RouteConstants.INVENTORY_ITEM_EDIT.route, this.activatedRoute);
  }
}
