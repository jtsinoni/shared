import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {RouteConstants} from "../../../constants/route.constants";
import {NavigationService} from '../../../services/navigation.service';
import {InventoryDetailsComponent} from "./inventory-details.component";
import {InventoryItemEditComponent} from "../inventory-item-edit/inventory-item-edit.component";

const inventoryDetailsRoutes: Routes = [
  {
    path: '',
    component: InventoryDetailsComponent,
    data: {breadcrumb: RouteConstants.INVENTORY_DETAILS.breadcrumb},
    canActivate: [NavigationService]
    /***,
     children: [
     {
       path: RouteConstants.INVENTORY_ITEM_EDIT.route,
       loadChildren: 'app/home/inventory/inventory-item-edit/inventory-item-edit.module#InventoryItemEditModule',
     },
     ]
     ****/
  },
  {
    path: RouteConstants.INVENTORY_ITEM_EDIT.route,
    component: InventoryItemEditComponent,
    canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.INVENTORY_ITEM_EDIT.breadcrumb},
  },

  {
    path: '',
    redirectTo: RouteConstants.INVENTORY_DETAILS.route
  }
];

@NgModule({
  imports: [RouterModule.forChild(inventoryDetailsRoutes)],
  exports: [RouterModule]
})
export class InventoryDetailsRoutingModule {
}
