import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {CommonComponentsModule} from '../../../common-components/common-components.module';

import {InventoryItemEditComponent} from './inventory-item-edit.component';
import {InventoryItemEditRoutingModule} from './inventory-item-edit-routing.module';
import {InventoryService} from "../services/inventory.service";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule
  ],
  declarations: [
    InventoryItemEditComponent
  ],
  exports: [
    InventoryItemEditComponent,
    InventoryItemEditRoutingModule
  ],
  providers: [
    InventoryService
  ]
})
export class InventoryItemEditModule {
}
