import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InventoryItemEditComponent } from './inventory-item-edit.component';
import {APP_BASE_HREF, Location, LocationStrategy, PathLocationStrategy} from '@angular/common';

describe('InventoryItemEditComponent', () => {
  let component: InventoryItemEditComponent;
  let fixture: ComponentFixture<InventoryItemEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InventoryItemEditComponent ],
      providers: [Location, { provide: LocationStrategy, useClass: PathLocationStrategy },
        { provide: APP_BASE_HREF, useValue: '/app'}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InventoryItemEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
