import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {RouteConstants} from "../../../constants/route.constants";
import {NavigationService} from '../../../services/navigation.service';
import {InventoryItemEditComponent} from "./inventory-item-edit.component";

const inventoryItemEditRoutes: Routes = [
  {
    path: '',
    component: InventoryItemEditComponent,
    data: {breadcrumb: RouteConstants.INVENTORY_ITEM_EDIT.breadcrumb},
    canActivate: [NavigationService]
  },
  {
    path: '',
    redirectTo: RouteConstants.INVENTORY_ITEM_EDIT.route
  }
];

@NgModule({
  imports: [RouterModule.forChild(inventoryItemEditRoutes)],
  exports: [RouterModule]
})
export class InventoryItemEditRoutingModule {
}
