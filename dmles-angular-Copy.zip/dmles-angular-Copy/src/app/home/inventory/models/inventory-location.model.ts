/* not quite ready for primetime yet
export class InventoryLocation {
  storageLocationId: string;
  inventoryRecordId: string;
  storageLocationRefId: string;
  locationReorderPointQty: number;
  locationLevelQty: number;
  locationLevelType: string;
  locationLevelMethod: string;
  locationIsResellable: boolean;
  locationIsFreeIssue: boolean;
  isFrozenLocation: boolean;
  physicalBalanceDifferenceQty: number;
  inPutQty: number;
  lastAuditDate: any;
  storageRecords: any[];
}
*/

/* From PL's PT code inventoryRecordView.controller.ts
 private getData(): void {
 this.locationData = [
 {
 "id" : "1",
 "orgName" : "W33BRA-LOG",
 "locName" : "Location 1",
 "locType" : "Standard",
 "storageArea" : "ST-DAA01-001",
 "locResale" : "No",
 "locCount" : "200",
 "locLevelQty" : "10",
 "locRopQty" : "5",
 "locActive" : "Active"
 },
 {
 "id" : "2",
 "orgName" : "W33BRA-LOG",
 "locName" : "Location 2",
 "locType" : "POU",
 "storageArea" : "ST-DAA01-001",
 "locResale" : "No",
 "locCount" : "12",
 "locLevelQty" : "50",
 "locRopQty" : "25",
 "locActive" : "Active"
 },
 {
 "id" : "3",
 "orgName" : "W33BRA-LOG",
 "locName" : "Location 3",
 "locType" : "Standard",
 "storageArea" : "ST-DAA01-001",
 "locResale" : "Yes",
 "locCount" : "120",
 "locLevelQty" : "70",
 "locRopQty" : "20",
 "locActive" : "Active"
 }
 ];
 }
 */
