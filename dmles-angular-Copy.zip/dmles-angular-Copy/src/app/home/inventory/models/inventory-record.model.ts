export class InventoryRecord {
  customer: string;
  itemDescription: string;
  longItemDescription: string;
  itemId: number;
  unitOfSalePrice: number;
  unitOfSaleQuantity: number;
  unitOfSale: string;
  defaultLocation: string;
  estimatedOnHand: number;
  critical: boolean;
  deleted: boolean;
}

/* not quite ready for primetime yet - this is what comes back in PL's code currently
export class InventoryRecord {
  id: string;
  orgNodeRefId: string;
  orgName: string;
  itemId: string;
  localName: string;
  shortItemDesc: string;
  longItemDesc: string;
  unitOfInventory: string;
  unitOfInventoryPrice: number;
  unitOfInventoryQty: number;
  queuedForPutQty: number;
  queuedForPickQty: number;
  isCriticalItem: boolean;
  estimatedMonthlyUsageQty: number;
  maximumReleaseQty: number;
  defaultReorderPointQty: number;
  defaultLevelQty: number;
  defaultLevelType: string;
  defaultLevelMethod: string;
  defaultIsResellable: boolean;
  defaultIsFreeIssue: boolean;
  inventoryLocations: any[];
}
*/
