/* not quite ready for primetime yet
export class InventoryStorageRecord {
  storageRecordId: string;
  storageLocationId: string;
  stratificationState: any;
  onHandBalanceQty: number;
  inPickQty: number;
  lotSerialNbr: string;
  expirationDate: any;
  revisedExpirationDate: any;
  manufacturer: string;
  manufacturerDate: any;
  manufacturerPartNbr: string;
}
*/
