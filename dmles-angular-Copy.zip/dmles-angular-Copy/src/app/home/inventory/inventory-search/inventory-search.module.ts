import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {Ng2SmartTableModule} from 'ng2-smart-table';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {AgGridModule} from 'ag-grid-angular';
import {PipesModule} from '../../../pipes/pipes.module';
import {CommonComponentsModule} from '../../../common-components/common-components.module';
import {LcTableModule} from '../../../common-components/lc-table/lc-table.module';

import {InventorySearchComponent, LinkEmitRowComponent} from './inventory-search.component';
import {InventorySearchRoutingModule} from './inventory-search-routing.module';
import {InventoryDetailsModule} from '../inventory-details/inventory-details.module';
import {InventoryItemAddModule} from '../inventory-item-add/inventory-item-add.module';
import {InventoryItemEditModule} from '../inventory-item-edit/inventory-item-edit.module';
import {InventoryService} from "../services/inventory.service";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LcTableModule,
    Ng2SmartTableModule,
    NgxDatatableModule,
    AgGridModule.withComponents([/*optional Angular Components to be used in the grid*/]),
    PipesModule,
    CommonComponentsModule,
    InventorySearchRoutingModule,
    InventoryDetailsModule,
    InventoryItemAddModule,
    InventoryItemEditModule
  ],
  entryComponents: [
    InventorySearchComponent,
    LinkEmitRowComponent
  ],
  declarations: [
    InventorySearchComponent,
    LinkEmitRowComponent
  ],
  exports: [
    InventorySearchComponent,
    InventorySearchRoutingModule
  ],
  providers: [
    InventoryService
  ]
})
export class InventorySearchModule {
}
