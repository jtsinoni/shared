import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InventorySearchComponent } from './inventory-search.component';
import {CommonComponentsModule} from '../../../common-components/common-components.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {LcTableSettings} from '../../../common-components/lc-table/models/lc-table-settings';
import {LcTableModule} from '../../../common-components/lc-table/lc-table.module';
import {Ng2SmartTableModule} from 'ng2-smart-table';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {PipesModule} from '../../../pipes/pipes.module';
import {AgGridModule} from 'ag-grid-angular';
import {RouterTestingModule} from '@angular/router/testing';
import {NavigationService} from '../../../services/navigation.service';
import {PermissionService} from '../../../services/permission.service';
import {ProfileApiService} from '../../../services/profile-api.service';
import {HttpTestModule} from '../../../common-components/test/http-test.module';
import {SidePanelService} from '../../../services/side-panel.service';
import {InventoryService} from '../services/inventory.service';

describe('InventorySearchComponent', () => {
  let component: InventorySearchComponent;
  let fixture: ComponentFixture<InventorySearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonComponentsModule, FormsModule, ReactiveFormsModule, LcTableModule, Ng2SmartTableModule,
        NgxDatatableModule, PipesModule, AgGridModule, RouterTestingModule, HttpTestModule.forRoot()],
      declarations: [ InventorySearchComponent ],
      providers: [NavigationService, PermissionService, ProfileApiService, SidePanelService, InventoryService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InventorySearchComponent);
    component = fixture.componentInstance;
    component.lcTableColumns = {};
    component.lcTableSettings = new LcTableSettings();
    // component.lcTableData = [];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
