import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {RouteConstants} from "../../../constants/route.constants";
import {NavigationService} from '../../../services/navigation.service';
import {InventorySearchComponent} from './inventory-search.component';
import {InventoryItemAddComponent} from "../inventory-item-add/inventory-item-add.component";
import {InventoryDetailsComponent} from "../inventory-details/inventory-details.component";

const inventorySearchRoutes: Routes = [
  {
    path: '',
    component: InventorySearchComponent,
    canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.INVENTORY_SEARCH.breadcrumb}
    /***,
     children: [
     {
       path: RouteConstants.INVENTORY_DETAILS.route,
       loadChildren: 'app/home/inventory/inventory-details/inventory-details.module#InventoryDetailsModule',
     },
     {
       path: RouteConstants.INVENTORY_ITEM_ADD.route,
       component: InventoryItemAddComponent,
       data: {breadcrumb: RouteConstants.INVENTORY_ITEM_ADD.breadcrumb},
       canActivate: [NavigationService]
     },
     ]
     ****/
  },
  {
    path: RouteConstants.INVENTORY_DETAILS.route,
    component: InventoryDetailsComponent,
    canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.INVENTORY_DETAILS.breadcrumb}
  },
  {
    path: RouteConstants.INVENTORY_ITEM_ADD.route,
    component: InventoryItemAddComponent,
    canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.INVENTORY_ITEM_ADD.breadcrumb}
  },

  {
    path: '',
    redirectTo: RouteConstants.INVENTORY_SEARCH.route
  }
];

@NgModule({
  imports: [RouterModule.forChild(inventorySearchRoutes)],
  exports: [RouterModule]
})
export class InventorySearchRoutingModule {
}
