import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {Router} from '@angular/router';
import {RouteConstants} from '../../../constants/route.constants';
import {ActivatedRoute} from '@angular/router';
import {NavigationService} from '../../../services/navigation.service';

import {LoggerService} from '../../../services/logger/logger.service';
import {GridOptions} from 'ag-grid/main';
import {InventoryRecord} from '../models/inventory-record.model';
import {InventoryService} from '../services/inventory.service';

import {LcTableSettings} from '../../../common-components/lc-table/models/lc-table-settings';
import {LcTableColumn} from '../../../common-components/lc-table/models/lc-table-column';
import {ViewCell} from 'ng2-smart-table';
import {LcLinkCellComponent} from '../../../common-components/lc-table/lc-link-cell/lc-link-cell.component';

import { SidePanelService } from '../../../services/side-panel.service';



///// LinkEmitRowComponent used in ng2-smart-table /////////////
@Component({
  selector: 'link-emit-row',
  template: `<a href="javascript:void(0);" (click)="onClick()">{{ renderValue }}</a>`,
})
export class LinkEmitRowComponent implements ViewCell, OnInit {
  renderValue: string;

  @Input() value: string | number;
  @Input() rowData: any;

  @Output() cellSelected: EventEmitter<any> = new EventEmitter();

  constructor(private logger: LoggerService) {
  }

  ngOnInit() {
    this.renderValue = this.value.toString().toUpperCase();
    // this.logger.debug(`LinkEmitRowComponent ngOnInit this.renderValue = ${JSON.stringify(this.renderValue)}`);
  }

  onClick() {
    this.logger.debug(`LinkEmitRowComponent onClick this.rowData = ${JSON.stringify(this.rowData)}`);
    this.cellSelected.emit(this.rowData);
  }
}

///////////////////////////////////////////////////////////////////////////
@Component({
  selector: 'app-inventory-search',
  templateUrl: './inventory-search.component.html',
  styleUrls: ['./inventory-search.component.scss']
})
export class InventorySearchComponent implements OnInit {
  private componentName: string = 'Inventory Search Component';
  private tableTitle: string = 'Inventory Records';

  searchInput: string = '';
  searchButtonClicked: boolean = false;

  inventoryRecords: InventoryRecord[];

  // used by ng2-smart-table
  public lcTableColumns: any;
  public lcTableSettings: LcTableSettings;

  settings = {
    actions: {
      columnTitle: '',
      add: false,
      edit: false,
      delete: false
    },
    columns: {
      customer: {
        title: 'Customer',
        editable: false
      },
      itemDescription: {
        title: 'Item Description',
        editable: false
      },
      itemId: {
        title: 'Item ID',
        type: 'custom',
        renderComponent: LinkEmitRowComponent,
        onComponentInitFunction: (instance) => {
          instance.cellSelected.subscribe(row => {
            this.goToDetailsFromNgx(row);
          });
        },
        editable: false
      },
      unitOfSalePrice: {
        title: 'Unit of Sale Price',
        editable: false
      },
      unitOfSale: {
        title: 'Unit of Sale',
        editable: false
      },
      defaultLocation: {
        title: 'Default Location',
        editable: false
      },
      estimatedOnHand: {
        title: 'Estimated On-Hand (All Locations)',
        editable: false
      },
      critical: {
        title: 'Critical',
        editable: false
      },
      deleted: {
        title: 'Deleted',
        editable: false
      }
    }
  };

  // used by ngx-datatable
  // public rows: Array<InventoryRecord> = [];
  private temp: Array<InventoryRecord> = [];

  public columns: Array<any> = [
    // {title: 'id', name: 'id'},
    {name: 'Customer', prop: 'customer'},
    {name: 'Item Description', prop: 'itemDescription'},
    {name: 'Item ID', prop: 'itemId'},
    {name: 'Unit of Sale Price', prop: 'unitOfSalePrice'},
    {name: 'Unit of Sale', prop: 'unitOfSale'},
    {name: 'Default Location', prop: 'defaultLocation'},
    {name: 'Estimated On-Hand (All Locations)', prop: 'estimatedOnHand'},
    {name: 'Critical', prop: 'critical'},
    {name: 'Deleted', prop: 'deleted'}
  ];
  public reorderable: boolean = true; // sets if the columns can be reordered
  public length: number = 0;

  // used by ag-grid
  gridOptions: GridOptions = {
    floatingFilter: true
  };

  columnDefs: any[] = [
    {headerName: 'Customer', field: 'customer', filter: 'agTextColumnFilter'},
    {headerName: 'Item Description', field: 'itemDescription', filter: 'agTextColumnFilter'},
    {headerName: 'Item ID', field: 'itemId', filter: 'agTextColumnFilter', cellClass: 'btn btn-link btn-link-text'},
    {headerName: 'Unit of Sale Price', field: 'unitOfSalePrice', type: 'numericColumn', filter: 'agNumberColumnFilter'},
    {headerName: 'Unit of Sale', field: 'unitOfSale', filter: 'agTextColumnFilter'},
    {headerName: 'Default Location', field: 'defaultLocation', filter: 'agTextColumnFilter'},
    {
      headerName: 'Estimated On-Hand (All Locations)',
      field: 'estimatedOnHand',
      type: 'numericColumn',
      filter: 'agNumberColumnFilter'
    },
    {headerName: 'Critical', field: 'critical', suppressFilter: true},
    {headerName: 'Deleted', field: 'deleted', suppressFilter: true},
  ];

  constructor(private router: Router, private logger: LoggerService,
              private activatedRoute: ActivatedRoute, private navigationService: NavigationService,
              public sidePanelService: SidePanelService, private inventoryService: InventoryService) {
    this.logger.info(`${this.componentName} - Start`);
  }

  ngOnInit() {
    // set up for lc-table
    this.setTableSettings();

    // see if the searchInput string has been saved and, if so, restore it
    this.searchInput = this.inventoryService.getSavedSearchInput();
    if (this.searchInput.length > 0) {
      this.searchButtonClicked = true;
      this.getInventoryRecords();
    }
  }

  clearSearchInput() {
    this.searchInput = '';
    this.searchButtonClicked = false;
  }

  createInventoryItem() {
    this.logger.info(`${this.componentName} - Create Inventory Item`);
  }

  getInventoryRecords(): void {
    this.inventoryService.getInventoryRecords()
      .subscribe(inventoryRecords => this.inventoryRecords = inventoryRecords);
    this.temp = this.inventoryRecords;
  }

  public goToAddInventoryItem(): void {
    this.navigationService.navigateRelativeTo(this.router, RouteConstants.INVENTORY_ITEM_ADD.route, this.activatedRoute);
  }

  goToDetails(event: any) {
    this.logger.debug(`rec = ${JSON.stringify(event.data)}`);
    this.inventoryService.setSelectedInventoryRecord(event.data);
    this.navigationService.navigateRelativeTo(this.router, RouteConstants.INVENTORY_DETAILS.route, this.activatedRoute);
  }

  goToDetailsFromNgx(row) {
    // this.logger.debug(`rec = ${JSON.stringify(event.data)}`);
    this.inventoryService.setSelectedInventoryRecord(row);
    this.navigationService.navigateRelativeTo(this.router, RouteConstants.INVENTORY_DETAILS.route, this.activatedRoute);
  }

  private onCellClicked(event) {
    this.logger.debug(`onCellClicked = ${JSON.stringify(event.colDef)}`);
    if (event.colDef.field === 'itemId') {
      this.goToDetails(event);
    }
  }

  private lcOnRefresh(refresh: string) {
    this.logger.debug(`refreshClick > ${refresh}`);
  }

  public onGridReady(params) {
    params.api.sizeColumnsToFit();
  }

  public onModelUpdated() {
  }

  public selectAllRows() {
    this.gridOptions.api.selectAll();
  }

  public onSearch(event: any) {

    const query = event.target.value;
    this.logger.debug('what is query: ' + query);

    if (query && query.length > 0) {
      const val = query.toLowerCase();
      this.logger.debug('what is val: ' + val);

      // filter data by name prop
      this.inventoryRecords = this.temp;
      const result = this.inventoryRecords.filter(function (d) {
        return d.customer.toLowerCase().indexOf(val) !== -1 ||
          d.itemDescription.toLowerCase().indexOf(val) !== -1 ||
          d.itemId.toString().toLowerCase().indexOf(val) !== -1 || !val;
      });

      this.logger.debug('what is result length: ' + result.length);

      // update the rows
      this.inventoryRecords = result;
      // Whenever the filter changes, always go back to the first page
      // this.table.offset = 0; // could not get this to work - gets an error here even when including #table
    } else {
      this.logger.debug('resetting inventoryRecords length of temp: ' + this.temp.length);
      this.inventoryRecords = this.temp;
    }
  }

  public onSubmit() {
    this.inventoryService.setSavedSearchInput(this.searchInput);
    this.searchButtonClicked = true;
    this.getInventoryRecords();
  }

  private setTableSettings() {

    // initialize the variables needed by lc-table (wrapped ng2-smart-table)
    this.lcTableSettings = new LcTableSettings();
    this.lcTableSettings.cardId = 'inventoryLcTable';
    this.lcTableSettings.cardTitle = 'Inventory Records';
    this.lcTableSettings.cardTitleIcon = 'fa fa-cubes';
    this.lcTableSettings.tableAttr.id = 'inventoryLcTableAttr';

    this.lcTableSettings.cardShowDownload = true;
    this.lcTableSettings.cardShowGlobalSearch = false;
    this.lcTableSettings.cardShowRefresh = true;

    this.lcTableSettings.tableHideSubHeader = false;

    // columns that need to use a render component
    const itemIdColumn: LcTableColumn = new LcTableColumn();
    itemIdColumn.title = 'Item Description';
    itemIdColumn.type = 'custom';
    itemIdColumn.renderComponent = LcLinkCellComponent;
    itemIdColumn.onComponentInitFunction = (instance) => {
      instance.cellSelected.subscribe(row => {
        this.goToDetailsFromNgx(row);
      });
    };

    /****
     itemId: {
      title: 'Item ID',
        type: 'custom',
        renderComponent: LinkViewComponent,
        onComponentInitFunction: (instance) => {
        instance.save.subscribe(row => {
          this.goToDetailsFromNgx(row);
        });
      },
        editable: false
    },
     ****/

    this.lcTableColumns = {
      customer: new LcTableColumn('Customer'),
      itemDescription: new LcTableColumn('Item Description'),
      itemId: itemIdColumn,
      unitOfSalePrice: new LcTableColumn('Unit of Sale Price'),
      unitOfSale: new LcTableColumn('Unit of Sale'),
      defaultLocation: new LcTableColumn('Default Location'),
      estimatedOnHand: new LcTableColumn('Estimated On-Hand (All Locations)'),
      critical: new LcTableColumn('Critical'),
      deleted: new LcTableColumn('Deleted'),
    };
  }
}

