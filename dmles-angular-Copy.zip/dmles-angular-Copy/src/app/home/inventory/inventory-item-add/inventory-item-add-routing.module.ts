import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {RouteConstants} from "../../../constants/route.constants";
import {NavigationService} from '../../../services/navigation.service';
import {InventoryItemAddComponent} from "./inventory-item-add.component";

const inventoryItemAddRoutes: Routes = [
  {
    path: '',
    component: InventoryItemAddComponent,
    data: {breadcrumb: RouteConstants.INVENTORY_ITEM_ADD.breadcrumb},
    canActivate: [NavigationService]
  },
  {
    path: '',
    redirectTo: RouteConstants.INVENTORY_ITEM_ADD.route
  }
];

@NgModule({
  imports: [RouterModule.forChild(inventoryItemAddRoutes)],
  exports: [RouterModule]
})
export class InventoryItemAddRoutingModule {
}
