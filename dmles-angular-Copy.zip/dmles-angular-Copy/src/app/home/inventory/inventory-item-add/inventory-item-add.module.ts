import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';

import {CommonComponentsModule} from '../../../common-components/common-components.module';

import {InventoryItemAddComponent} from './inventory-item-add.component';
import {InventoryItemAddRoutingModule} from './inventory-item-add-routing.module';
import {InventoryService} from '../services/inventory.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CommonComponentsModule
  ],
  declarations: [
    InventoryItemAddComponent
  ],
  exports: [
    InventoryItemAddComponent,
    InventoryItemAddRoutingModule
  ],
  providers: [
    InventoryService
  ]
})
export class InventoryItemAddModule {
}
