import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InventoryItemAddComponent } from './inventory-item-add.component';
import {APP_BASE_HREF, Location, LocationStrategy, PathLocationStrategy} from '@angular/common';

describe('InventoryItemAddComponent', () => {
  let component: InventoryItemAddComponent;
  let fixture: ComponentFixture<InventoryItemAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InventoryItemAddComponent ],
      providers: [Location, { provide: LocationStrategy, useClass: PathLocationStrategy },
        { provide: APP_BASE_HREF, useValue: '/app'}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InventoryItemAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
