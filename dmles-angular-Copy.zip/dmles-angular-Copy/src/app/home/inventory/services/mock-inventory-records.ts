import {InventoryRecord} from '../models/inventory-record.model';

export const INVENTORY_RECORDS: InventoryRecord[] = [
  {
    customer: 'W33DME-LOG',
    itemDescription: 'Adhes Tape 12inx5 Yds Moleskin',
    longItemDescription: 'Padding Cast Or Splint Moleskin 1/16in Thick 9inw 4ydl Self-Adhesive Back',
    itemId: 551457,
    unitOfSalePrice: 34.17,
    unitOfSaleQuantity: 1,
    unitOfSale: 'Each (EA)',
    defaultLocation: '',
    estimatedOnHand: 0,
    critical: false,
    deleted: false
  },
  {
    customer: 'W33DME-LOG',
    itemDescription: 'Tape Casting, 3m, Black',
    longItemDescription: 'Tape Cast Splint Fiberglass 2inw 4ydl',
    itemId: 651001285306,
    unitOfSalePrice: 2.06,
    unitOfSaleQuantity: 1,
    unitOfSale: 'Roll (RO)',
    defaultLocation: '',
    estimatedOnHand: 0,
    critical: true,
    deleted: false
  },
  {
    customer: 'W33DME-LOG',
    itemDescription: 'Tape Srg 1.5ydx1in 3M Sil Kind Rem Brthbl',
    longItemDescription: 'Tape Surgical 1.5ydx1in 3M Silicone Kind Removal Breathable Hypoallergenic Adhesive Roll Latex Free Disposable',
    itemId: 707387763633,
    unitOfSalePrice: 4.20,
    unitOfSaleQuantity: 1,
    unitOfSale: 'Roll (RO)',
    defaultLocation: '',
    estimatedOnHand: 0,
    critical: false,
    deleted: false
  }
];
