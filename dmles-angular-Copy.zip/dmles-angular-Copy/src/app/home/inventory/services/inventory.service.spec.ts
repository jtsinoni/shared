import { TestBed, inject } from '@angular/core/testing';

import { InventoryService } from './inventory.service';
import {LoggerService} from '../../../services/logger/logger.service';

describe('InventoryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InventoryService, LoggerService]
    });
  });

  it('should be created', inject([InventoryService], (service: InventoryService) => {
    expect(service).toBeTruthy();
  }));
});
