import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {of} from 'rxjs/observable/of';
import {InventoryRecord} from '../models/inventory-record.model';
import {INVENTORY_RECORDS} from './mock-inventory-records';
import {LoggerService} from '../../../services/logger/logger.service';

@Injectable()
export class InventoryService {

  private savedSearchInput: string = '';
  private selectedInventoryRecord: InventoryRecord;

  constructor(private logger: LoggerService) {
  }

  getSavedSearchInput(): string {
    return this.savedSearchInput;
  }

  setSavedSearchInput(value: string) {
    this.savedSearchInput = value;
  }

  getSelectedInventoryRecord(): InventoryRecord {
    return this.selectedInventoryRecord;
  }

  setSelectedInventoryRecord(value: InventoryRecord) {
    this.selectedInventoryRecord = value;
    // this.logger.debug(`saved this.selectedInventoryRecord = ${JSON.stringify(this.selectedInventoryRecord)}`);
  }

  getInventoryRecords(): Observable<InventoryRecord[]> {
    return of(INVENTORY_RECORDS);
  }

  getInventoryRecord(id: number): Observable<InventoryRecord> {
    return of(INVENTORY_RECORDS.find(inventoryRecord => inventoryRecord.itemId === id));
  }
}
