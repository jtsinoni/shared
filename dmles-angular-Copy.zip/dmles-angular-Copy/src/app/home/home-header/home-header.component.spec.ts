import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeHeaderComponent } from './home-header.component';
import {RouterTestingModule} from '@angular/router/testing';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {PopoverModule} from 'ngx-bootstrap';
import {LoggerService} from '../../services/logger/logger.service';
import {CommonComponentsModule} from '../../common-components/common-components.module';
import {MainNavService} from '../main-nav/main-nav.service';
import {PipesModule} from '../../pipes/pipes.module';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpTestModule} from '../../common-components/test/http-test.module';
import {NotificationService} from '../../services/notification.service';
import {ToastrModule, ToastrService} from 'ngx-toastr';
import {PermissionService} from '../../services/permission.service';
import {NavigationService} from '../../services/navigation.service';


describe('HomeHeaderComponent', () => {
  let component: HomeHeaderComponent;
  let fixture: ComponentFixture<HomeHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [PopoverModule.forRoot(), RouterTestingModule, CommonComponentsModule, PipesModule,
        HttpTestModule.forRoot(), ToastrModule.forRoot()],
      declarations: [ HomeHeaderComponent],
      providers: [LoggerService, MainNavService, ProfileApiService, NotificationService, ToastrService,
        NavigationService, PermissionService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
