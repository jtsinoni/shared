import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {LoggerService} from '../../services/logger/logger.service';
import {StateConstants} from '../../constants/state.constants';
import {ProfileService} from '../../services/profile.service';
import {AuthenticationService} from '../../services/authentication.service';
import {NotificationService} from '../../services/notification.service';
import {NavigationService} from '../../services/navigation.service';
import {RouteConstants} from '../../constants/route.constants';

@Component({
  selector: 'app-home-header',
  templateUrl: './home-header.component.html',
  providers: [ProfileService, NotificationService]
})
export class HomeHeaderComponent implements OnInit {

  constructor(private logger: LoggerService,
              private profileService: ProfileService,
              private router: Router,
              private navigationService: NavigationService,
              private authenticationService: AuthenticationService,
              private notificationService: NotificationService) { }

  ngOnInit() {
    this.profileService.loadData();
  }

  // public changeAccess(newNodeId: string): void {
  //   this.logger.info('newNodeId: ' + newNodeId);
  //   this.navigationService.navigateFromHomeTo(this.router, StateConstants.LOADING);
  //   // this.profileService.changeAccess(newNodeId).subscribe(() => {
  //   //   this.navigationService.navigateFromHomeTo(this.router, StateConstants.MY_DASHBOARD);
  //   // });
  // }

  public changeAccess(newNodeId: string): void {
    this.logger.info('newNodeId: ' + newNodeId);
    this.profileService.changeAccess(true);
  }

  public changeProfile(newProfileId: string): void {
    this.navigationService.navigateFromHomeTo(this.router,  RouteConstants.LOADING.route);
    this.logger.info(`newProfileId: ${newProfileId}`);
    this.profileService.changeProfile2(newProfileId).subscribe(() => {
      this.navigationService.navigateFromHomeTo(this.router, RouteConstants.MY_DASHBOARD.route);
    });

  }

  // public changeProfile(newProfileId: string): void {
  //   this.logger.info('newProfileId: ' + newProfileId);
  //   this.profileService.changeProfile(true);
  // }

  public logout(): void {
    this.profileService.logOut().subscribe((data) => {
      if (data) {
        this.authenticationService.logout();
        this.navigationService.navigateDirectlyTo(this.router, StateConstants.LOGIN).then(() => {
          this.notificationService.successMsg('You have successfully logged out. Your connection has been terminated.',
            'Logged Out', {positionClass: 'toast-bottom-center'});
        });
      }
    });
  }

  public goToAbout(): void {
    this.navigationService.navigateDirectlyTo(this.router, StateConstants.HOME_ROOT + '/' + StateConstants.ABOUT);
  }

  public goToHelp(): void {
    this.navigationService.navigateDirectlyTo(this.router,  StateConstants.HOME_ROOT + '/' + StateConstants.HELP);
  }

  public goToUserProfile(): void {
    this.navigationService.navigateDirectlyTo(this.router,  StateConstants.HOME_ROOT + '/' + StateConstants.USER_PROFILE);
  }

}
