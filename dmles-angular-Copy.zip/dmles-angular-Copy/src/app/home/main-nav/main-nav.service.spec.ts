import {TestBed, inject} from '@angular/core/testing';

import {MainNavService} from './main-nav.service';
import {LoginService} from '../../services/login.service';
import {LoggerService} from '../../services/logger/logger.service';
import {UtilService} from '../../services/util.service';
import {ProfileApiService} from '../../services/profile-api.service';
import {HttpClient, HttpHandler} from '@angular/common/http';
import { StorageService } from '../../services/storage.service';
import { WindowService } from '../../services/window.service';
import { CurrencyPipe } from '@angular/common';
import { AuthenticationService } from '../../services/authentication.service';
import {RouterTestingModule} from '@angular/router/testing';


describe('MainNavService', () => {
  let http: HttpClient;
  let logger: LoggerService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoginService, LoggerService, MainNavService, UtilService,
                  ProfileApiService, HttpClient,  HttpHandler,  AuthenticationService,
                  StorageService, WindowService, UtilService, CurrencyPipe],
      imports: [RouterTestingModule],
    });
    http = TestBed.get(HttpClient);
    logger = TestBed.get(LoggerService);
  });

  it('should be created', inject([MainNavService], (service: MainNavService) => {
    expect(service).toBeTruthy();
  }));

  it('myNav items to be defined',
    inject([MainNavService], (service: MainNavService) => {
      expect(service.myNav).toBeDefined();
    }));
});
