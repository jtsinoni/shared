export interface IState {
  state: string;
}

export interface INavigationSelection {
  id: string;
  icon: string;
  perm: string;
  state: string;
  text: string;
  shown: boolean;
}

export class NavigationModel {
  public id: string;
  public active: boolean;
  public tooltip: string;
  public icon: string;
  public shown: boolean;
  public statesCovered: Array<IState>;
  navChoices: Array<INavigationSelection>;

}
