import { Injectable } from '@angular/core';
import {LoggerService} from '../../services/logger/logger.service';
import {LoginService} from '../../services/login.service';
import {ResourceConstants} from '../../constants/resource.constants';
import {StateConstants} from '../../constants/state.constants';
import {RouteConstants} from '../../constants/route.constants';
import {CurrentUserProfile} from '../../models/current-user-profile.model';
import {NavigationModel} from './navigation.model';

@Injectable()
export class MainNavService {

  private serviceName: string = 'MainNavService';
  private masterNav: Array<NavigationModel> = [];  // TODO: Move to MongoDB
  public myNav: Array<any> = [];
  private currUser: CurrentUserProfile;

  constructor(private logger: LoggerService, private loginService: LoginService) {
    this.logger.info('%s - Start', this.serviceName);
    this.setMasterNavData();

  }

  public loadMyNavPerRole() {
    this.myNav = this.masterNav.slice();
    this.currUser = this.loginService.currentUser;
    if (!this.currUser) {
      this.loginService.signIn().subscribe((data) => {
        this.currUser = {...data};
        this.setMainNavData();
      });
    } else {
      this.setMainNavData();
    }

  }

  private setMainNavData() {
    let mainNavCount: number = 0;

    Object.values(this.masterNav).forEach((mainNavItem, navKey) => {
      mainNavCount = 0;
      if (mainNavItem.navChoices) {
        Object.values(mainNavItem.navChoices).forEach((navMenuItem, menuKey) => {
          const perm = navMenuItem.perm;
          const isFound = this.currUser.elements.indexOf(perm) > -1;
          if (isFound) {
            mainNavCount = mainNavCount + 1;
          } else {
            this.myNav[navKey].navChoices[menuKey].shown = false;
          }
        });
      }
      if (0 === mainNavCount && 'dashboard' !== mainNavItem.id) {
        this.myNav[navKey].shown = false;
      }

    });
  }

  public activateMainNav(currentState: string): void {
    Object.values(this.myNav).forEach((nav: any) => {
      nav.active = false;
      Object.values(nav.statesCovered).forEach((navItem: any) => {
        if (navItem.state && currentState.indexOf(navItem.state) > -1) {
          nav.active = true;
        }
        // return nav.active;
      });
    });
  }


  public getMyNavItems() {
    // var deferred = this.$q.defer();
    this.loadMyNavPerRole();
    // deferred.resolve(this.myNav);
    // return deferred.promise;
  }

  private setMasterNavData () {
     // TODO: Move to MongoDB
     this.masterNav = [
       {
         'id': 'dashboard',
         'active': false,
         'tooltip': 'My Dashboard',
         'icon': 'fa fa-dashboard fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': StateConstants.MY_DASHBOARD}
         ],
         'navChoices': null
       },
       {
         'id': 'catalog',
         'active': false,
         'tooltip': 'Catalog',
         'icon': 'fa fa-search fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': StateConstants.ABI_SHELL}
         ],
         'navChoices': [
           {
             'id': 'abi',
             'icon': '',
             'perm': ResourceConstants.ABI,
             'state': StateConstants.ABI_SEARCH,
             'text': 'ABi Search',
             'shown': true
           }
         ]
       },
       {
         'id': 'equipment',
         'active': false,
         'tooltip': 'Equipment',
         'icon': 'fa fa-medkit fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': StateConstants.EQUIP_SHELL}
         ],
         'navChoices': [
           {   'id': 'equipmentRequest',
             'icon': '',
             'perm': ResourceConstants.EQUIP_REQUESTS_MY_REQUESTS,
             'state': StateConstants.EQUIP_REQUEST_MY_REQUESTS,
             'text': 'Equipment Request',
             'shown': true
           },
           {
             'id': 'equipmentRecord',
             'icon': '',
             'perm': ResourceConstants.EQUIP_RECORDS_VIEW,
             'state': StateConstants.EQUIP_RECORD_SEARCH,
             'text': 'Equipment Record',
             'shown': true
           }
         ]
       },
       {
         'id': 'access',
         'active': false,
         'tooltip': 'User and Role Administration',
         'icon': 'fa fa-group fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': RouteConstants.ACCESS.route}
         ],
         'navChoices': [
           {
             'id': 'users',
             'icon': '',
             'perm': ResourceConstants.USER_PROFILE_MANAGEMENT,
             'state': RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT.route,
             'text': 'User Profile Management',
             'shown': true
           },
           {
             'id': 'roles',
             'icon': '',
             'perm': ResourceConstants.ROLE_MANAGEMENT,
             'state': RouteConstants.ACCESS_ROLE_MANAGEMENT.route,
             'text': 'Role Management',
             'shown': true
           },
           {
             'id': 'permissions',
             'icon': '',
             'perm': ResourceConstants.PERMISSION_MANAGEMENT,
             'state': RouteConstants.ACCESS_PERMISSION_MANAGEMENT.route,
             'text': 'Permission Management',
             'shown': true
           }
         ]
       },
       {
         'id': 'organizationButton',
         'active': false,
         'tooltip': 'Organization View',
         'icon': 'fa fa-sitemap fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': StateConstants.ORG_SHELL}
         ],
         'navChoices': [
           {
             'id': 'manageOrg',
             'icon': '',
             'perm': ResourceConstants.ORGANIZATION_MANAGEMENT,
             'state': StateConstants.ORG_MNG,
             'text': 'Manage Organization',
             'shown': true
           },
           {
             'id': 'viewOrg',
             'icon': '',
             'perm': ResourceConstants.ORGANIZATION_VIEW,
             'state': StateConstants.ORG_VIEW,
             'text': 'View Organization',
             'shown': true
           }]
       },
       {
         'id': 'jmlfdcAdmin',
         'active': false,
         'tooltip': 'JMLFDC Administration',
         'icon': 'fa fa-gears fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': StateConstants.JMLFDC_ADMIN_SHELL},
           {'state': StateConstants.ABI_STAGING_SHELL }
         ],
         'navChoices': [
           {
             'id': 'manageVirtualItemMasterCatalog',
             'icon': '',
             'perm': ResourceConstants.MANAGE_ABI_STAGING,
             'state': StateConstants.ABI_STAGING_VIEW,
             'text': 'Manage ABi Staging',
             'shown': true
           },
           {
             'id': 'manageServiceProviders',
             'icon': '',
             'perm': ResourceConstants.MANAGE_SERVICE_PROVIDERS,
             'state': StateConstants.MANAGE_SERVICE_PROVIDERS,
             'text': 'Manage Service Providers',
             'shown': true
           },
           {
             'id': 'viewApplicationHistory',
             'icon': '',
             'perm': ResourceConstants.VIEW_APP_HISTORY,
             'state': StateConstants.APP_HISTORY_VIEW,
             'text': 'View Application History',
             'shown': true
           },
           {
             'id': 'equipmentTesting',
             'icon': '',
             'perm': ResourceConstants.EQUIPMENT_TESTING,
             'state': StateConstants.EQUIPMENT_TESTING,
             'text': 'Equipment Testing',
             'shown': true
           },
           {
             'id': 'viewSystemNotifications',
             'icon': '',
             'perm': ResourceConstants.VIEW_SYSTEM_NOTIFICATIONS,
             'state': StateConstants.JMLFDC_ADMIN_SHELL + '/' + StateConstants.NOTIFICATIONS_VIEW,
             'text': 'System Notifications',
             'shown': true
           }
         ]
       },
       {
         'id': 'coffee',
         'active': true,
         'tooltip': 'Coffee',
         'icon': 'fa fa-coffee fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': StateConstants.COFFEE}
         ],
         'navChoices': null
       },
       {
         'id': 'inventory',
         'active': true,
         'tooltip': 'Inventory',
         'icon': 'fa fa-cubes fa-2x',
         'shown': true,
         'statesCovered': [
           {'state': RouteConstants.INVENTORY.route}
         ],
         'navChoices': [
           {
             'id': 'inventorySearch',
             'icon': '',
             'perm': ResourceConstants.INVENTORY_MANAGEMENT,
             'state': RouteConstants.INVENTORY_SEARCH.route,
             'text': 'Inventory Search',
             'shown': true
           }
           ]
       }
     ];

   }


}
