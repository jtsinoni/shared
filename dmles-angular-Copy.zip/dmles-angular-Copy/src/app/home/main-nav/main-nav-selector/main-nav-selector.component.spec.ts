import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainNavSelectorComponent } from './main-nav-selector.component';
import {RouterTestingModule} from '@angular/router/testing';
import {LoggerService} from '../../../services/logger/logger.service';
import {TooltipModule} from 'ngx-bootstrap';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('MainNavSelectorComponent', () => {
  let component: MainNavSelectorComponent;
  let fixture: ComponentFixture<MainNavSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [RouterTestingModule, TooltipModule.forRoot()],
      declarations: [ MainNavSelectorComponent ],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainNavSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
