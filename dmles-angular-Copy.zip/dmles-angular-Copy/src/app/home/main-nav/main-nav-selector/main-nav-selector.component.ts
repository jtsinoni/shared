import {Component, Input, OnInit} from '@angular/core';
import {NavigationModel} from '../navigation.model';
import {Router} from '@angular/router';
import {LoggerService} from '../../../services/logger/logger.service';
import {NavigationService} from '../../../services/navigation.service';

@Component({
  selector: 'app-main-nav-selector',
  templateUrl: './main-nav-selector.component.html'
})
export class MainNavSelectorComponent implements OnInit {

  @Input() navigationModel: NavigationModel;

  constructor(private logger: LoggerService,
              private router: Router,
              private navigationService: NavigationService) {
  }

  ngOnInit() {
  }

  public goToSelection(state: string) {
    this.navigationService.navigateFromHomeTo(this.router, state);
  }


}
