import { Component, OnInit } from '@angular/core';
import {MainNavService} from './main-nav.service';
import {Router} from '@angular/router';
import {StateConstants} from '../../constants/state.constants';
import {LoggerService} from '../../services/logger/logger.service';
import {NavigationService} from '../../services/navigation.service';
import {RouteConstants, RouteInfo} from '../../constants/route.constants';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  providers: [MainNavService]
})
export class MainNavComponent implements OnInit {

  public routeConstants: RouteConstants = RouteConstants;

  constructor(public mainNavService: MainNavService,
              private router: Router,
              private logger: LoggerService,
              private navigationService: NavigationService) {
  }

  ngOnInit() {
    this.mainNavService.loadMyNavPerRole();
    this.mainNavService.activateMainNav(this.router.url);
  }

  public goToDashboard(): void {
    this.navigationService.navigateDirectlyTo(this.router, StateConstants.HOME_ROOT + '/' + StateConstants.MY_DASHBOARD);
  }

  public goToSystemNotifications(): void {
    // this.navigationService.navigateTo(this.router, StateConstants.JMLFDC_ADMIN_SHELL, StateConstants.NOTIFICATIONS_VIEW);
    this.navigationService.navigateFromHomeTo(this.router, `${StateConstants.JMLFDC_ADMIN_SHELL}/${StateConstants.NOTIFICATIONS_VIEW}`);
  }

  public navigateTo(routeInfo: RouteInfo): void {
    this.navigationService.navigateFromHomeTo(this.router, `${routeInfo.parent.route}/${routeInfo.route}`);
    // this.navigationService.navigateDirectlyTo(this.router, `${StateConstants.HOME_ROOT}/${routeInfo.parent.route}/${routeInfo.route}`);
  }

  public goToCoffee() {
    // TODO do we still have coffee?
    this.navigationService.navigateTo(this.router, StateConstants.COFFEE);
  }

}
