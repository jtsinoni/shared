import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {MainNavComponent} from './main-nav.component';
import {MainNavService} from './main-nav.service';
import {LoggerService} from '../../services/logger/logger.service';
import {LoginService} from '../../services/login.service';
import {TooltipModule} from 'ngx-bootstrap';
import {NO_ERRORS_SCHEMA} from '@angular/core';

describe('MainNavComponent', () => {
  let component: MainNavComponent;
  let fixture: ComponentFixture<MainNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [TooltipModule.forRoot()],
      declarations: [MainNavComponent],
      providers: [MainNavService, LoggerService, LoginService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
