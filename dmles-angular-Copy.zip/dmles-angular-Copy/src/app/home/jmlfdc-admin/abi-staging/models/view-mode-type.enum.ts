export enum ViewModeType {
  ShowIncomplete = 'Show Incomplete Records',
  ShowMerging = 'Show Records Being Merged',
  ShowPendingApproval = 'Show Records Pending Approval',
  ShowApproved = 'Show Approved Records',
  ShowPublished = 'Show Published Records',
  ShowAll = 'Show All Records',
  ShowInUse = 'Show In Use Records',
  ShowMerged = 'Show Merged Records',
}
