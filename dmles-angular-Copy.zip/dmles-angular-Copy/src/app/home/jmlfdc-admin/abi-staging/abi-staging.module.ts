import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ModelsModule} from './models/models.module';

@NgModule({
  imports: [
    CommonModule, ModelsModule
  ],
  declarations: []
})
export class AbiStagingModule { }
