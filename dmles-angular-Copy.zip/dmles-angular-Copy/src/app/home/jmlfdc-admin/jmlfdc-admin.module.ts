import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {JmlfdcAdminRoutingModule} from './jmlfdc-admin-routing.module';
import { AdminComponent } from './admin/admin.component';
import {SystemNotificationModule} from './system-notification/system-notification.module';

@NgModule({
  imports: [
    CommonModule, JmlfdcAdminRoutingModule, SystemNotificationModule
  ],
  declarations: [AdminComponent],
  exports: [AdminComponent]
})
export class JmlfdcAdminModule { }
