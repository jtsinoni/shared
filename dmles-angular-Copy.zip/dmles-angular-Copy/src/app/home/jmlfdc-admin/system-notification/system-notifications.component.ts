import {Component, OnInit} from '@angular/core';
import {SystemNotification} from './models/system-notification';
import {LoggerService} from '../../../services/logger/logger.service';
import {SystemNotificationService} from './services/system-notification.service';
import {ActivatedRoute, Router} from '@angular/router';
import {StateConstants} from '../../../constants/state.constants';
import 'rxjs/add/operator/map';
import {FormsModule} from '@angular/forms';
import {NavigationService} from '../../../services/navigation.service';
import {LcTableSettings} from '../../../common-components/lc-table/models/lc-table-settings';
import {LcDateCellComponent} from '../../../common-components/lc-table/lc-date-cell/lc-date-cell.component';
import {LcLinkCellComponent} from '../../../common-components/lc-table/lc-link-cell/lc-link-cell.component';
import {LcTableColumn} from '../../../common-components/lc-table/models/lc-table-column';

@Component({
  selector: 'app-system-notifications',
  templateUrl: './system-notifications.component.html',
  providers: [SystemNotificationService, FormsModule]
})
export class SystemNotificationsComponent implements OnInit {

  public lcTableColumns: any;
  public lcTableSettings: LcTableSettings;
  public lcTableData: Array<SystemNotification> = [];

  constructor(private logger: LoggerService,
              private systemNotificationService: SystemNotificationService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private navigationService: NavigationService) {}

  ngOnInit() {
    this.setTableSettings();
    this.loadData();
  }

  private setTableSettings(){

    this.lcTableSettings = new LcTableSettings();
    this.lcTableSettings.cardId = 'sysNotifTable';
    this.lcTableSettings.cardTitle = 'System Notifications';
    this.lcTableSettings.cardTitleIcon = 'fa fa-bullhorn';
    this.lcTableSettings.tableAttr.id = 'sysNotifTableAttr';

    this.lcTableSettings.cardShowHeader = true;

    // this.lcTableSettings.cardShowDownload = false;
    // this.lcTableSettings.cardShowGlobalSearch = false;
    // this.lcTableSettings.cardShowRefresh = false;

    // this.lcTableSettings.cardShowGlobalSearch = false;
    // this.lcTableSettings.tableHideSubHeader = false;

    const idColumn: LcTableColumn = new LcTableColumn();
    idColumn.sortDirection = 'desc';
    idColumn.title = 'ID';

    const nameColumn: LcTableColumn = new LcTableColumn();
    nameColumn.title = 'Name';
    nameColumn.type = 'custom';
    nameColumn.renderComponent = LcLinkCellComponent;
    nameColumn.onComponentInitFunction = (instance) => {
      instance.cellSelected.subscribe(row => {
        this.goToEditNotification(row);
      });
    };

    const startDateColumn: LcTableColumn = new LcTableColumn();
    startDateColumn.sortDirection = 'desc';
    startDateColumn.title = 'Start Date';
    startDateColumn.type = 'custom';
    startDateColumn.renderComponent = LcDateCellComponent;

    const endDateColumn: LcTableColumn = new LcTableColumn();
    endDateColumn.title = 'End Date';
    endDateColumn.type = 'custom';
    endDateColumn.renderComponent = LcDateCellComponent;

    const updatedDateColumn: LcTableColumn = new LcTableColumn();
    updatedDateColumn.title = 'Updated Date';
    updatedDateColumn.type = 'custom';
    updatedDateColumn.renderComponent = LcDateCellComponent;

    this.lcTableColumns = {
      displayType: new LcTableColumn('Type'),
      name: nameColumn,
      content: new LcTableColumn('Content'),
      startDate: startDateColumn,
      endDate: endDateColumn,
      updateBy: new LcTableColumn('Updated By'),
      updateDate: updatedDateColumn,
      isActive: new LcTableColumn('Active'),
    };
  }

  private loadData(){
    this.lcTableData = [];
    this.systemNotificationService.getSystemNotifications().subscribe((result) => {
      this.lcTableData = result;
    });
  }

  public goToAddNotification() {
    this.navigationService.navigateRelativeTo(this.router, StateConstants.NOTIFICATIONS_ADD, this.activatedRoute);
  }

  public goToEditNotification(systemNotification) {
    // TODO: Should get fresh notification from DB before editing
    this.logger.debug(`what we got here ${JSON.stringify(systemNotification)}`);
    this.systemNotificationService.setSystemNotification(systemNotification);
    this.navigationService.navigateRelativeTo(this.router, StateConstants.NOTIFICATIONS_EDIT, this.activatedRoute);
  }

  public lcOnRefresh(refresh: string) {
    this.loadData();
  }

}
