export class SystemNotification {
  public id: string;
  public displayType: string;
  public name: string;
  public content: string;
  public startDate: Date;
  public endDate: Date;
  public updateBy: string;
  public updateDate: Date;
  public isActive: boolean;

  constructor(obj?: SystemNotification) {
    this.id = obj && obj.id || '';
    this.displayType = obj && obj.displayType || '';
    this.name = obj && obj.name || '';
    this.content = obj && obj.content || '';
    this.startDate = obj && obj.startDate || new Date();
    this.endDate = obj && obj.endDate || new Date();
    this.updateBy = obj && obj.updateBy || '';
    this.updateDate = obj && obj.updateDate || null;
    this.isActive = obj && obj.isActive || null;
  }
}
