import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {CommonComponentsModule} from '../../../common-components/common-components.module';
import {SystemNotificationService} from './services/system-notification.service';
import {SystemNotificationApiService} from './services/system-notification-api.service';
import {ViewsModule} from './views/views.module';
import {SystemNotificationsComponent} from './system-notifications.component';

@NgModule({
  imports: [
    CommonModule,
    CommonComponentsModule,
    ViewsModule
  ],
  declarations: [
    SystemNotificationsComponent
  ],
  exports: [
    SystemNotificationsComponent
  ],
  providers: [
    SystemNotificationService,
    SystemNotificationApiService
  ]
})
export class SystemNotificationModule { }
