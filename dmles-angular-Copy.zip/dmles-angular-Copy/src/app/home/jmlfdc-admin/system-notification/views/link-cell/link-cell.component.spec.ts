import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkCellComponent } from './link-cell.component';
import {LoggerService} from '../../../../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';

describe('LinkCellComponent', () => {
  let component: LinkCellComponent;
  let fixture: ComponentFixture<LinkCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ LinkCellComponent ],
      providers: [LoggerService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
