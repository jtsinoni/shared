import {Component, Input, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoggerService} from '../../../../../services/logger/logger.service';
import {SystemNotification} from '../../models/system-notification';
import {SystemNotificationService} from '../../services/system-notification.service';
import {ActivatedRoute, Router} from '@angular/router';
import {StateConstants} from '../../../../../constants/state.constants';
import {NavigationService} from '../../../../../services/navigation.service';

@Component({
  selector: 'app-create-notification',
  templateUrl: './create-notification.component.html',
  styleUrls: ['./create-notification.component.scss']
})
export class CreateNotificationComponent implements OnInit {

  public createNotificationForm: FormGroup;

  // @Input()
  // public minDate: Date = new Date();
  //
  @Input()
  public systemNotification: SystemNotification = new SystemNotification();

  constructor(
    private logger: LoggerService,
    private formBuilder: FormBuilder,
    public systemNotificationService: SystemNotificationService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private navigationService: NavigationService) {

  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.createNotificationForm = this.formBuilder.group({
      systemNotificationNameControl: ['', Validators.required],
      systemNotificationTypeControl: ['', Validators.required],
      systemNotificationContentControl: ['', Validators.required],
      editSystemNotificationStartDateControl: ['', Validators.required],
      editSystemNotificationEndDateControl: ['', Validators.required],
      enabledCheckboxControl: ['']
    });

    this.createNotificationForm.setValue({
      systemNotificationNameControl: this.systemNotification.name,
      systemNotificationTypeControl: this.systemNotification.displayType,
      systemNotificationContentControl: this.systemNotification.content,
      editSystemNotificationStartDateControl: this.systemNotification.startDate,
      editSystemNotificationEndDateControl: this.systemNotification.endDate,
      enabledCheckboxControl: this.systemNotification.isActive
    });
  }

  saveSystemNotification() {
    if (!this.createNotificationForm.invalid) {
       this.systemNotification = this.createNotificationForm.value;

      this.logger.debug(`saved system notification ${JSON.stringify(this.systemNotification)}`);
      this.systemNotificationService.createSystemNotification(this.systemNotification);
      this.goToViewNotifications();
    }


  }

  public goToViewNotifications() {
    this.navigationService.navigateRelativeTo(this.router, StateConstants.NOTIFICATIONS_VIEW, this.activatedRoute);
  }

  public allowSave(): boolean {
    return !this.createNotificationForm.invalid;
  }


}
