import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YesNoCellComponent } from './yes-no-cell.component';
import {PipesModule} from '../../../../../pipes/pipes.module';

describe('YesNoCellComponent', () => {
  let component: YesNoCellComponent;
  let fixture: ComponentFixture<YesNoCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YesNoCellComponent ],
      imports: [PipesModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YesNoCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
