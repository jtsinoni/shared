import {Component, Input, OnInit} from '@angular/core';
import {ViewCell} from 'ng2-smart-table';

@Component({
  selector: 'app-yes-no-cell',
  template: `<span>{{ value | dmlesTrueFalse }}</span>`
})
export class YesNoCellComponent implements ViewCell, OnInit {
  @Input() value: string | number;
  @Input() rowData: any;


  constructor() { }

  ngOnInit() {

  }

}
