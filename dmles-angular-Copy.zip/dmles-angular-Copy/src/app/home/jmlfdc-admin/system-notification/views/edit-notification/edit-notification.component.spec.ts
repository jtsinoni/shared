import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditNotificationComponent } from './edit-notification.component';
import {LoggerService} from '../../../../../services/logger/logger.service';
import {FormBuilder} from '@angular/forms';
import {SystemNotificationService} from '../../services/system-notification.service';
import {SystemNotificationApiService} from '../../services/system-notification-api.service';
import {HttpTestModule} from '../../../../../common-components/test/http-test.module';
import {RouterTestingModule} from '@angular/router/testing';
import {PermissionService} from '../../../../../services/permission.service';
import {LoginService} from '../../../../../services/login.service';
import {NavigationService} from '../../../../../services/navigation.service';
import {ProfileApiService} from '../../../../../services/profile-api.service';

describe('EditNotificationComponent', () => {
  let component: EditNotificationComponent;
  let fixture: ComponentFixture<EditNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpTestModule.forRoot(), RouterTestingModule],
      declarations: [ EditNotificationComponent ],
      providers: [LoggerService, FormBuilder, SystemNotificationService, SystemNotificationApiService,
        NavigationService, PermissionService, LoginService, ProfileApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
