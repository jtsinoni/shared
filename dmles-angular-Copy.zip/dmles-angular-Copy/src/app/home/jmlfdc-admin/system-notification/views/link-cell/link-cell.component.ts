import { Component, OnInit } from '@angular/core';
import {ViewCell} from 'ng2-smart-table';
import {LoggerService} from '../../../../../services/logger/logger.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-link-cell',
  template: `<a (click)="goToLink(value)">{{ value }}</a>`
})
export class LinkCellComponent implements ViewCell, OnInit {
  value: string | number;
  rowData: any;

  constructor(private logger: LoggerService, private router: Router) { }

  ngOnInit() {
  }

  goToLink(link: string) {

  }

}
