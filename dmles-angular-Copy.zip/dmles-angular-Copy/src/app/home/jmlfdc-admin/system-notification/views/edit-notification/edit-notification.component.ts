import { Component, OnInit } from '@angular/core';
import {LoggerService} from '../../../../../services/logger/logger.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {SystemNotificationService} from '../../services/system-notification.service';
import {Router} from '@angular/router';
import {SystemNotification} from '../../models/system-notification';
import {StateConstants} from '../../../../../constants/state.constants';
import {NavigationService} from '../../../../../services/navigation.service';

@Component({
  selector: 'app-edit-notification',
  templateUrl: './edit-notification.component.html',
  styleUrls: ['./edit-notification.component.scss']
})
export class EditNotificationComponent implements OnInit {

  public editNotificationForm: FormGroup;

  private systemNotification: SystemNotification;

  constructor(  private logger: LoggerService,
                private formBuilder: FormBuilder,
                public systemNotificationService: SystemNotificationService,
                private router: Router,
                private navigationService: NavigationService) {
  }

  ngOnInit() {
    this.getData();
  }

  private getData() {
      this.systemNotification = this.systemNotificationService.systemNotification;
      this.logger.debug(`***** AND what we got here ${JSON.stringify(this.systemNotification)}`);
      this.createForm();

  }

  private createForm() {
    this.editNotificationForm = this.formBuilder.group({
      systemNotificationNameControl: ['', Validators.required],
      systemNotificationTypeControl: ['', Validators.required],
      systemNotificationContentControl: ['', Validators.required],
      editSystemNotificationStartDateControl: ['', Validators.required],
      editSystemNotificationEndDateControl: ['', Validators.required],
      enabledCheckboxControl: ['']
    });

    // this.editNotificationForm.setValue({
    //   systemNotificationNameControl: this.systemNotification.name,
    //   systemNotificationTypeControl: this.systemNotification.displayType,
    //   systemNotificationContentControl: this.systemNotification.content,
    //   editSystemNotificationStartDateControl: this.systemNotification.startDate,
    //   editSystemNotificationEndDateControl: this.systemNotification.endDate,
    //   enabledCheckboxControl: this.systemNotification.isActive
    // });


  }

  public allowSave() {
    return !this.editNotificationForm.invalid;
  }

  public goToViewNotifications() {
    this.navigationService.navigateTo(this.router, StateConstants.NOTIFICATIONS_VIEW);
  }



}
