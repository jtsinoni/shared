import { Component, OnInit } from '@angular/core';
import {ViewCell} from 'ng2-smart-table';

@Component({
  selector: 'app-date-cell',
  template: `<span>{{ value | dmlesDateTime }}</span>`
})
export class DateCellComponent implements ViewCell, OnInit {
  value: string | number;
  rowData: any;

  constructor() { }

  ngOnInit() {
  }

}
