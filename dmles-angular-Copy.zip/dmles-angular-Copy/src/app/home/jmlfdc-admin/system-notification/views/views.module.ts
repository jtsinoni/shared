import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {PaginationModule, TabsModule} from 'ngx-bootstrap';
import {SystemNotificationService} from '../services/system-notification.service';
import {LinkCellComponent} from './link-cell/link-cell.component';
import {DateCellComponent} from './date-cell/date-cell.component';
import {PipesModule} from '../../../../pipes/pipes.module';
import {YesNoCellComponent} from './yes-no-cell/yes-no-cell.component';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {CreateNotificationComponent} from './create-notification/create-notification.component';
import {EditNotificationComponent} from './edit-notification/edit-notification.component';
import {LcTableModule} from '../../../../common-components/lc-table/lc-table.module';

@NgModule({
  imports: [
    CommonModule,
    LcTableModule,
    NgxDatatableModule,
    FormsModule,
    PaginationModule.forRoot(),
    TabsModule.forRoot(),
    PipesModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    LinkCellComponent,
    DateCellComponent,
    YesNoCellComponent,
    CreateNotificationComponent,
    EditNotificationComponent
  ],
  providers: [SystemNotificationService],
  entryComponents: [LinkCellComponent, DateCellComponent, YesNoCellComponent]

})
export class ViewsModule {
}
