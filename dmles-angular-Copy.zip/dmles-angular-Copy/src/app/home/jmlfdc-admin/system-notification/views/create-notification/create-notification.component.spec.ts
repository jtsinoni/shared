import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateNotificationComponent } from './create-notification.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {LoggerService} from '../../../../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {SystemNotificationService} from '../../services/system-notification.service';
import {SystemNotificationApiService} from '../../services/system-notification-api.service';
import {HttpTestModule} from '../../../../../common-components/test/http-test.module';
import {PermissionService} from '../../../../../services/permission.service';
import {NavigationService} from '../../../../../services/navigation.service';
import {LoginService} from '../../../../../services/login.service';
import {ProfileApiService} from '../../../../../services/profile-api.service';

describe('CreateNotificationComponent', () => {
  let component: CreateNotificationComponent;
  let fixture: ComponentFixture<CreateNotificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateNotificationComponent ],
      imports: [FormsModule, ReactiveFormsModule, RouterTestingModule, HttpTestModule.forRoot()],
      providers: [LoggerService, SystemNotificationService, SystemNotificationApiService, NavigationService,
        PermissionService, LoginService, ProfileApiService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
