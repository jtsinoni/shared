import { TestBed, inject } from '@angular/core/testing';

import { SystemNotificationApiService } from './system-notification-api.service';
import {LoggerService} from '../../../../services/logger/logger.service';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';

describe('SystemNotificationApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpTestModule.forRoot()],
      providers: [SystemNotificationApiService, LoggerService]
    });
  });

  it('should be created', inject([SystemNotificationApiService], (service: SystemNotificationApiService) => {
    expect(service).toBeTruthy();
  }));
});
