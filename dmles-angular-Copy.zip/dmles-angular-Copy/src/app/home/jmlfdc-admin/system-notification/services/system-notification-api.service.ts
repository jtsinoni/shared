import { Injectable } from '@angular/core';
import {ApiService} from '../../../../services/api.service';
import {LoggerService} from '../../../../services/logger/logger.service';
import {HttpClient} from '@angular/common/http';
import {AuthenticationService} from '../../../../services/authentication.service';
import {ApiConstants} from '../../../../constants/api.constants';
import {SystemNotification} from '../models/system-notification';

@Injectable()
export class SystemNotificationApiService extends ApiService{

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService) {
    super(ApiConstants.NOTIFICATION_API, logger, http, authenticationService);

  }
  public getSystemNotifications() {
      return this.get('getMyNotifications');
    }

  public getAllSystemNotifications() {
      return this.get('getAllSystemNotifications');
    }

  public addSystemNotification(systemNotification: SystemNotification){
      return this.post('addSystemNotification', systemNotification).map((result) => {
        return result;
      });
    }

  public saveSystemNotification(systemNotification: SystemNotification){
      return this.post('saveSystemNotification', systemNotification).map((result) => {
        return result;
      });
    }


}
