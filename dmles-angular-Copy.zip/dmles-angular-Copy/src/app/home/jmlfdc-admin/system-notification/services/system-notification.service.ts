import {Injectable} from '@angular/core';
import {SystemNotification} from '../models/system-notification';
import {LoggerService} from '../../../../services/logger/logger.service';
import {SystemNotificationApiService} from './system-notification-api.service';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class SystemNotificationService {

  private serviceName: String = 'SystemNotificationService';

  public systemNotification: SystemNotification = null;
  public allNotifications: Array<SystemNotification> = [];

  public systemNotificationDisplayTypeOptions = ['New Feature', 'Information', 'Maintenance'];

  constructor(private logger: LoggerService, private systemNotificationApiService: SystemNotificationApiService) {
    this.logger.debug('%s - Start', this.serviceName);
  }

  public getSystemNotifications(): Observable<Array<SystemNotification>> {
    this.logger.info('load  System Notifications');
    return this.systemNotificationApiService.getAllSystemNotifications();

  }

  public clearSystemNotification() {
    this.systemNotification = new SystemNotification();
  }


  public getSystemNotification(): SystemNotification {
    return this.systemNotification;
  }

  public resetSystemNotification() {
    this.systemNotification = null;
  }

  public setSystemNotification(systemNotification: SystemNotification): void {
    this.systemNotification = {...systemNotification};
    this.logger.debug(`what about here ..... ${JSON.stringify(this.systemNotification)}`);
  }

  public createSystemNotification(systemNotification: SystemNotification) {
    this.systemNotificationApiService.addSystemNotification(systemNotification).subscribe((data) => {
      this.logger.debug(`${this.serviceName}- saved new system notification`);
    });
  }

  public saveSystemNotification(systemNotification: SystemNotification) {
    this.systemNotificationApiService.saveSystemNotification(systemNotification).subscribe((data) => {
      this.logger.debug(`${this.serviceName}- saved updated a system notification`);
    });
  }


}
