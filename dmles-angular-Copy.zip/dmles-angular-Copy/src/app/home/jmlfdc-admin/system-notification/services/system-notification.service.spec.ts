import { TestBed, inject } from '@angular/core/testing';

import { SystemNotificationService } from './system-notification.service';
import {LoggerService} from '../../../../services/logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {SystemNotificationApiService} from './system-notification-api.service';
import {HttpTestModule} from '../../../../common-components/test/http-test.module';

describe('SystemNotificationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpTestModule.forRoot()],
      providers: [SystemNotificationService, LoggerService, SystemNotificationApiService]
    });
  });

  it('should be created', inject([SystemNotificationService], (service: SystemNotificationService) => {
    expect(service).toBeTruthy();
  }));
});
