import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemNotificationsComponent } from './system-notifications.component';
import {LoggerService} from '../../../services/logger/logger.service';
import {SystemNotificationService} from './services/system-notification.service';
import {SystemNotificationApiService} from './services/system-notification-api.service';
import {HttpTestModule} from '../../../common-components/test/http-test.module';
import {RouterTestingModule} from '@angular/router/testing';
import {Ng2SmartTableModule} from 'ng2-smart-table';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {PipesModule} from '../../../pipes/pipes.module';
import {NavigationService} from '../../../services/navigation.service';
import {PermissionService} from '../../../services/permission.service';
import {LoginService} from '../../../services/login.service';
import {ProfileApiService} from '../../../services/profile-api.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('SystemNotificationsComponent', () => {
  let component: SystemNotificationsComponent;
  let fixture: ComponentFixture<SystemNotificationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [NgxDatatableModule, Ng2SmartTableModule, HttpTestModule.forRoot(), RouterTestingModule, PipesModule],
      declarations: [ SystemNotificationsComponent ],
      providers: [LoggerService, SystemNotificationService, SystemNotificationApiService, NavigationService,
        PermissionService, LoginService, ProfileApiService],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemNotificationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
