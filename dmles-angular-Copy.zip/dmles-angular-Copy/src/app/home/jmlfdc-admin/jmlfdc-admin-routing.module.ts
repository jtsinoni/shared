import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SystemNotificationsComponent} from './system-notification/system-notifications.component';
import {AdminComponent} from './admin/admin.component';
import {CreateNotificationComponent} from './system-notification/views/create-notification/create-notification.component';
import {EditNotificationComponent} from './system-notification/views/edit-notification/edit-notification.component';
import {LoginService} from '../../services/login.service';
import {NavigationService} from '../../services/navigation.service';
import {RouteConstants} from '../../constants/route.constants';

const adminRoutes: Routes = [
  {
    path: '',
    component:  AdminComponent, canActivate: [LoginService],
    data: {breadcrumb: RouteConstants.JMLFDC_ADMIN.breadcrumb},
    children: [
      {
        path: RouteConstants.NOTIFICATIONS_VIEW.route,
        component: SystemNotificationsComponent,
        data: {breadcrumb: RouteConstants.NOTIFICATIONS_VIEW.breadcrumb},
        canActivate: [NavigationService],
        children: [
          {
            path: RouteConstants.NOTIFICATIONS_ADD.route,
            component: CreateNotificationComponent,
            data: {breadcrumb: RouteConstants.NOTIFICATIONS_ADD.breadcrumb},
            canActivate: [NavigationService]
          },
          {
            path: RouteConstants.NOTIFICATIONS_EDIT.route,
            component: EditNotificationComponent,
            data: {breadcrumb: RouteConstants.NOTIFICATIONS_EDIT.breadcrumb},
            canActivate: [NavigationService]
          }
        ]
      },
      {path: '', redirectTo: RouteConstants.NOTIFICATIONS_VIEW.route}
    ]},
  {path: '', redirectTo: RouteConstants.JMLFDC_ADMIN.route}
];

@NgModule({
  imports: [RouterModule.forChild(adminRoutes)],
  exports: [RouterModule]
})
export class JmlfdcAdminRoutingModule { }
