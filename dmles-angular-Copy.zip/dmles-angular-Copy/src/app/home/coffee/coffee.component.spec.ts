import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {NO_ERRORS_SCHEMA} from '@angular/core';

import { CoffeeComponent } from './coffee.component';
import {RouterTestingModule} from '@angular/router/testing';
import {CommonComponentsModule} from '../../common-components/common-components.module';
import {SidePanelService} from '../../services/side-panel.service';

describe('CoffeeComponent', () => {
  let component: CoffeeComponent;
  let fixture: ComponentFixture<CoffeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, CommonComponentsModule],
      declarations: [ CoffeeComponent ],
      providers: [SidePanelService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoffeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
