import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CoffeeComponent} from './coffee.component';

const coffeeRoutes: Routes = [
  {
    path: '',
    // data: {breadcrumb: 'Coffee'},
    component:  CoffeeComponent,
    children: [
      // {
      //   path: '',
      //   component: SomeOtherCoffeeChildComponent goes here
      // }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(coffeeRoutes)],
  exports: [RouterModule]
})
export class CoffeeRouterModule {

}
