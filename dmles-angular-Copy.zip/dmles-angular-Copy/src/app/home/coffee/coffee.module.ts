import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CoffeeRouterModule} from './coffee-router.module';
import {CoffeeComponent} from './coffee.component';
import {CommonComponentsModule} from '../../common-components/common-components.module';

@NgModule({
  imports: [
    CommonComponentsModule,
    CommonModule,
    CoffeeRouterModule
  ],
  declarations: [CoffeeComponent],
  exports: [CoffeeComponent]
})
export class CoffeeModule { }
