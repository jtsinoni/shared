import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccessRoutingModule } from './access-routing.module';
import { UserProfileManagementComponent } from './user-profile-management/user-profile-management.component';
import { AccessComponent } from './access.component';
import { RoleManagementComponent } from './role-management/role-management.component';
import { PermissionManagementComponent } from './permission-management/permission-management.component';
import { CommonComponentsModule } from '../../common-components/common-components.module';

@NgModule({
  imports: [
    CommonModule,
    AccessRoutingModule,
    CommonComponentsModule,
  ],
  declarations: [AccessComponent, UserProfileManagementComponent, RoleManagementComponent, PermissionManagementComponent],
  exports: [AccessComponent, UserProfileManagementComponent, RoleManagementComponent, PermissionManagementComponent]
})
export class AccessModule { }
