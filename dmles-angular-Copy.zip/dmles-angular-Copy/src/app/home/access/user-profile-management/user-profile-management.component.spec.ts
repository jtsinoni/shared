import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {UserProfileManagementComponent} from './user-profile-management.component';
import {BsDatepickerModule} from 'ngx-bootstrap';

describe('UserProfileManagementComponent', () => {
  let component: UserProfileManagementComponent;
  let fixture: ComponentFixture<UserProfileManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserProfileManagementComponent ],
      imports: [BsDatepickerModule.forRoot()],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProfileManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
