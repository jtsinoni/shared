import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-access',
  templateUrl: './access.component.html',
})
export class AccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
