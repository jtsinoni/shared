import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {AccessComponent} from './access.component';
import {UserProfileManagementComponent} from './user-profile-management/user-profile-management.component';
import {RouteConstants} from '../../constants/route.constants';
import {RoleManagementComponent} from './role-management/role-management.component';
import {PermissionManagementComponent} from './permission-management/permission-management.component';
import {NavigationService} from '../../services/navigation.service';
import {LoginService} from '../../services/login.service';
const routes: Routes = [
  {
    path: '',
    component:  AccessComponent, canActivate: [LoginService],
    data: {breadcrumb: RouteConstants.ACCESS.breadcrumb},
    children: [
        {
          path: RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT.route,
          component: UserProfileManagementComponent,
          data: {breadcrumb: RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT.breadcrumb},
          canActivate: [NavigationService]
        },
        {
          path: RouteConstants.ACCESS_ROLE_MANAGEMENT.route,
          component: RoleManagementComponent,
          data: {breadcrumb: RouteConstants.ACCESS_ROLE_MANAGEMENT.breadcrumb},
          canActivate: [NavigationService]
        },
        {
          path: RouteConstants.ACCESS_PERMISSION_MANAGEMENT.route,
          component: PermissionManagementComponent,
          data: {breadcrumb: RouteConstants.ACCESS_PERMISSION_MANAGEMENT.breadcrumb},
          canActivate: [NavigationService]
        },

        // default route if non selected
        {path: '', redirectTo: RouteConstants.ACCESS_USER_PROFILE_MANAGEMENT.route}
  ]},
  {path: '', redirectTo: RouteConstants.ACCESS.route}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccessRoutingModule { }
