import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {CommonComponentsModule} from '../common-components/common-components.module';
import {PipesModule} from '../pipes/pipes.module';
import {HomeComponentsModule} from './home-components/home-components.module';
import {AlertModule, BsDropdownModule, PopoverModule, TooltipModule} from 'ngx-bootstrap';
import {HomeFooterComponent} from './home-footer/home-footer.component';
import {HomeHeaderComponent } from './home-header/home-header.component';
import {MyDashboardComponent} from './my-dashboard/my-dashboard.component';
import {MainNavComponent} from './main-nav/main-nav.component';
import {UtilService} from '../services/util.service';
import {MainNavService} from './main-nav/main-nav.service';
import {DmlesArraySortPipePipe} from '../pipes/dmles-array-sort-pipe.pipe';
import {MainNavSelectorComponent} from './main-nav/main-nav-selector/main-nav-selector.component';
import {DirectivesModule} from '../directives/directives.module';
import {HomeComponent} from './home.component';
import {HomeRoutingModule} from './home-routing.module';
import {NavigationService} from '../services/navigation.service';

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    FormsModule,
    CommonComponentsModule,
    PipesModule,
    HomeComponentsModule,
    PopoverModule.forRoot(),
    AlertModule.forRoot(),
    TooltipModule.forRoot(),
    BsDropdownModule.forRoot(),
    DirectivesModule],
  declarations: [HomeFooterComponent,
    HomeComponent,
    HomeHeaderComponent,
    HomeFooterComponent,
    MyDashboardComponent,
    MainNavComponent,
    MainNavSelectorComponent,
    HomeComponent],
  exports: [HomeFooterComponent,
    CommonComponentsModule,
    DmlesArraySortPipePipe],
  providers: [UtilService, MainNavService, NavigationService]
})
export class HomeModule {
}
