import { DmlesDatePipe } from './dmles-date.pipe';

describe('DmlesDatePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesDatePipe('yyyy MM dd');
    expect(pipe).toBeTruthy();
  });
});
it(`should return formated date string`, () => {
  const dateTime: Date = new Date('2017-11-29 10:54:02');
    // TODO what if it isn't en-us?
  const pipe = new DmlesDatePipe('en-US');

  expect(pipe.transform(dateTime)).toEqual('29 Nov 2017');
});
