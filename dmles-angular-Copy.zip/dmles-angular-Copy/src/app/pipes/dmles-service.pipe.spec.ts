import { DmlesServicePipe } from './dmles-service.pipe';

describe('DmlesServicePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesServicePipe();
    expect(pipe).toBeTruthy();
  });
});
it(`should return service name from abbreviation`, () => {
  const pipe = new DmlesServicePipe();
  expect(pipe.transform('DA')).toEqual('Army');
  expect(pipe.transform('')).toEqual('Unknown');
  expect(pipe.transform(null)).toEqual('Unknown');
  expect(pipe.transform('blah')).toEqual('Other');
  expect(pipe.transform('DM')).toEqual('Marine Corps');
});

