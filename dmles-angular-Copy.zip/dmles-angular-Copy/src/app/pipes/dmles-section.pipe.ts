import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dmlesSection'
})
export class DmlesSectionPipe implements PipeTransform {

  transform(input: Array<any>, section: string, doFilter: boolean): any {
    let output: Array<any> = new Array();
    if (!doFilter) {
      output = input.slice();
    } else {
      for (const f of input) {
        if (f.section === section) {
          output.push(f);
        }
      }
    }
    return output;
  }
}


