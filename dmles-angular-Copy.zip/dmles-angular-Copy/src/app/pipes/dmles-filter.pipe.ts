import { Pipe, PipeTransform } from '@angular/core';
import { UserProfile } from '../models/user-profile.model';

@Pipe({
  name: 'filter'
})
export class DmlesFilterPipe implements PipeTransform {
  private isUserProfile(arg: any): arg is UserProfile {
    return arg.profileName !== undefined;
  }

  private isString(arg: any): arg is string {
    return arg.toLowerCase !== undefined;
  }

  transform(items: any[], searchText: string): any[] {
    if (!items || items.length === 0) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLowerCase();

    return items.filter(item => {
      if (this.isString(item)) {
        return (item as string).toLowerCase().includes(searchText);
      }

      if (this.isUserProfile(item)) {
        return (item as UserProfile).profileName.toLowerCase().includes(searchText);
      }
    });
  }
}
