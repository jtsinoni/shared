import { DmlesTrueFalsePipe } from './dmles-true-false.pipe';

describe('DmlesTrueFalsePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesTrueFalsePipe();
    expect(pipe).toBeTruthy();
  });
});
it(`should return Yes, No or Unknown from boolean, null, empty string or undefined`, () => {
  const pipe = new DmlesTrueFalsePipe();
  expect(pipe.transform(false)).toEqual('No');
  expect(pipe.transform('')).toEqual('Unknown');
  expect(pipe.transform(null)).toEqual('Unknown');
  expect(pipe.transform(true)).toEqual('Yes');
});
