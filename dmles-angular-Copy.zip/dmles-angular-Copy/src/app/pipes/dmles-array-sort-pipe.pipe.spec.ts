import { DmlesArraySortPipePipe } from './dmles-array-sort-pipe.pipe';

describe('DmlesArraySortPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesArraySortPipePipe();
    expect(pipe).toBeTruthy();
  });
});
