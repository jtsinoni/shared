import { DmlesDateTimePipe } from './dmles-date-time.pipe';

describe('DmlesDateTimePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesDateTimePipe('yyyy-MM-dd HH:mm');
    expect(pipe).toBeTruthy();
  });
});
it(`should return formated date time string`, () => {
  const dateTime: Date = new Date('2017-11-29 10:54:02');
  // TODO what if it isn't en-us?
  const pipe = new DmlesDateTimePipe('en-US');
  expect(pipe.transform(dateTime)).toEqual('29 Nov 2017 10:54:02');
});
