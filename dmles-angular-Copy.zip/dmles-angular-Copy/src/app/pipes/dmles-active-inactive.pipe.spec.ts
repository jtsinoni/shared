import { DmlesActiveInactivePipe } from './dmles-active-inactive.pipe';

describe('DmlesActiveInactivePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesActiveInactivePipe();
    expect(pipe).toBeTruthy();
  });
});

it(`should return 'Active' if value is present`, () => {
  const pipe = new DmlesActiveInactivePipe();
  expect(pipe.transform('test')).toEqual('Active');
});

it(`should return 'Inactive' if value is undefined or null`, () => {
  const pipe = new DmlesActiveInactivePipe();
  expect(pipe.transform(null)).toEqual('Inactive');
});
