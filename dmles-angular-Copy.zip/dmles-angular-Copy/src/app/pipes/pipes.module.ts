import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DmlesDateTimePipe} from './dmles-date-time.pipe';
import {DmlesDatePipe} from './dmles-date.pipe';
import {DmlesActiveInactivePipe} from './dmles-active-inactive.pipe';
import {DmlesSectionPipe} from './dmles-section.pipe';
import {DmlesServicePipe} from './dmles-service.pipe';
import {DmlesTitleCasePipe} from './dmles-title-case.pipe';
import {DmlesTrueFalsePipe} from './dmles-true-false.pipe';
import {DmlesArraySortPipePipe} from './dmles-array-sort-pipe.pipe';
import {DmlesFilterPipe} from './dmles-filter.pipe';


@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
    // DmlesActiveInactivePipe,
    DmlesDateTimePipe,
    DmlesDatePipe,
    DmlesSectionPipe,
    DmlesServicePipe,
    DmlesTitleCasePipe,
    DmlesTrueFalsePipe,
    DmlesArraySortPipePipe,
    DmlesFilterPipe
  ],
  exports: [
    // DmlesActiveInactivePipe,
    DmlesDateTimePipe,
    DmlesDatePipe,
    DmlesSectionPipe,
    DmlesServicePipe,
    DmlesTitleCasePipe,
    DmlesTrueFalsePipe,
    DmlesArraySortPipePipe,
    DmlesFilterPipe
  ]
})
export class PipesModule {

  static forRoot() {
    return {
      ngModule: PipesModule,
      providers: [],
    };
  }

}
