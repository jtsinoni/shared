import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dmlesService'
})
export class DmlesServicePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let retVal: string = '';
    if (value === null || value === '')  {
        retVal = 'Unknown';
    } else if (value === 'DA') {
        retVal = 'Army';
    } else if (value === 'DHA')  {
        retVal = 'Defense Health Agency';
    } else if (value === 'DF') {
        retVal = 'Air Force';
    } else if (value === 'DN' || value === 'NV') {
        retVal = 'Navy';
    } else if (value === 'DM') {
        retVal = 'Marine Corps';
    } else if (value === 'VA') {
        retVal = 'Veterans Administration';
    } else {
        retVal = 'Other';
    }

    return retVal;
  }

}
