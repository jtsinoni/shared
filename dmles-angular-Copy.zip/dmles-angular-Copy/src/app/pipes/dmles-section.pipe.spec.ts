import { DmlesSectionPipe } from './dmles-section.pipe';

describe('DmlesSectionPipe', () => {

 // beforeEach(function () {
 //  const thingOne = { id: 1, section: 'section1' };
 //  const thingTwo = { id: 2, section: 'section2' };
 //  const thingThree = { id: 3, section: 'section3' };
 //  const testData1: Array<any> = new Array(thingOne);
 //  const testData2: Array<any> = new Array(thingOne, thingTwo, thingThree);

    it('create an instance', () => {
      const pipe = new DmlesSectionPipe();
      expect(pipe).toBeTruthy();
    });

    it(`should return the existing array if doFilter is false`, () => {
      const pipe = new DmlesSectionPipe();
      const thingOne = { id: 1, section: 'section1' };
      const thingTwo = { id: 2, section: 'section2' };
      const thingThree = { id: 3, section: 'section3' };
      // const testData1: Array<any> = new Array(thingOne);
      const testData2: Array<any> = new Array(thingOne, thingTwo, thingThree);
      const result = pipe.transform(testData2, 'sectionXXXX', false);
      expect(result).toEqual(testData2);
    });


    it(`should return an array with only section1`, () => {
      const pipe = new DmlesSectionPipe();
      const thingOne = { id: 1, section: 'section1' };
      const thingTwo = { id: 2, section: 'section2' };
      const thingThree = { id: 3, section: 'section3' };
      const testData1: Array<any> = new Array(thingOne);
      const testData2: Array<any> = new Array(thingOne, thingTwo, thingThree);

      const result = pipe.transform(testData2, 'section1', true);
      expect(result).toEqual(testData1);
    });


    it(`should return an empty array if doFilter is true and no sections are matched`, () => {
      const pipe = new DmlesSectionPipe();

      const thingOne = { id: 1, section: 'section1' };
      const thingTwo = { id: 2, section: 'section2' };
      const thingThree = { id: 3, section: 'section3' };
      // const testData1: Array<any> = new Array(thingOne);
      const testData2: Array<any> = new Array(thingOne, thingTwo, thingThree);


      const result = pipe.transform(testData2, 'blah', true);
      let emptyArray: Array<any>;
      emptyArray = new Array();
      expect(result).toEqual(emptyArray);
    });
//  });
});



