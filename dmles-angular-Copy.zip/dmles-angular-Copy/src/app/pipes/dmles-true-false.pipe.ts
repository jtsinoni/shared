import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dmlesTrueFalse'
})
export class DmlesTrueFalsePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let retVal: string = 'Yes';
    if (value === null || value === '') {
        retVal = 'Unknown';
    } else if (value === false) {
        retVal = 'No';
    }
    return retVal;
  }

}
