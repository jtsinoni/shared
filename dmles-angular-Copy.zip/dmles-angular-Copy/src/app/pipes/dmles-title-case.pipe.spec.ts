import { DmlesTitleCasePipe } from './dmles-title-case.pipe';

describe('DmlesTitleCasePipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesTitleCasePipe();
    expect(pipe).toBeTruthy();
  });
});
it(`should return title cased string from input`, () => {
  const pipe = new DmlesTitleCasePipe();
  // what about 'has'?
  expect(pipe.transform('my dog has fleas')).toEqual('My Dog Has Fleas');
  expect(pipe.transform(null)).toEqual(null);
  expect(pipe.transform('i\'ve got blisters on my fingers')).toEqual('I\'ve Got Blisters on My Fingers');
});

