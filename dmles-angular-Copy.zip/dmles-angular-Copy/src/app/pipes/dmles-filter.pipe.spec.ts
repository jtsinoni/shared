import { DmlesFilterPipe } from './dmles-filter.pipe';
import { UserProfile } from '../models/user-profile.model';

describe('DmlesFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DmlesFilterPipe();
    expect(pipe).toBeTruthy();
  });

  it(`should return an empty array`, () => {
    const pipe = new DmlesFilterPipe();
    expect(pipe.transform([], null)).toEqual([]);
    expect(pipe.transform(null, null)).toEqual([]);
  });

  it(`should return the array passed in if the searchString is null or empty`, () => {
    const pipe = new DmlesFilterPipe();
    const items: Array<string> = ['hello', 'world'];
    expect(pipe.transform(items, null)).toEqual(items);
    expect(pipe.transform(items, '')).toEqual(items);
  });

  it(`should return an array of strings filtered based on the searchString`, () => {
    const pipe = new DmlesFilterPipe();
    const items: Array<string> = ['ROOT', 'Site Equipment Manager', 'DEV'];
    const searchString: string = 'r';
    // should return ROOT and Site Equipment Manager, because they both contain an 'r'
    expect(pipe.transform(items, searchString)).toEqual(['ROOT', 'Site Equipment Manager']);
  });

  it(`should return an array of UserProfile objects filtered based on the searchString`, () => {
    const pipe = new DmlesFilterPipe();
    const userProfile1: UserProfile = new UserProfile();
    userProfile1.profileName = 'ROOT';

    const userProfile2: UserProfile = new UserProfile();
    userProfile2.profileName = 'Site Equipment Manager';

    const userProfile3: UserProfile = new UserProfile();
    userProfile3.profileName = 'DEV';

    const userProfiles: UserProfile[] = [userProfile1, userProfile2, userProfile3];

    const searchString: string = 'r';
    // should return ROOT and Site Equipment Manager, because they both contain an 'r'
    expect(pipe.transform(userProfiles, searchString)).toEqual([userProfile1, userProfile2]);
  });
});

