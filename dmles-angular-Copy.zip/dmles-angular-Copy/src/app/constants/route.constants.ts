export interface RouteInfo {
  route: string;
  breadcrumb?: string;
  parent?: RouteInfo;
  children?: Array<RouteInfo>;
}
export class RouteConstants {
  static LOGIN: RouteInfo = {route: 'dmles.login', breadcrumb: 'Login'};
  static CHOOSE_PROFILE: RouteInfo = {route: 'chooseProfile', breadcrumb: 'Choose Profile', parent: RouteConstants.LOGIN};
  static REQUEST_PKI_DN_UPDATE: RouteInfo = {route: 'requestPkiDnUpdate', breadcrumb: 'Update CAC/PIV', parent: RouteConstants.LOGIN};
  static ACCESSIBILITY: RouteInfo = {route: 'accessibility', breadcrumb: 'Accessibility', parent: RouteConstants.LOGIN};

  static HOME_ROOT: RouteInfo = {route: 'dmles.home', breadcrumb: 'Home'};
  static MY_DASHBOARD: RouteInfo = {route: 'dashboard', breadcrumb: 'My Dashboard', parent: RouteConstants.HOME_ROOT};
  static ABOUT: RouteInfo = {route: 'about', breadcrumb: 'About', parent: RouteConstants.HOME_ROOT};
  static HELP: RouteInfo = {route: 'help', breadcrumb: 'Help', parent: RouteConstants.HOME_ROOT};
  static USER_PROFILE: RouteInfo = {route: 'userProfile', breadcrumb: 'My Profile', parent: RouteConstants.HOME_ROOT};
  static USER_PROFILE_EDIT_GEN_INFO: RouteInfo = {route: 'editGenInfoUserProfile', breadcrumb: 'Edit Profile', parent: RouteConstants.HOME_ROOT};
  static LOADING: RouteInfo = {route: 'loading', parent: RouteConstants.HOME_ROOT};

  static ACCESS: RouteInfo = {route: 'access', breadcrumb: 'Access', parent: RouteConstants.HOME_ROOT};
  static ACCESS_USER_PROFILE_MANAGEMENT: RouteInfo = {route: 'userProfileManagement', breadcrumb: 'User Profile Management', parent: RouteConstants.ACCESS};
  static ACCESS_PERMISSION_MANAGEMENT: RouteInfo = {route: 'permissionManagement', breadcrumb: 'Permission Management', parent: RouteConstants.ACCESS};
  static ACCESS_ROLE_MANAGEMENT: RouteInfo = {route: 'roleManagement', breadcrumb: 'Role Management', parent: RouteConstants.ACCESS};

  static JMLFDC_ADMIN: RouteInfo = {route: 'jmlfdcAdmin', breadcrumb: 'JMLFDC Admin', parent: RouteConstants.HOME_ROOT};
  static NOTIFICATIONS_VIEW: RouteInfo = {route: 'viewNotifications', breadcrumb: 'Notifications', parent: RouteConstants.JMLFDC_ADMIN};
  static NOTIFICATIONS_ADD: RouteInfo = {route: 'createNotification', breadcrumb: 'Create Notification', parent: RouteConstants.NOTIFICATIONS_VIEW};
  static NOTIFICATIONS_EDIT: RouteInfo = {route: 'createNotification', breadcrumb: 'Create Notification', parent: RouteConstants.NOTIFICATIONS_VIEW};

  static INVENTORY: RouteInfo = {route: 'inventory', breadcrumb: 'Inventory', parent: RouteConstants.HOME_ROOT};
  static INVENTORY_SEARCH: RouteInfo = {route: 'search', breadcrumb: 'Inventory Search', parent: RouteConstants.INVENTORY};
  static INVENTORY_ITEM_ADD: RouteInfo = {route: 'itemAdd', breadcrumb: 'Add an Inventory Item', parent: RouteConstants.INVENTORY_SEARCH};
  static INVENTORY_DETAILS: RouteInfo = {route: 'details', breadcrumb: 'Inventory Item Details', parent: RouteConstants.INVENTORY_SEARCH};
  static INVENTORY_ITEM_EDIT: RouteInfo = {route: 'itemEdit', breadcrumb: 'Edit an Inventory Item', parent: RouteConstants.INVENTORY_DETAILS};
}
