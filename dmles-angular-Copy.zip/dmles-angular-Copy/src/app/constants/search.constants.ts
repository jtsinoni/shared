
export class SearchConstants {

    static EVENT_MODULE_ABI: string = 'ABi';
    static EVENT_MODULE_BASE: string = 'BaseModule';
    static EVENT_MODULE_EQUIPMENT_RECORD: string = 'EquipmentRecord';

    // components that potentially have many specific instances
    static EVENT_TARGET_COMPONENT_CATEGORY: string = ' Category';
    static EVENT_TARGET_COMPONENT_CATEGORY_BREADCRUMB: string = ' CategoryBreadcrumb';
    static EVENT_TARGET_COMPONENT_FACET: string = ' Facet';

    // breadbox component
    static EVENT_TARGET_COMPONENT_SELECTED_FACET_OPTIONS_BREADBOX: string = ' SelectedFacetOptionsBreadbox';

    // parent search component
    static EVENT_TARGET_COMPONENT_SEARCH: string = ' Search';

    // Category component methods
    static EVENT_TARGET_METHOD_CLEAR_ALL_CATEGORY_OPTION_SELECTIONS: string = 'clearAllCategoryOptionSelections';
    // tslint:disable-next-line:max-line-length
    static EVENT_TARGET_METHOD_UPDATE_CATEGORY_OPTION_SELECTIONS_PER_BREADCRUMB_CLICK: string = 'updateCategoryOptionSelectionsPerBreadcrumbClick';

    // Category Breadcrumb component methods
    static EVENT_TARGET_METHOD_UPDATE_BREADCRUMB_PER_CATEGORY_OPTION_SELECTION: string = 'updateBreadcrumbPerCategoryOptionSelection';

    // Facet component methods
    static EVENT_TARGET_METHOD_CLEAR_SELECTED_FACET_OPTION: string = 'clearSelectedFacetOption';
    static EVENT_TARGET_METHOD_CLEAR_FILTERING_MATCH_STRING: string = 'clearFilteringMatchString';

    // Selected Facet Options Breadbox component methods
    static EVENT_TARGET_METHOD_CLEAR_ALL_SELECTED_FACET_OPTIONS: string = 'clearAllSelectedFacetOptions';
    static EVENT_TARGET_METHOD_REMOVE_SELECTED_FACET_OPTION: string = 'removeSelectedFacetOption';
    static EVENT_TARGET_METHOD_UPDATE_SELECTED_FACET_OPTIONS: string = 'updateSelectedFacetOptions';

    // Search component methods
    static EVENT_TARGET_METHOD_EXECUTE_SEARCH: string = 'executeSearch';
    static EVENT_TARGET_METHOD_INIT_SEARCH: string = 'initSearch';

    static NO_VALUE: string = '--- No Value ---';

    constructor() {
    }
}
