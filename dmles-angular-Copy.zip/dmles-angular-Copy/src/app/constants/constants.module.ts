// import { NgModule } from '@angular/core';
//
// import {ApiConstants } from './api.constants';
// import {ContentConstants } from './content.constants';
// import {CookieConstants } from './cookie.constants';
// import {ResourceConstants } from './resource.constants';
// import {SearchConstants } from './search.constants';
// import {ServiceLongName } from './serviceLongName.constants';
// import {ServiceShortName } from './serviceShortName.constants';
// import {StateConstants } from './state.constants';
//
// @NgModule({
//     declarations: [
//         ApiConstants,
//         ContentConstants,
//         CookieConstants,
//         ResourceConstants,
//         SearchConstants,
//         ServiceLongName,
//         ServiceShortName,
//         StateConstants
//     ],
//     // imports: [
//     //     ApiConstants,
//     //     ContentConstants,
//     //     CookieConstants,
//     //     ResourceConstants,
//     //     SearchConstants,
//     //     ServiceLongName,
//     //     ServiceShortName,
//     //     StateConstants    ],
//     // providers: []
//   })
//   export class ConstantsModule { }
