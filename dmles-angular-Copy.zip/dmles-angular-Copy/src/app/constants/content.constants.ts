export class ContentConstants {
    public static COMMENT_SUCCESSFULL_DELETE: string = 'Comment Successfully deleted.';
    public static DATE_TIME: string = 'dd MMM yyyy HH:mm:ss';
    public static DODAAC_COMPARE_FIELD: string = 'dodaac';
    public static EMPLOYEE_EMAIL_COMPARE_FIELD: string = 'email';
    public static ERR_MSG: string = 'An error occurred, please try again later. If this error persists, contact the system admin.';
    // tslint:disable-next-line:max-line-length
    public static REQUEST_UPDATE_ERR_MSG: string = 'An error occurred.  Please check the email address you entered, and try again.  If this error persists, contact application support personnel.';
    public static SIGN_IN_ERR_MSG: string = 'There was a problem processing your request. If the problem persists please contact application support personnel.';
    public static EVENT_ITEMS_IN_CART: string = 'eventItemsInCart';
    public static EVENT_USER_UPDATE: string = 'eventUserUpdate';
    public static FORMAT_DATE: string = 'dd MMM yyyy';
    public static FORMAT_DATE_TIME: string = 'dd MMM yyyy HH:mm:ss';
    public static MANUFACTURER_SITE_ID: string = 'DMLSS';
    public static ORDER_REQ_TYPE_CATALOG: string = 'CATALOG';
    public static ORDER_REQ_TYPE_NEW_ITEM: string = 'NEW_ITEM';
    public static REGEX_EMAIL: string = '/^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
    public static REGEX_PHONE: string = '/\d{3}-\d{3}-\d{4}/';
    public static ROLE_COMPARE_FIELD: string = 'name';
    public static SELECTED: string = 'SELECTED';
    public static SEARCH_MAX: number = 250;
    public static UNREGISTERED_USER: string = 'UnregisteredUser';
    public static DELETED_USER_ERR_MSG: string = 'User Profile is deleted. Please contact application support personnel.';
    public static EXPIRED_USER_ERR_MSG: string = 'User Profile has expired. Please contact application support personnel.';
    public static LOCKED_USER_ERR_MSG: string = 'User Profile is locked. Please contact application support personnel.';
    public static PENDING_USER_ERR_MSG: string = 'User Profile is pending. Please contact application support personnel.';
    public static SUSPENDED_USER_ERR_MSG: string = 'User Profile is suspended. Please contact application support personnel.';
    public static ACTIVE: string = 'ACTIVE';
    public static LOCKED: string = 'Locked';
    public static PENDING: string = 'Pending';
    public static SUSPENDED: string = 'Suspended';
    public static SAVE_SUCCESSFUL: string = 'Save Successful';
}
