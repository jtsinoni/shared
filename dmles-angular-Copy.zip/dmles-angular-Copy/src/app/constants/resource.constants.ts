// TODO: Once the permission's collection has been made, these should be pulled from that
// collection and then, used appropriately.
export class ResourceConstants {

    static ABI: string = 'abi';

    static MANAGE_ABI_STAGING: string = 'manage-abi-staging';
    static MANAGE_ABI_MOVE_TO_PRODUCTION: string = 'manage-abi-move-to-production';
    static MANAGE_ABI_DELTA: string = 'manage-abi-delta';
    static MANAGE_SERVICE_PROVIDERS: string = 'manage-service-providers';

    static EQUIP_REQUESTS_VIEW: string = 'requests-service';
    static EQUIP_REQUESTS_MY_REQUESTS: string = 'equip-my-requests';
    static EQUIP_REQUESTS_APPROVE: string = 'equip-approve';
    static EQUIP_REQUESTS_CREATE: string = 'equip-request-create';
    static EQUIP_REQUESTS_FACILITIES: string = 'equip-request-facilities';
    static EQUIP_REQUESTS_MAINTENANCE: string = 'equip-request-maintenance';
    static EQUIP_REQUESTS_SAFETY: string = 'equip-request-safety';
    static EQUIP_REQUESTS_TECHNOLOGY: string = 'equip-request-technology';
    static EQUIP_REQUESTS_REVIEW: string = 'equip-request-review';
    static EQUIP_REQUESTS_UPDATE: string = 'equip-update';

    static EQUIP_RECORDS_VIEW: string = 'equip-records';

    static GLOBAL_ACCESS: string = 'global-access';

    static ORGANIZATION_MANAGEMENT: string = 'organization-management';
    static ORGANIZATION_VIEW: string = 'organization-view';

    static PERMISSION_MANAGEMENT: string = 'permission-management';

    static ROLE_MANAGEMENT: string = 'role-management';

    static USER_PROFILE_MANAGEMENT: string = 'user-profile-management';

    static VIEW_ALL_REQUESTS: string = 'view-all-requests';

    static WORKFLOW_MANAGEMENT: string = 'workflow-management';

    static INVENTORY_MANAGEMENT: string = 'inventory-management';
    static INVENTORY_RECORD_VIEW: string = 'inventory-record-view';
    static INVENTORY_PHYSICAL_VIEW: string = 'inventory-physical-view';
    static INVENTORY_STORAGE_VIEW: string = 'inventory-storage-view';
    static INVENTORY_EXCESS_REPORT: string = 'inventory-excess-report';
    static INVENTORY_EXCESS_REQUEST: string = 'inventory-excess-request';
    static INVENTORY_PLANNING: string = 'inventory-planning';

    static REAL_ESTATE_INSTALLATION_RECORD_VIEW: string = 'real-estate-installation-view';
    static REAL_ESTATE_INSTALLATION_SITE_RECORD_VIEW: string = 'real-estate-site-view';

    static BUYER_DETAIL_VIEW: string = 'buyer-main';
    static BUYER_LOOKUP_VIEW: string = 'buyer-lookup';

    static EQUIPMENT_TESTING: string = 'test-equipment';

    static VIEW_SYSTEM_NOTIFICATIONS: string = 'view-system-notifications';
    static ADD_SYSTEM_NOTIFICATION: string = 'add-system-notification';
    static VIEW_APP_HISTORY: string = 'view-app-history';

    constructor() {
        // no-op
    }
}
