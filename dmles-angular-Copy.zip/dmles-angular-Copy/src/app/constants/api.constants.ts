
export class ApiConstants {

    // Note: Keep these lines sorted to avoid merge conflicts
    public static ABI_API: string = 'Dmles.ABi.Server/V1/abi/';
    public static ABI_DELTA_API: string = 'Dmles.ABi.Server/V1/abi/delta/';
    public static ABI_PRODUCTION_API: string = 'Dmles.ABi.Server/V1/abi/production/';
    public static ABI_SITE_CATALOG_API: string = 'Dmles.ABi.Server/V1/abi/sitecatalog/';
    public static ABI_STAGING_API: string = 'Dmles.ABi.Server/V1/abi/staging/';
    public static ABI_STAGING_JOIN_API: string = 'Dmles.ABi.Server/V1/abi/staging/join/';
    public static ABI_STAGING_LOOKUP_API: string = 'Dmles.ABi.Server/V1/abi/staging/lookup/';
    public static ABI_TASK_HISTORY_MANAGER_API: string = 'Dmles.ABi.Server/V1/abi/taskHistory/';
    public static ABI_TAXONOMY_API: string = 'Dmles.ABi.Server/V1/abi/taxonomy/';
    public static ABI_STAGING_MOVE_RECORDS_API: string = 'Dmles.ABi.Server/V1/abi/staging/moveRecords/';
    public static CLIENT_ID: string = 'dmles';
    public static DMLES_TOKEN: string = 'dmles-token';
    public static DMLES_USER: string = 'dmles-user';
    public static EQUIPMENT_API: string = 'Dmles.Equipment.Server/V1/';
    public static FILE_MANAGER_API: string = 'Dmles.FileManager.Server/V1/';
    public static NOTIFICATION_API: string = 'Dmles.Notification.Server/V1/notification/';
    public static OAUTH_API: string = 'Dmles.OAuth.Server/';
    public static ORG_API: string = 'Dmles.Organization.Server/V1/organization/';
    public static ROLE_API: string = 'Dmles.User.Server/V1/role/';
    public static SERVICE_PROVIDER_API: string = 'Dmles.Organization.Server/V1/organization/';
    public static SITE_API: string = 'Dmles.Site.Server/V1/';
    public static SYSTEM_API: string = 'Dmles.System.Server/V1/';
    public static SYSTEM_APP_HISTORY: string = 'Dmles.System.Server/V1/';
    public static UNREGISTERED_USER: string = 'UnregisteredUser';
    public static USER_API: string = 'Dmles.User.Server/V1/user/';

}
