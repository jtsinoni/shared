import { TestBed, inject } from '@angular/core/testing';
import { CurrencyPipe } from '@angular/common';
import { AuthenticationService } from './authentication.service';
import { TestabilityRegistry } from '@angular/core/src/testability/testability';
import { LoggerService } from './logger/logger.service';
import { StorageService } from './storage.service';
import { WindowService } from './window.service';
import { UtilService } from './util.service';


describe('AuthenticationService', () => {
  let authenticationService: AuthenticationService;
  let logger: LoggerService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthenticationService, LoggerService,
                  StorageService, WindowService, UtilService, CurrencyPipe]
    });

    authenticationService = TestBed.get(AuthenticationService);
    logger = TestBed.get(LoggerService);
  });

  it('should be created', () => {
    expect(authenticationService).toBeTruthy();
  });

  it('should save token to session web storage', () => {
    const token: string = 'some-token';
    expect(authenticationService.saveToken(token)).toBeUndefined();
  });

  it('should return token from session storage', () => {
    const token: any = !!authenticationService.getToken();
    expect(token).toBe(true);
  });

  it('should validate user is logged in', () => {
    const isLoggedIn: boolean = authenticationService.isLoggedIn();
    expect(isLoggedIn).toBe(true);
  });

  it('should validate user is logged out', () => {
    authenticationService.logout();
    const isLoggedIn: boolean = authenticationService.isLoggedIn();
    expect(isLoggedIn).toBe(false);
  });
});
