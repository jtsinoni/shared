import { async, TestBed, inject } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { CurrencyPipe } from '@angular/common';
import { ApiService } from './api.service';
import { LoggerService } from './logger/logger.service';
import { AuthenticationService } from './authentication.service';
import { StorageService } from './storage.service';
import { WindowService } from './window.service';
import { UtilService } from './util.service';


describe('ApiService', () => {
  let http: HttpClient;
  let logger: LoggerService;
  let authenticationService: AuthenticationService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [LoggerService, HttpClient, AuthenticationService,
                  StorageService, WindowService, UtilService, CurrencyPipe],
    });

    http = TestBed.get(HttpClient);
    logger = TestBed.get(LoggerService);
    authenticationService = TestBed.get(AuthenticationService);
  }));

  it('should compile', async(() => {
    const apiService = new ApiService('some service', logger, http, authenticationService);
    expect(apiService).toBeTruthy();
  }));
});
