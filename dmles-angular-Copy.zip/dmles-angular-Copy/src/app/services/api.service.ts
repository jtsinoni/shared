import {HttpHeaders, HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs/Observable';

import {AppConfig} from '../app.config';
import {LoggerService} from '../services/logger/logger.service';
import {AuthenticationService} from './authentication.service';

export interface HeaderNameValue {
  name: string;
  value: string;
}
interface GetParams {
  url: string;
  headers: HttpHeaders;
}

export class ApiService {
  private apiServiceName: string = 'Api Service';
  private baseUrl: string;

  constructor(private methodPath: string,
              protected logger: LoggerService,
              private http: HttpClient,
              protected authenticationService: AuthenticationService) {

    if (AppConfig.BT_BASE_URL) {
      this.baseUrl = AppConfig.BT_BASE_URL;
      this.logger.info(`${this.apiServiceName} - btBaseUrl loaded: ${this.baseUrl}`);
    } else {
      this.logger.error(`${this.apiServiceName} - Error: Unable to load btBaseUrl`);
    }
  }

  protected determineUrl(action: string, apiConstant?: string) {
    let url: string;
    if (apiConstant) {
      url = this.baseUrl + apiConstant + action;
    } else {
      url = this.baseUrl + this.methodPath + action;
    }
    return url;
  }

  private getHelper(action: string, apiConstant?: string): GetParams {
    const url: string = this.determineUrl(action, apiConstant);
    this.logger.debug(`${this.apiServiceName} - BT Get URL: ${url}`);

    const headers: HttpHeaders = this.getHeader('GET');
    return {url: url, headers: headers};
  }

  public getArrayBuffer(action: string, apiConstant?: string): Observable<any> {
    const params: GetParams = this.getHelper(action, apiConstant);
    return this.http.get(params.url, {headers: params.headers, responseType: 'arraybuffer'});
  }

  public get(action: string, apiConstant?: string): Observable<any> {
    const params: GetParams = this.getHelper(action, apiConstant);
    return this.http.get(params.url, {headers: params.headers});
  }

  public post(action: string, data: any, headers?: HttpHeaders): Observable<any> {
    const url: string = this.determineUrl(action);
    this.logger.debug(`${this.apiServiceName} - BT Post URL: ${url}`);

    if (!headers) {
      headers = this.getHeader('POST');
    }

    return this.http.post(url, data, {headers: headers});
  }

  protected addToHeaders(headers: HttpHeaders, moreHeaders: HeaderNameValue[]): HttpHeaders {
    if (moreHeaders) {
      for (const header of moreHeaders) {
        headers = headers.append(header.name, header.value);
      }
    }
    return headers;
  }

  protected getHeader(verb: string, authType: string = 'Token', authTypeValue?: string, moreHeaders?: HeaderNameValue[]): HttpHeaders {
    if (!authTypeValue) {
      authTypeValue = this.authenticationService.getToken();
    }

    let headers: HttpHeaders = new HttpHeaders({
      'Authorization': `${authType} ${authTypeValue}`,
      'ClientId': 'dmles',
      'Access-Control-Allow-Origin': '*'
    });
    headers = this.addToHeaders(headers, moreHeaders);

    switch (verb) {
      case 'POST': {
        headers = headers.append('Content-Type', 'application/json');
        break;
      }
      case 'GET': {
        break;
      }
      default: {
        break;
      }
    }
    return headers;
  }
}
