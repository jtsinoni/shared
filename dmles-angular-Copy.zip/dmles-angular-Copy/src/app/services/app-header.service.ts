import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
import {LoggerService} from './logger/logger.service';
import {StateConstants} from '../constants/state.constants';
import {UtilService} from './util.service';

@Injectable()
export class AppHeaderService {

  public securityPage: boolean;
  public showFooter: boolean;
  public showLoginHeader: boolean;
  public showFullHeader: boolean;

  constructor(private router: Router, private logger: LoggerService, private utilService: UtilService) { }


  public doesRouteExist(routePath: string): boolean {
    this.logger.debug('looking for: ' + routePath);
    let exists = false;
    const pathName = routePath.replace('/', '');
    for (let i = 0; i < this.router.config.length; i++) {
      const path: string = this.router.config[i].path;
      if (path === pathName) {
        exists = true;
        break;
      }
    }
    return exists;
  }

  public setHeaderAndFooter(currentUrl: string) {

    this.logger.debug(`the current url is ${currentUrl}`);

    const index: number =  this.utilService.findTheNthOccurrenceInString(currentUrl, '/', 2);

    this.logger.debug(`the index is ${index}`);
    if (index > 0) {
      currentUrl = currentUrl.substr(0, index);

      this.logger.debug(`the current url modified is ${currentUrl}`);
    }
    const routeExists = this.doesRouteExist(currentUrl);

    this.logger.debug('route ' + currentUrl + ' exists: ' + routeExists);

    if (!routeExists || currentUrl === '/' || currentUrl === '/**') {
      // hide the header & footer
      this.securityPage = true;
      this.showFooter = false;
      this.showLoginHeader = false;
      this.showFullHeader = false;
    } else if (currentUrl === ('/' + StateConstants.LOGIN) ||
               currentUrl === ('/' + StateConstants.REQUEST_PKI_DN_UPDATE) ||
               currentUrl === ('/' + StateConstants.CHOOSE_PROFILE) ||
               currentUrl === ('/' + StateConstants.ACCESSIBILITY)) {
      // show the login header, hide the footer
      this.securityPage = false;
      this.showFooter = false;
      this.showLoginHeader = true;
      this.showFullHeader = false;
    } else {
      // show home header
      this.securityPage = false;
      this.showFooter = true;
      this.showLoginHeader = false;
      this.showFullHeader = true;
    }
  }


}
