import {DoCheck, Injectable, OnInit} from '@angular/core';
import {LoggerService} from './logger/logger.service';
import {LoginService} from './login.service';
import {CurrentUserProfile} from '../models/current-user-profile.model';

@Injectable()
export class PermissionService {

  private currentUser: CurrentUserProfile;

  constructor(
    private logger: LoggerService,
    private loginService: LoginService
  ) { }

  private isStateFound(stateName: string, userStates: string[]): boolean {
    return userStates.indexOf(stateName) > -1;
  }

  private isAssignedPermissionFound(elementName: string, userElements: string[]): boolean {
    return userElements.indexOf(elementName) > -1;
  }

  public checkElements(elementName: string): boolean {
    let canAccess: boolean = false;
    const currentProfile: CurrentUserProfile = this.loginService.currentUser;
    // this.logger.warn(`checkElements > currentProfile: ${JSON.stringify(currentProfile)}`);

    if (currentProfile && currentProfile.elements) {
      canAccess = this.isAssignedPermissionFound(elementName, currentProfile.elements);
    }

    if (!canAccess){
      this.logger.warn('User profile does not contain element: %s', elementName);
    }

    return canAccess;
  }

  public checkStates(stateName: string): boolean {
    let canAccess: boolean = false;
    const currentProfile: CurrentUserProfile = this.loginService.currentUser;
    if (currentProfile && currentProfile.states) {
      canAccess = this.isStateFound(stateName, currentProfile.states);
    }

    if (!canAccess){
      this.logger.warn('User profile does not contain state: %s', stateName);
    }

    return canAccess;
  }

}
