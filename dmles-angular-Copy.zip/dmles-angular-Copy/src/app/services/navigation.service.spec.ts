import { TestBed, inject } from '@angular/core/testing';

import { NavigationService } from './navigation.service';
import {LoggerService} from './logger/logger.service';
import {RouterTestingModule} from '@angular/router/testing';
import {PermissionService} from './permission.service';
import {LoginService} from './login.service';
import {ProfileApiService} from './profile-api.service';
import {HttpTestModule} from '../common-components/test/http-test.module';
import {MockComponent} from '../common-components/test/mock.component';
import {Router} from '@angular/router';

describe('NavigationService', () => {
  let navigationService: NavigationService;
  beforeEach(() => {


    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpTestModule.forRoot()],
      providers: [NavigationService, LoggerService, PermissionService, LoginService, ProfileApiService]
    });

    navigationService = TestBed.get(NavigationService);
  });

  it('should be created', inject([NavigationService], (service: NavigationService) => {
    expect(service).toBeTruthy();
  }));

  it('should return the route url', () => {
    const url: string = 'dmles.home';
    expect(navigationService).toBeDefined();
  });

  // it('should return the route url', () => {
  //   const url: string = 'dmles.home';
  //   expect(navigationService.navigateDirectlyTo(router, 'home')).toBeDefined();
  // });


});
