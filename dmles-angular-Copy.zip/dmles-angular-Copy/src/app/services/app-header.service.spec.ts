import {TestBed, inject} from '@angular/core/testing';
import {AppHeaderService} from './app-header.service';
import {RouterTestingModule} from '@angular/router/testing';
import {CommonComponentsModule} from '../common-components/common-components.module';
import {MockComponent} from '../common-components/test/mock.component';
import {LoginService} from './login.service';
import {UtilService} from './util.service';
import {CurrencyPipe} from '@angular/common';

describe('AppHeaderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CommonComponentsModule, RouterTestingModule.withRoutes(
        [
          {path: 'security', component: MockComponent},
          {path: 'login', component: MockComponent, data: {breadcrumb: 'Login'}},
          {path: 'home', component: MockComponent, data: {breadcrumb: 'Home'}, canActivate: [LoginService]},
          {path: 'about', component: MockComponent, data: {breadcrumb: 'About'}},
          {path: 'help', component: MockComponent, data: {breadcrumb: 'Help'}},
          {path: '', redirectTo: 'security', pathMatch: 'full'},
          {path: '**', component: MockComponent},
        ],
      )],
      providers: [AppHeaderService, RouterTestingModule, UtilService, CurrencyPipe]
    });
  });

  it('should be created', inject([AppHeaderService], (service: AppHeaderService) => {
    expect(service).toBeTruthy();
  }));

  it('doesRouteExist should return true if the route exists false otherwise',
    inject([AppHeaderService], (service: AppHeaderService) => {
      expect(service.doesRouteExist('/')).toEqual(true);
    }));
});
