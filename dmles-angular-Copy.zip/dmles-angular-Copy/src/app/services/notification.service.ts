import { Injectable } from '@angular/core';
import { LoggerService } from './logger/logger.service';
import { ContentConstants } from '../constants/content.constants';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class NotificationService {

  private defaultConfig: any = {
    positionClass: 'toast-top-right'
  };

  constructor(private logger: LoggerService,
              private toastr: ToastrService) { }

  public errorMsg(msg: string, title?: string, config?: any): void {
    if (!title){
      title = 'Error';
    }
    if (!config){
      config = this.defaultConfig;
    }
    setTimeout(() => {
      this.toastr.error(msg, title, config);
    });
  }

  public infoMsg(msg: string, title?: string, config?: any): void {
    if (!title){
      title = 'Info';
    }
    if (!config){
      config = this.defaultConfig;
    }
    setTimeout(() => {
      this.toastr.info(msg, title, config);
    });
  }

  public successMsg(msg: string, title?: string, config?: any): void {
    if (!title){
      title = 'Success';
    }
    if (!config){
      config = this.defaultConfig;
    }
    setTimeout(() => {
      this.toastr.success(msg, title, config);
    });
  }

  public throwError(componentName: string, logMsg: string, errResponse: any): void {
    let errMsg = errResponse;
    if (errResponse.statusText){
      errMsg = errResponse.statusText;
    }
    this.logger.error(componentName + ' - ' + logMsg + ':' + errMsg);
    this.errorMsg(ContentConstants.ERR_MSG);
  }

  public warningMsg(msg: string, title?: string, config?: any): void {
    if (!title){
      title = 'Warning';
    }
    if (!config){
      config = this.defaultConfig;
    }
    setTimeout(() => {
      this.toastr.warning(msg, title, config);
    });
  }

}
