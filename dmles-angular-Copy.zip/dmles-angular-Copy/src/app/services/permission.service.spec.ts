import { TestBed, inject } from '@angular/core/testing';

import { PermissionService } from './permission.service';
import {LoggerService} from './logger/logger.service';
import {LoginService} from './login.service';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpTestModule} from '../common-components/test/http-test.module';
import {ProfileApiService} from './profile-api.service';

describe('PermissionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpTestModule.forRoot()],
      providers: [PermissionService, LoggerService, LoginService, ProfileApiService]
    });
  });

  it('should be created', inject([PermissionService], (service: PermissionService) => {
    expect(service).toBeTruthy();
  }));
});
