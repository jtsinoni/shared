import { TestBed, inject } from '@angular/core/testing';
import { UtilService } from './util.service';
import {CurrencyPipe} from '@angular/common';

describe('UtilService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UtilService, CurrencyPipe]
    });
  });

  it('should be created', inject([UtilService], (service: UtilService) => {
    expect(service).toBeTruthy();
  }));

  it('addZero should accept a single digit number and return a 0 prefixed numeric string',
    inject([UtilService], (service: UtilService) => {
      expect(service.addZero(2)).toEqual('02');
    }));

  it('addZero should accept a 2+ digit number and return the existing number',
    inject([UtilService], (service: UtilService) => {
      expect(service.addZero(12)).toEqual(12);
    }));

  it('convertToCamelCaseToText should convert a camel case string to common case',
    inject([UtilService], (service: UtilService) => {
      expect(service.convertCamelCaseToText('MyDogHasFleas')).toEqual('My Dog Has Fleas');
    }));

    it('convertCurrencyToFloat should convert a currency string to a floating point number',
    inject([UtilService], (service: UtilService) => {
      expect(service.convertCurrencyToFloat('$10.25')).toEqual(10.25);
    }));

    it('convertFloatToCurrency should convert a float value to a currency string (US Dollar only)',
    inject([UtilService], (service: UtilService) => {
      expect(service.convertFloatToCurrency(10.25)).toEqual('$10.25');
    }));

    it('detectIE should return a number representing the host browser',
    inject([UtilService], (service: UtilService) => {
      expect(service.detectIE()).toEqual(0);
    }));

    it('esBuildSearchStatsStr should return a formated string',
    inject([UtilService], (service: UtilService) => {
      const items: string = '25';
      const milliseconds: string = '1000';
      expect(service.esBuildSearchStatsStr(items, milliseconds)).toEqual('25 item(s) found ( 1000 milliseconds )');
    }));

    it('esEscapeSpecialChars should return a string with special characters escaped',
    inject([UtilService], (service: UtilService) => {
      expect(service.esEscapeSpecialChars('%^*sfsf')).toEqual('\\%\\^*sfsf');
    }));

  it('getDateInMillis should return the current date in milliseconds',
    inject([UtilService], (service: UtilService) => {
      expect(service.getDateInMillis()).toEqual(new Date().getTime());
    }));

  it('getDate should return the current formatted date',
    inject([UtilService], (service: UtilService) => {
      const date = new Date();
      const dateString = date.getFullYear() + '-' + service.addZero(date.getMonth()) + '-' +  service.addZero(date.getDay());
      expect(service.getDate(date)).toEqual(dateString);
    }));

  it('getTime should return the current formatted time',
    inject([UtilService], (service: UtilService) => {
      const date = new Date();
      const timeString = service.addZero(date.getHours()) + ':' + service.addZero(date.getMinutes()) + ':'
          + service.addZero(date.getSeconds() + '.' + date.getMilliseconds());
      expect(service.getTime(date)).toEqual(timeString);
    }));

  it('getDateTime should return the current formatted date time',
    inject([UtilService], (service: UtilService) => {
      const date = new Date();
      const dateString: string = service.getDate(date);
      const timeString: string = service.getTime(date);
      expect(service.getDateTime(date)).toEqual(dateString + ' ' + timeString);
    }));

  it('getHashLength should return the length of the object key',
    inject([UtilService], (service: UtilService) => {
      const hashObject: any = {key: 'blah', data: 'blah'};
      expect(service.getHashLength(hashObject)).toEqual(2);
    }));

  it('isStringFound should return true if the substring is contained in "searchwithin" false otherwise',
    inject([UtilService], (service: UtilService) => {
      const searchFor: string = 'blah';
      const searchWithin: string = 'oblahde';
      expect(service.isStringFound(searchFor, searchWithin)).toEqual(true);
      expect(service.isStringFound('gaga', searchWithin)).toEqual(false);
    }));

  it('isObjectEmpty should return true if the object null, empty or undefined false otherwise',
    inject([UtilService], (service: UtilService) => {
      const obj1: any = {};
      const obj2: any = {key: '1'};
      expect(service.isObjectEmpty(obj1)).toEqual(true);
      expect(service.isObjectEmpty(obj2)).toEqual(false);
    }));

  it('sortResults should return a sorted collection by property ascending or descending',
    inject([UtilService], (service: UtilService) => {
      const listToSort: any = [{key: '1', name: 'zeb'}, {key: '2', name: 'yeezus'}, {key: '3', name: 'fred'}];
      const sortedList: any = [{key: '3', name: 'fred'}, {key: '2', name: 'yeezus'}, {key: '1', name: 'zeb'} ];
      expect(service.sortResults(listToSort, 'name', true)).toEqual(sortedList);
    }));

  it('isNullOrEmpty should return true if the object is null or empty false otherwise',
    inject([UtilService], (service: UtilService) => {
      const emptyObject: any = null;
      const aString = 'blah';
      expect(service.isNullOrEmpty(emptyObject)).toEqual(true);
      expect(service.isNullOrEmpty(aString)).toEqual(false);
    }));

  it('isStringNullOrEmpty should return true if the object is a string and is null or empty, false otherwise',
    inject([UtilService], (service: UtilService) => {
      const emptyString: string = '';
      const aString: string = 'blah';
      expect(service.isStringNullOrEmpty(emptyString)).toEqual(true);
      expect(service.isStringNullOrEmpty(aString)).toEqual(false);
    }));

  it('isNullOrUndefined should return true if the object is null or undefined false otherwise',
    inject([UtilService], (service: UtilService) => {
      const emptyObject: any = null;
      const undefinedObject: any = undefined;
      const definedObject: any = {};
      expect(service.isNullOrUndefined(emptyObject)).toEqual(true);
      expect(service.isNullOrUndefined(undefinedObject)).toEqual(true);
      expect(service.isNullOrUndefined(definedObject)).toEqual(false);

    }));

  it('doesArrayContainString should return true if the array contains searchString false otherwise',
    inject([UtilService], (service: UtilService) => {
      const searchFor: string = 'blah';
      const stringArray: Array<string> = ['my', 'dog', 'has', 'fleas', 'blah'];
      expect(service.doesArrayContainString(searchFor, stringArray)).toEqual(true);
      expect(service.doesArrayContainString('gaga', stringArray)).toEqual(false);
    }));

  it('listContainsString should return true if the stringToCheck is in the list false if otherwise',
    inject([UtilService], (service: UtilService) => {
      const list: Array<string> = ['zeb', 'yeezus', 'fred'];
      expect(service.listContainsString(list, 'yeezus')).toEqual(true);
      expect(service.listContainsString(list, 'paul')).toEqual(false);
    }));

  it('findTheNthOccurrenceInString should return the index of the nth occurrence -1 if not found',
    inject([UtilService], (service: UtilService) => {
      const source: string = 'yeezus/fred/billy';
      expect(service.findTheNthOccurrenceInString(source, '/', 1)).toEqual(6);
      expect(service.findTheNthOccurrenceInString(source, '/', 2)).toEqual(11);
      expect(service.findTheNthOccurrenceInString(source, '/', 4)).toEqual(-1);
    }));



});
