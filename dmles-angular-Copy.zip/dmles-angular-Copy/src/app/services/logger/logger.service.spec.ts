import { TestBed, inject } from '@angular/core/testing';

import {LoggerService} from './logger.service';

describe('LoggerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoggerService]
    });
  });

  it('should be created', inject([LoggerService], (service: LoggerService) => {
    expect(service).toBeTruthy();
  }));

  it('should write log statements to the console log',
    inject([LoggerService], (service: LoggerService) => {
    const message = 'blah %s';
    const debugMessage = 'something went wrong here  %s';
    const args1 = 'de blah';
    const args2 = 'HELP!';

    service.info(message, args1);
    service.debug(debugMessage, args2);
    service.error(message);
    // check the log here...;)
    expect(service).toBeTruthy();
  }));
});
