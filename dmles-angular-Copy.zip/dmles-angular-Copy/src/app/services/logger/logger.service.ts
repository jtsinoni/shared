import {Injectable} from '@angular/core';
import {ILogger} from './ilogger';
import {environment} from '../../../environments/environment';

// use a single %s in message for an argument insertion
@Injectable()
export class LoggerService implements ILogger {
  static ERROR: string = 'ERROR';
  static DEBUG: string = 'DEBUG';
  static INFO: string = 'INFO';
  static WARN: string = 'WARN';

  constructor() {
  }

  // TODO flesh this out
  private isDebugMode = environment.production === false;

  info(message: string, args?: any) {
    this.callConsole(LoggerService.INFO, message, args);
  }

  debug(message: any, args?: any) {
    this.callConsole(LoggerService.DEBUG, message, args);
  }

  error(errorMessage: string) {
    this.callConsole(LoggerService.ERROR, errorMessage, '');
  }

  warn(message: any, args?: any) {
    this.callConsole(LoggerService.WARN, message, args);
  }

  private callConsole(type: string, message: string, args?: any) {
    if (this.isDebugMode) {
      if (!args) {
        args = '';
      }
      message = '[' + type + ']: ' + message;
      const logFn: Function = (console)[type] || console.log || null;
      logFn.apply(console, [message, args]);
    }
  }


}
