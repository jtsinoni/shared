import { Injectable } from '@angular/core';

@Injectable()
export class Base64Service {
  constructor() { }

  /**
   * Creates a base-64 encoded ASCII string from a "string" of binary data.
   */
  public b64EncodeUnicode(value: string) {
      return btoa(value.trim());
  }

  /**
   * Decodes a string of data which has been encoded using base-64 encoding.
   */
  public b64DecodeUnicode(value: string) {
      return atob(value);
  }
}
