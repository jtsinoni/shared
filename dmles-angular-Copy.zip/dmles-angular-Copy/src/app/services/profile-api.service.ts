import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiConstants } from '../constants/api.constants';
import { LoggerService } from './logger/logger.service';
import { ApiService } from './api.service';
import { AuthenticationService } from './authentication.service';
import { UserProfile } from '../models/user-profile.model';
import { Observable } from 'rxjs/Observable';
import { RoleRef } from '../models/role-ref.model';
import { NodeRef } from '../models/node-ref-data.model';
import { CurrentUserProfile } from '../models/current-user-profile.model';
import { GroupInvitation } from '../models/group-invitation.model';
import { GroupInvitationProfileTableData } from '../models/group-invitation-profile-table-data';

// TODO: Break out Invitation API calls into its own service

@Injectable()
export class ProfileApiService extends ApiService {
  private serviceName: string = 'ProfileApiService';
  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService) {
    super(ApiConstants.USER_API, logger, http, authenticationService);
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public acceptGroupInvitation(userProfile: UserProfile): Observable<UserProfile> {
    return this.post(`acceptGroupInvitation`, userProfile);
  }

  public acceptInvitationByPendingUser(userProfile: UserProfile): Observable<UserProfile> {
    return this.post(`acceptInvitationByPendingUser`, userProfile);
  }

  public addProfile(userProfile: UserProfile): Observable<UserProfile> {
    return this.post(`addProfile`, userProfile);
  }

  public approveInvitationByManager(userProfile: UserProfile): Observable<UserProfile> {
    return this.post(`approveInvitationByManager`, userProfile);
  }

  public cancelPkiDnUpdate(updateId: string): Observable<UserProfile> {
    return this.post(`cancelPkiDnUpdate`, updateId);
  }

  public checkUserEmail(checkEmail: string): Observable<boolean> {
    return this.get(`checkUserEmail?email=${checkEmail}`);
  }

  public createGroupInvitation(groupInvitation: GroupInvitation): Observable<GroupInvitation>{
    return this.post(`createInvitation`, groupInvitation);
  }

  public deleteUserProfile(userProfileId: string, reason: string): Observable<UserProfile> {
    return this.get(`deleteUserProfile?userProfileId=${userProfileId}&reason=${reason}`);
  }

  public denyGroupInvitationByManager(userProfile: UserProfile): Observable<boolean> {
    return this.post(`denyGroupInvitationByManager`, userProfile);
  }

  // Was: groupInvitationDeniedByUser
  // TODO: Update calling component
  public denyGroupInvitationByUser(userProfileId: string): Observable<boolean> {
    return this.get(`denyGroupInvitationByUser?userProfileId=${userProfileId}`);
  }

  // Was: invitationDeniedByAdmin
  // TODO: Update calling component
  public denySingleInvitationByAdmin(invitationId: string): Observable<boolean> {
    return this.get(`denySingleInvitationByAdmin?invitationId=${invitationId}`);
  }

  // Was: invitationDeniedByUser
  // TODO: Update calling component
  public denySingleInvitationByUser(invitationId: string): Observable<boolean> {
    return this.get(`denySingleInvitationByUser?invitationId=${invitationId}`);
  }

  public expireUserProfile(userProfileId: string, newExpirationDate: Date): Observable<UserProfile> {
    return this.get(`renewUserProfile?userProfileId=${userProfileId}&newExpirationDate=${newExpirationDate}`);
  }

  public getActiveUserProfiles(): Observable<UserProfile[]> {
    return this.get(`getActiveUserProfiles`);
  }

  public getAllGroupInvitations(): Observable<GroupInvitation[]> {
    return this.get(`getAllGroupInvitations`);
  }

  public getApprovedUserProfiles(): Observable<UserProfile[]> {
    return this.get(`getApprovedUserProfiles?userStatus=ALL`);
  }

  public getCntActiveUserProfiles(pkiDn: string): Observable<number> {
    return this.get(`getCntActiveUserProfiles?pkiDn=${pkiDn}`);
  }

  public getCntPendingMgrApprovalProfiles(groupInvitationId: string): Observable<number> {
    return this.get(`getCntPendingMgrApprovalProfiles?invitationId=${groupInvitationId}`);
  }

  public getCurrentProfile(): Observable<CurrentUserProfile> {
    return this.get(`getCurrentProfile`);
  }

  public getCurrentUserProfileByUpdateId(updateId: string): Observable<UserProfile> {
    return this.get(`getCurrentUserProfileByUpdateId?updateId=${updateId}`);
  }

  public getCurrentProfileRoleRefs(): Observable<RoleRef[]> {
    return this.get(`getCurrentProfileRoleRefs`);
  }

  public getGroupInvitation(invitationId: string): Observable<GroupInvitation> {
    return this.get(`getGroupInvitation?invitationId=${invitationId}`);
  }

  // Was: getGroupInvitationURL
  // TODO: Update calling component
  public getGroupInvitationUrl(invitationId: string): Observable<string> {
    return this.get(`getGroupInvitationUrl?invitationId=` + invitationId);
  }

  public getPendingUserProfiles(): Observable<UserProfile[]> {
    return this.get(`getPendingUserProfiles`);
  }

  public getProfilesByEmail(id: string): Observable<UserProfile[]> {
    return this.get(`getProfilesByEmail?email=${id}`);
  }

  public getProfilesByGroupInvitationId(groupInvitationId: string): Observable<GroupInvitationProfileTableData[]> {
    return this.get(`getProfilesByGroupInvitationId?groupInvitationId=${groupInvitationId}`);
  }

  public getUserProfile(): Observable<UserProfile> {
    return this.get(`getUserProfile`);
  }

  public getUserProfileById(id: string): Observable<UserProfile> {
    return this.get(`getUserProfileById?id=${id}`);
  }

  // TODO: Remove, you should NEVER return more than ONE current user profile
  public getUserByPkiDn(pkiDn: string): Observable<CurrentUserProfile[]> {
    return this.get(`getUserByPkiDn?pkiDn=${pkiDn}`);
  }

  public getUserProfilesByPkiDn(pkiDn: string): Observable<UserProfile[]> {
    return this.get(`getUserProfilesByPkiDn?pkiDn=${pkiDn}`);
  }

  public getTotalPendingUserProfiles(): number {
    // const pendingUserProfiles: UserProfile[] = this.get(`getPendingUserProfiles');
    // TODO: Move count to DAO call, this is very inefficient...
    return 0;
  }

  public lockUserProfile(userProfileId: string, reason: string): Observable<UserProfile> {
    return this.get(`lockUserProfile?userProfileId=${userProfileId}&reason=${reason}`);
  }

  public logout(): Observable<boolean> {
    return this.get(`logout`);
  }

  public requestPkiDnUpdate(userEmail: string): Observable<UserProfile>  {
    return this.get(`requestPkiDnUpdate?userEmail=${userEmail}`);
  }

  // Was: invitationResend
  // TODO: Update calling component
  public resendInvitation(invitationId: string): Observable<UserProfile> {
    return this.get(`resendInvitation?invitationId=${invitationId}`);
  }

  public saveUserProfilePermissions(userProfile: UserProfile): Observable<UserProfile>  {
    return this.post(`saveUserPermissions`, userProfile);
  }

  public saveUserProfileRoles(userProfile: UserProfile): Observable<UserProfile>  {
    return this.post(`saveUserRoles`, userProfile);
  }

  public setCurrentNodeRef(id: string): Observable<NodeRef> {
    return this.get(`setCurrentNodeRef?id=${id}`);
  }

  public setCurrentProfile(id: string): Observable<CurrentUserProfile> {
    return this.get(`setCurrentProfile?id=${id}`);
  }

  public suspendUserProfile(userProfileId: string, reason: string, startDate: Date, endDate: Date) {
    return this.get(`suspendUserProfile?userProfileId=${userProfileId}&reason=${reason}&startDate=${startDate}&endDate=${endDate}`);
  }

  public unlockUserProfile(userProfileId: string): Observable<UserProfile> {
    return this.get(`unlockUserProfile?userProfileId=${userProfileId}`);
  }

  public updateGroupInvitation(groupInvitation: GroupInvitation): Observable<GroupInvitation> {
    return this.post(`updateGroupInvitation`, groupInvitation);
  }

  public updateMyProfileInfo(profileUpdate: UserProfile): Observable<UserProfile> {
    // TODO the bt is defining and mapping to a 'MyProfileUpdate' object should be a UserProfile object
    const myProfileUpdate = {id: profileUpdate.id, profileName: profileUpdate.profileName,
      firstName: profileUpdate.firstName, lastName: profileUpdate.lastName,
      email: profileUpdate.email,
      phoneNumbers: profileUpdate.phoneNumbers};
    return this.post(`updateMyProfileInfo`, myProfileUpdate);
  }

  public updatePkiDnForUser(updateId: string): Observable<UserProfile> {
    return this.post(`updatePkiDnForUser`, updateId);
  }

  public updateProfileAccess(userProfile: UserProfile): Observable<UserProfile> {
    return this.post(`updateProfileAccess`, userProfile);
  }

  public updateProfileByAdmin(profileUpdate: UserProfile): Observable<UserProfile> {
    return this.post(`updateProfileByAdmin`, profileUpdate);
  }

  public updateProfileInvitationByAdmin(profileUpdate: UserProfile): Observable<UserProfile> {
    return this.post(`updateProfileInvitationByAdmin`, profileUpdate);
  }

}
