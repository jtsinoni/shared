import {TestBed, inject} from '@angular/core/testing';

import {WindowService} from './window.service';
import {LoggerService} from './logger/logger.service';
import {UtilService} from './util.service';
import {CurrencyPipe} from '@angular/common';

describe('WindowService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WindowService, LoggerService, UtilService, CurrencyPipe]
    });
  });

  it('should be created', inject([WindowService], (service: WindowService) => {
    expect(service).toBeTruthy();
  }));

  it('should create access to the window object',
    inject([WindowService], (service: WindowService) => {
      expect(service.window).toBeTruthy();
    }));
});
