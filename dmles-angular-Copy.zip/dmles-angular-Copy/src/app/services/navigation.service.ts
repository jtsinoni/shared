import {Injectable} from '@angular/core';
import {LoggerService} from './logger/logger.service';
import {
  ActivatedRoute, ActivatedRouteSnapshot, CanActivate, CanActivateChild, CanDeactivate, Route, Router,
  RouterStateSnapshot,
  UrlSegment
} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import {PermissionService} from './permission.service';
import {StateConstants} from '../constants/state.constants';

@Injectable()
export class NavigationService implements CanActivate, CanActivateChild {

  private serviceName = 'navigationService';

  get currentPath (): string {
  return this.path;
  }

  get currentRoute (): ActivatedRouteSnapshot[]  {
    return this.routeSnapshot;
  }

  private routeSnapshot: ActivatedRouteSnapshot[];
  private path: string;
  private previousRoute: string;

  constructor(private logger: LoggerService, private permissionService: PermissionService) {
    this.logger.info(`In service: ${this.serviceName}`);
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean>
    | Promise<boolean> | boolean {
    // this.logger.debug(`Can Activate: what is the state url: ${state.url}`);
    // this.logger.debug(`Can Activate: what is the route data: ${JSON.stringify(route.data)}`);
    // this.logger.debug(`Can Activate: what is the PATH FROM ROOT: ${route.pathFromRoot}`);
    this.permissionService.checkStates(state.url);
    this.path = state.url;
    this.routeSnapshot = route.pathFromRoot;
    this.setPreviousRoute();
    // this.logger.debug(`what is the path from root ${this.path}`);
    return true;
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean>
    | Promise<boolean> | boolean {
    // this.logger.debug(`Can Activate child: what is the child state url: ${state.url}`);
    // this.logger.debug(`Can Activate child: what is the child route data: ${JSON.stringify(childRoute.data)}`);

    this.permissionService.checkStates(state.url);
    this.path = state.url;
    return true;
  }

  public navigateRelativeTo(router: Router, location: string, activatedRoute: ActivatedRoute): Promise<boolean> {
    const link = ['../' + location];
    return router.navigate(link, {relativeTo: activatedRoute});
  }

  public navigateTo(router: Router, location: string, destination?: string): Promise<boolean> {
    const link = destination ?  ['/' + this.previousRoute + '/' + location + '/' + destination] :
      ['/' + this.previousRoute + '/' + location];
    return router.navigate(link);
  }

  public navigateDirectlyTo(router: Router, location: string): Promise<boolean> {
    const link = ['/' + location];
    return router.navigate(link);
  }

  public navigateFromHomeTo(router: Router, location: string): Promise<boolean> {
    const link = ['/' + StateConstants.HOME_ROOT + '/' + location];
    return router.navigate(link);
  }




  private setPreviousRoute() {
    const routeLength = this.currentRoute.length;
    let count: number = 0;
    this.previousRoute = '';
    while (count < (routeLength - 1)) {
      for (const segment of this.currentRoute[count].url) {
        this.previousRoute += `/${segment.path}`;
      }
      count++;
    }
    this.logger.debug(`what is the previous ROUTE***: ${this.previousRoute}`);
  }




}
