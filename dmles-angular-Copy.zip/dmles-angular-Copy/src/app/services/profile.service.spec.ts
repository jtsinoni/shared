import { TestBed, inject } from '@angular/core/testing';

import { ProfileService } from './profile.service';
import {ProfileApiService} from './profile-api.service';
import {MainNavService} from '../home/main-nav/main-nav.service';
import {OAuthService} from './oauth.service';
import {LoginService} from './login.service';
import {RouterTestingModule} from '@angular/router/testing';
import {LoggerService} from './logger/logger.service';
import {HttpClient, HttpClientModule, HttpHandler} from '@angular/common/http';
import {AuthenticationService} from './authentication.service';
import {StorageService} from './storage.service';
import {WindowService} from './window.service';
import {UtilService} from './util.service';
import {CurrencyPipe} from '@angular/common';
import {Base64Service} from './base64.service';

describe('ProfileService', () => {
  let http: HttpClient;
  let logger: LoggerService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileService, ProfileApiService, MainNavService, HttpClientModule, HttpClient,
        HttpHandler, AuthenticationService, StorageService, OAuthService, RouterTestingModule, LoginService,
        LoggerService, WindowService, UtilService, CurrencyPipe, Base64Service],
      imports: [RouterTestingModule]
    });
    http = TestBed.get(HttpClient);
    logger = TestBed.get(LoggerService);
  });

  it('should be created', inject([ProfileService], (service: ProfileService) => {
    expect(service).toBeTruthy();
  }));
});
