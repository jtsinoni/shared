import {Injectable} from '@angular/core';
import {Router} from '@angular/router';

import {StateConstants} from '../constants/state.constants';
import {CurrentUserProfile} from '../models/current-user-profile.model';
import {RoleRef} from '../models/role-ref.model';
import {UserProfile} from '../models/user-profile.model';

import {LoginService} from './login.service';
import {ProfileApiService} from './profile-api.service';
import {MainNavService} from '../home/main-nav/main-nav.service';
import {OAuthService} from './oauth.service';
import {LoggerService} from './logger/logger.service';
import {NodeRef} from '../models/node-ref-data.model';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import {AuthenticationService} from './authentication.service';

@Injectable()
export class ProfileService {

  private serviceName = 'ProfileService';
  // private goToDash: boolean;

  public currRoles: Array<RoleRef> = [];
  public selectedAccess: NodeRef = new NodeRef();
  public selectedProfile: UserProfile = new UserProfile();
  public profiles: Array<UserProfile> = [];
  public access: Array<NodeRef> = [];

  constructor(private logger: LoggerService,
              private profileApiService: ProfileApiService,
              private mainNavService: MainNavService,
              private oAuthService: OAuthService,
              private loginService: LoginService,
              private authenticationService: AuthenticationService) {
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public getProfileData(needDash?: boolean): void {
    // if (needDash){
    //   this.goToDash = needDash;
    // }
    this.profileApiService.getActiveUserProfiles().subscribe((userProfiles: UserProfile[]) => {
      this.profiles = <UserProfile[]> JSON.parse(JSON.stringify(userProfiles));
      Object.values(userProfiles).forEach((value) => {
        if (this.loginService.currentUser.id === value.id){
          this.selectedProfile = value;
        }
      });
      this.getRoles();
    });
  }

  private getRoles(): void {
    this.profileApiService.getCurrentProfileRoleRefs().subscribe((roleRefs: RoleRef[]) => {
      this.currRoles = <RoleRef[]> JSON.parse(JSON.stringify(roleRefs));
      return this.getAccess();
      // this.access = this.loginService.currentUser.accessToNodes;
      // Object.values(this.loginService.currentUser.accessToNodes).forEach((value) => {
      //   if (this.loginService.currentUser.currentNodeRef.id === value.id) {
      //     this.selectedAccess = value;
      //   }
      // });
    });
  }

  private getAccess(): void {
    this.access = this.loginService.currentUser.accessToNodes;
    Object.values(this.loginService.currentUser.accessToNodes).forEach((value) => {
      if (this.loginService.currentUser.currentNodeRef.id === value.id) {
        this.selectedAccess = value;
      }
    });
    // if (this.goToDash){
    //   // this.router.navigate(StateConstants.createLink(StateConstants.MY_DASHBOARD));
    //   // this.navigationService.navigateTo(this.router, StateConstants.MY_DASHBOARD);
    // }
  }

  private initNewCurrentProfile(): void {
    this.oAuthService.getNewToken(this.loginService.currentUser.pkiDn).subscribe((response) => {
      this.loginService.signIn().subscribe((signedInProfile: CurrentUserProfile) => {
        this.loginService.currentUser = signedInProfile;
        this.authenticationService.updateCurrentUser(signedInProfile);
        this.mainNavService.loadMyNavPerRole();
        this.getProfileData();
      });
    });
  }

  // private needDashNav(goToDash: boolean): void {
  //   if (goToDash){
  //     this.goToDash = true;
  //     // this.router.navigate(StateConstants.createLink(StateConstants.LOADING));
  //     this.navigationService.navigateTo(this.router, StateConstants.LOADING);
  //   }else{
  //     this.goToDash = false;
  //   }
  // }

  public loadData(needDash?: boolean){
      this.getProfileData(needDash);
  }

  public changeAccess(goToDash: boolean): void {
    // this.needDashNav(goToDash);
    this.profileApiService.setCurrentNodeRef(this.selectedAccess.id).subscribe((nodeRef: NodeRef) => {
      this.initNewCurrentProfile();
    });
  }

  public changeProfile(goToDash: boolean): void {
    // this.needDashNav(goToDash);
    this.profileApiService.setCurrentProfile(this.selectedProfile.id).subscribe((currentProfile: CurrentUserProfile) => {
      this.initNewCurrentProfile();
    });
  }

  public logOut(): Observable<boolean> {
    return this.profileApiService.logout();
  }

  public changeProfile2(newProfileId?: string): Observable<any> {

    const changeCurrentProfile = (newProfileId?: string) => {
      if (newProfileId) {
        this.selectedProfile.id = newProfileId;
      }
      this.logger.debug(`in changeCurrentProfile ID: ${newProfileId}`);
      return this.profileApiService.setCurrentProfile(this.selectedProfile.id);
    };

    const initializeCurrentProfile = () => {
      this.logger.debug('in initializeCurrentProfile');

      return this.oAuthService.getNewToken(this.loginService.currentUser.pkiDn);
    };

    const logInNewProfile = () => {
      this.logger.debug('in logInNewProfile');

      return this.loginService.signIn().map((signedInProfile: CurrentUserProfile) => {
        this.loginService.currentUser = signedInProfile;
        this.logger.debug(`new current user profile NAME:  ${this.loginService.currentUser.profileName}`);
        this.authenticationService.updateCurrentUser(signedInProfile);
        this.mainNavService.loadMyNavPerRole();
      });
    };

    const getProfileData = () => {
      this.logger.debug('in getProfileData');
      return this.profileApiService.getActiveUserProfiles().map((userProfiles: UserProfile[]) => {
        this.logger.debug(`user profiles data ^^^^^^^^^^^ ${userProfiles}`);
        this.profiles = <UserProfile[]> JSON.parse(JSON.stringify(userProfiles));
        Object.values(userProfiles).forEach((value) => {
          if (this.loginService.currentUser.id === value.id) {
            this.selectedProfile = value;
            this.logger.debug(`Got a selected profile xxxxxx: ${this.selectedProfile.profileName}`);
          }
          return;
        });
      });
    };

    const getRoles = () => {
      this.logger.debug('in getRoles()');
      return this.profileApiService.getCurrentProfileRoleRefs().map((roleRefs: RoleRef[]) => {
        this.currRoles = <RoleRef[]> JSON.parse(JSON.stringify(roleRefs));
       });
    };

    const getAccess = () => {
      this.access = this.loginService.currentUser.accessToNodes;
      this.logger.debug(`In getAccess,current user profile ${JSON.stringify(this.loginService.currentUser.profileName)}`);
      Object.values(this.loginService.currentUser.accessToNodes).forEach((value) => {
        if (this.loginService.currentUser.currentNodeRef.id === value.id) {
          this.selectedAccess = value;
        } else {
          this.logger.debug('****cant find SELECTED ACCESSS******');
        }
      });
    };

    return changeCurrentProfile(newProfileId)
      .map(initializeCurrentProfile) // need to pass or store data between these
      .map(logInNewProfile)
      .map(getProfileData)
      .map(getRoles)
      .map(getAccess);
  }

}
