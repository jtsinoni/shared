import { TestBed, inject } from '@angular/core/testing';

import { Base64Service } from './base64.service';

describe('Base64Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Base64Service]
    });
  });

  it('should be created', inject([Base64Service], (service: Base64Service) => {
    expect(service).toBeTruthy();
  }));

  it('encodes text value', inject([Base64Service], (service: Base64Service) => {
    const value: string = service.b64EncodeUnicode('hello world');
    const expectedValue: string = 'aGVsbG8gd29ybGQ=';
    expect(value).toEqual(expectedValue);
  }));

  it('decodes text value', inject([Base64Service], (service: Base64Service) => {
    const value: string = service.b64DecodeUnicode('aGVsbG8gd29ybGQ=');
    const expectedValue: string = 'hello world';
    expect(value).toEqual(expectedValue);
  }));
});
