import { TestBed, inject } from '@angular/core/testing';
import { NotificationService } from './notification.service';
import { LoggerService } from './logger/logger.service';
import { ToastrService, ToastrModule  } from 'ngx-toastr';

describe('NotificationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ToastrModule.forRoot()],
      providers: [NotificationService, LoggerService, ToastrService]
    });
  });

  it('should be created', inject([NotificationService], (service: NotificationService) => {
    expect(service).toBeTruthy();
  }));
});
