import { async, TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpHeaders, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';
import { OAuthService } from './oauth.service';
import {LoggerService} from '../services/logger/logger.service';
import { AppConfig } from '../app.config';
import { HeaderNameValue } from './api.service';
import { ApiConstants } from '../constants/api.constants';
import { StorageService } from './storage.service';
import { WindowService } from './window.service';
import { UtilService } from './util.service';
import { AuthenticationService } from './authentication.service';
import { Base64Service } from './base64.service';

describe('OAuthService', () => {
  let logger: LoggerService;
  let service: OAuthService;
  let httpMock: HttpTestingController;
  let url: string;
  let urlAction: string;
  let encodedDN: string;

  function matchHttpHeaders(req: HttpRequest<any>): boolean {
    return req.url === url
      && req.method === 'POST'
      && req.headers.get('Authorization').includes(`Basic ${encodedDN}`)
      && req.headers.get('ClientId') === 'dmles'
      && req.headers.get('Access-Control-Allow-Origin') === '*'
      && req.headers.get('Content-Type') === 'application/json';
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [LoggerService, OAuthService, AuthenticationService, Base64Service,
                  StorageService, WindowService, UtilService, CurrencyPipe],
    });
    AppConfig.BT_BASE_URL = 'https://localhost:4431/';

    logger = TestBed.get(LoggerService);
    service = TestBed.get(OAuthService);
    httpMock = TestBed.get(HttpTestingController);
    urlAction = 'token';
    url = AppConfig.BT_BASE_URL + ApiConstants.OAUTH_API + urlAction;
    encodedDN = 'SGVsbG8gV29ybGQ=';  // Hello World
  }));

  afterEach(() => {
    httpMock.verify();
  });

  it('should compile', () => {
    expect(service).toBeTruthy();
  });

  it('should return fake token via oAuth', () => {
    service.getNewToken('')
      .subscribe((data) => {
        // data or JWT token must have two "." in it
        const matches: number = data.match(/\./gi).length;
        expect(matches).toBe(2);
    });

    const mockToken: any = {'authctoken': 'eyJhbGc.wdjwqgeh.kwjekjqwe'};
    httpMock.match({
      url: url,
      method: 'POST'
    })[0].flush(mockToken);
  });

  describe('getNewToken', () => {
    let authenticationService: AuthenticationService;
    const token: string = 'eyJhbGc.wdjwqgeh.kwjekjqwe';
    beforeEach(() => {
      authenticationService = TestBed.get(AuthenticationService);
      authenticationService.saveToken(token);
    });

    afterEach(() => {
      authenticationService.logout();
    });

    it('should return token from session storage', () => {
      service.getToken(token)
        .subscribe((data) => {
          expect(token).toEqual(data);
        });
    });
  });

  it('getTokenViaOAuth should contain correct headers in request', () => {
    service.getTokenViaOAuth(urlAction, encodedDN).subscribe();

    httpMock.expectOne((req: HttpRequest<any>) => {
      return matchHttpHeaders(req);
    }, 'Find matching headers in Request');
  });

  it('getTokenViaOAuthForPkiDnUpdate should contain correct headers in request', () => {
    const updateIdHeader: HeaderNameValue = {name: 'UpdateId', value: '123456'};
    const headers: HeaderNameValue[] = [updateIdHeader];
    service.getTokenViaOAuthForPkiDnUpdate(urlAction, encodedDN, updateIdHeader.value).subscribe();


    httpMock.expectOne((req: HttpRequest<any>) => {
      return matchHttpHeaders(req)
        && req.headers.has(updateIdHeader.name);
    }, 'Find matching headers in PkiDnUpdate Request');
  });

  it('getTokenViaOAuthForInvitation should contain correct headers in SINGLE request', () => {
    const invitationIdHeader: HeaderNameValue = {name: 'InvitationId', value: '123456'};
    const invitationTypeHeader: HeaderNameValue = {name: 'InvitationType', value: 'SINGLE'};
    const headers: HeaderNameValue[] = [invitationIdHeader, invitationTypeHeader];
    service.getTokenViaOAuthForInvitation(urlAction, encodedDN, invitationIdHeader.value, invitationTypeHeader.value).subscribe();

    httpMock.expectOne((req: HttpRequest<any>) => {
      return matchHttpHeaders(req)
        && req.headers.has(invitationIdHeader.name)
        && req.headers.has(invitationTypeHeader.name);
    }, 'Find matching headers in Invitation SINGLE Request');
  });

  it('getTokenViaOAuthForInvitation should contain correct headers in GROUP request', () => {
    const invitationIdHeader: HeaderNameValue = {name: 'InvitationId', value: '123456'};
    const invitationTypeHeader: HeaderNameValue = {name: 'InvitationType', value: 'GROUP'};
    const headers: HeaderNameValue[] = [invitationIdHeader, invitationTypeHeader];
    service.getTokenViaOAuthForInvitation(urlAction, encodedDN, invitationIdHeader.value, invitationTypeHeader.value).subscribe();

    httpMock.expectOne((req: HttpRequest<any>) => {
      return matchHttpHeaders(req)
        && req.headers.has(invitationIdHeader.name)
        && req.headers.has(invitationTypeHeader.name);
    }, 'Find matching headers in Invitation GROUP Request');
  });
});
