import { TestBed, inject, async } from '@angular/core/testing';

import { LoginService } from './login.service';
import {LoggerService} from './logger/logger.service';
import {ProfileApiService} from './profile-api.service';
import {HttpClientModule, HttpClient, HttpHandler} from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { StorageService } from './storage.service';
import { WindowService } from './window.service';
import { UtilService } from './util.service';
import { CurrencyPipe } from '@angular/common';
import {RouterTestingModule} from '@angular/router/testing';

describe('LoginService', () => {
  let http: HttpClient;
  let logger: LoggerService;
  let authenticationService;
  let loginService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoginService, LoggerService, ProfileApiService, HttpClientModule, HttpClient,
                  HttpHandler, AuthenticationService,
                  StorageService, WindowService, UtilService, CurrencyPipe, AuthenticationService],
      imports: [RouterTestingModule],
    });
    http = TestBed.get(HttpClient);
    logger = TestBed.get(LoggerService);
    authenticationService = TestBed.get(AuthenticationService);
    loginService = TestBed.get(LoginService);

  });

  it('should be created', inject([LoginService], (service: LoginService) => {
    expect(service).toBeTruthy();
  }));
});
