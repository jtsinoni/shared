import {Injectable} from '@angular/core';
import {LoggerService} from './logger/logger.service';
import {StorageService} from './storage.service';
import {ApiConstants} from '../constants/api.constants';
import {CurrentUserProfile} from '../models/current-user-profile.model';

@Injectable()
export class AuthenticationService {
  private serviceName = 'AuthenticationService';

  constructor(private logger: LoggerService,
              private storageService: StorageService) {
    this.logger.debug(`${this.serviceName} - Start`);
  }

  public getToken(): any {
    return this.storageService.getData(ApiConstants.DMLES_TOKEN);
  }

  public getCurrentUser(): CurrentUserProfile {
     return this.storageService.getData(ApiConstants.DMLES_USER);
  }

  public isLoggedIn(): boolean {
    return !!this.getToken();
  }

  public logout() {
    this.logger.debug('USER logged out');
    this.storageService.removeData(ApiConstants.DMLES_TOKEN);
    this.storageService.removeData(ApiConstants.DMLES_USER);
    this.storageService.clearData();
  }

  public saveToken(token) {
    this.storageService.storeData(ApiConstants.DMLES_TOKEN, token, false);
  }

  public saveCurrentUser(currentUser: CurrentUserProfile) {
    this.storageService.storeData(ApiConstants.DMLES_USER, currentUser, true);
  }

  public updateCurrentUser(currentUser: CurrentUserProfile) {
    this.storageService.removeData(ApiConstants.DMLES_USER);
    this.saveCurrentUser(currentUser);

  }
}
