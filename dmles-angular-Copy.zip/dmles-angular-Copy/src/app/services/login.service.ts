import {DoCheck, Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, CanActivateChild, Router, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/of';

import {CurrentUserProfile} from '../models/current-user-profile.model';
import {LoggerService} from './logger/logger.service';
import {ProfileApiService} from './profile-api.service';
import {AuthenticationService} from './authentication.service';
import {UserProfile} from '../models/user-profile.model';

@Injectable()
export class LoginService implements CanActivate, CanActivateChild {
  private serviceName = 'LoginService';
  protected __currentUser: CurrentUserProfile;
  public pkiDn: string = null;
  private ok: boolean = true;
  public securityAccepted: boolean = false;

  get currentUser(): CurrentUserProfile {
    // this.logger.warn(`getting currentUser`);
    if (!this.__currentUser) {
      this.loadCurrentUser().subscribe((data) => {
        this.__currentUser = {...data};
        // this.logger.warn(`returning currentUser`);
        return this.__currentUser;
      });
    } else {
      return this.__currentUser;
    }
  }

  set currentUser(currentUser: CurrentUserProfile) {
    // this.logger.warn(`setting currentUser`);
    this.__currentUser = currentUser;
  }

  constructor(private logger: LoggerService,
              private router: Router,
              private profileApiService: ProfileApiService,
              private authentication: AuthenticationService) {
    this.logger.debug(`${this.serviceName} - Start`);
    this.loadCurrentUser();  // Needed this loaded earlier...
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> |
    Promise<boolean> | boolean {
    // TODO if currentUser is not null...
    // then do some check of Route and State
    return this.ok;
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> |
    Promise<boolean> | boolean {
    return this.ok;
  }

  private setAndReturnCurrentUserProfile(data: CurrentUserProfile): CurrentUserProfile {
    this.logger.info('!! Current user profile set: %s', data);
    this.setCurrentUser(data);
    return this.currentUser;
  }

  private loadCurrentUser(): Observable<CurrentUserProfile> {
    if (this.authentication.isLoggedIn()) {
      this.currentUser = this.authentication.getCurrentUser();
      return Observable.of(this.currentUser);
    } else {
      return this.signIn()
        .map((result: CurrentUserProfile) => {
          return this.setAndReturnCurrentUserProfile(result);
        });
    }
  }

  private setCurrentUser(currentUserProfile: CurrentUserProfile) {
    this.currentUser = {...currentUserProfile};
    this.authentication.saveCurrentUser(this.currentUser);

  }

  public signIn(): Observable<CurrentUserProfile> {
    return this.profileApiService.get('signIn')
      .map((result) => {
        return this.setAndReturnCurrentUserProfile(result);
      });
  }

  public updateCurrentUser(userProfile: UserProfile) {
    this.currentUser.profileName = userProfile.profileName;
    this.currentUser.lastName = userProfile.lastName;
    this.currentUser.firstName = userProfile.firstName;
    this.currentUser.email = userProfile.email;
    this.currentUser.phoneNumbers[0].value = userProfile.phoneNumbers[0].value;
    this.authentication.saveCurrentUser(this.currentUser);
  }
}
