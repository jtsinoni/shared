import { ModuleWithProviders, NgModule } from '@angular/core';
import { Base64Service } from './base64.service';
import { LoggerModule } from './logger/logger.module';
import { UtilService } from './util.service';
import { OAuthService } from './oauth.service';
import { LoggerService } from './logger/logger.service';
import { LoginService } from './login.service';
import { PermissionService } from './permission.service';
import { StorageService } from './storage.service';
import { WindowService } from './window.service';
import { AppHeaderService} from './app-header.service';
import { AuthenticationService} from './authentication.service';
import { CurrencyPipe} from '@angular/common';
import { ProfileApiService } from './profile-api.service';
import { ProfileService } from './profile.service';
import { NotificationService } from './notification.service';
import { SidePanelService } from './side-panel.service';

@NgModule({
  imports: [LoggerModule],
})
export class ServicesModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ServicesModule,
      providers: [
        Base64Service,
        AppHeaderService,
        LoginService,
        OAuthService,
        PermissionService,
        StorageService,
        UtilService,
        LoggerService,
        WindowService,
        AuthenticationService,
        CurrencyPipe,
        ProfileApiService,
        ProfileService,
        NotificationService,
        SidePanelService,
      ]
    };
  }
}
