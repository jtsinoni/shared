import { TestBed, inject } from '@angular/core/testing';
import {HttpClient, HttpClientModule, HttpHandler} from '@angular/common/http';
import { ProfileApiService } from './profile-api.service';
import {LoggerService} from './logger/logger.service';
import { AuthenticationService } from './authentication.service';
import { StorageService } from './storage.service';
import { WindowService } from './window.service';
import { UtilService } from './util.service';
import { CurrencyPipe } from '@angular/common';

describe('ProfileApiService', () => {
  let http: HttpClient;
  let logger: LoggerService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileApiService, HttpClientModule, HttpClient, LoggerService,
                  HttpHandler, AuthenticationService, StorageService, WindowService, UtilService, CurrencyPipe],
    });
    http = TestBed.get(HttpClient);
    logger = TestBed.get(LoggerService);

  });

  it('should be created', inject([ProfileApiService], (service: ProfileApiService) => {
    expect(service).toBeTruthy();
  }));
});
