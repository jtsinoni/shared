import {TestBed, inject} from '@angular/core/testing';

import {StorageService} from './storage.service';
import {LoggerService} from './logger/logger.service';
import {UtilService} from './util.service';
import {CurrencyPipe} from '@angular/common';
import {WindowService} from './window.service';

describe('StorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StorageService, LoggerService, UtilService, CurrencyPipe, WindowService, LoggerService]
    });
  });

  it('should be created', inject([StorageService], (service: StorageService) => {
    expect(service).toBeTruthy();
  }));
  it('clearData should clear session storage',
    inject([StorageService], (service: StorageService) => {
    expect(service.clearData()).toBeUndefined();
  }));
  it('#1 getData should return data from session storage',
    inject([StorageService], (service: StorageService) => {
      expect(service.getData('key')).toBeNull();
    }));
  it('#1 removeData should return null session storage',
    inject([StorageService], (service: StorageService) => {
      expect(service.removeData('key')).toBeUndefined();
    }));
  it('storeData should add data to session storage',
    inject([StorageService], (service: StorageService) => {
      expect(service.storeData('keyXXXX', {id: '1', name: 'billy'}, true)).toBeUndefined();
    }));
  it('#2 getData should return data from session storage',
    inject([StorageService], (service: StorageService) => {
      expect(service.getData('keyXXXX')).toEqual({id: '1', name: 'billy'});
    }));
  it('#2 removeData should remove data from session storage',
    inject([StorageService], (service: StorageService) => {
      expect(service.removeData('keyXXXX')).toBeUndefined();
    }));
});
