import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ApiService, HeaderNameValue } from './api.service';
import { ApiConstants } from '../constants/api.constants';
import {LoggerService} from '../services/logger/logger.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';
import { Base64Service } from './base64.service';

@Injectable()
export class OAuthService extends ApiService {
  private serviceName: string = 'OAuth Service';

  constructor(logger: LoggerService,
              http: HttpClient,
              authenticationService: AuthenticationService,
              private base64Service: Base64Service) {
    super(ApiConstants.OAUTH_API, logger, http, authenticationService);
    this.logger.info(`${this.serviceName} - Start`);
  }

  private encodeDn(dn: string): string {
    return this.base64Service.b64EncodeUnicode(dn + ':password');
  }

  private processTokenResponse(observable: Observable<any>): Observable<any> {
    return observable
      .map((result) => {
        if (result && result.authctoken) {
          const token: any = result.authctoken;
          this.authenticationService.saveToken(token);
          this.logger.debug(`${this.serviceName} - New token received and saved`);
          return token;
        } else {
          this.logger.debug(`${this.serviceName} - New token NOT received and saved!`);
          return null;
        }
      });
  }

  private getOAuthToken(action: string, encodedDn: string, moreHeaders?: HeaderNameValue[]): Observable<any> {
    const url: string = this.determineUrl(action);
    // this.logger.info(`${this.serviceName} - BT getToken URL: ${url}`);

    const headers: HttpHeaders = this.getHeader('POST', 'Basic', encodedDn, moreHeaders);
    return this.post(action, {}, headers);
  }

  public getTokenViaOAuth(action: string, encodedDn: string,  moreHeaders?: HeaderNameValue[]): Observable<any> {
    return this.getOAuthToken(action, encodedDn, moreHeaders);
  }

  public getTokenViaOAuthForInvitation(action: string, encodedDn: string, invitationId: string, invitationType: string): Observable<any> {
    const moreHeaders: HeaderNameValue[] = [{name: 'InvitationId', value: invitationId},
                                            {name: 'InvitationType', value: invitationType}];
    return this.getOAuthToken(action, encodedDn, moreHeaders);
  }

  public getTokenViaOAuthForPkiDnUpdate(action: string, encodedDn: string, updateId: string): Observable<any> {
    const moreHeaders: HeaderNameValue[] = [{name: 'UpdateId', value: updateId}];
    return this.getOAuthToken(action, encodedDn, moreHeaders);
  }

  public getToken(dn: string): Observable<any> {
    const token = this.authenticationService.getToken();
    if (!token) {
      return this.getNewToken(dn);
    } else {
      return Observable.create((observer) => {
        observer.next(token);
      });
    }
  }

  public getNewToken(dn: string): Observable<any> {
    const observable: Observable<any> = this.getTokenViaOAuth('token', this.encodeDn(dn));
    return this.processTokenResponse(observable);
  }

  public getNewTokenForInvitation(dn: string, invitationId: string, invitationType: string): Observable<any> {
    const observable: Observable<any> = this.getTokenViaOAuthForInvitation('token', this.encodeDn(dn), invitationId, invitationType);
    return this.processTokenResponse(observable);
  }

  public getNewTokenForPkiDnUpdate(dn: string, updateId: string): Observable<any> {
    const observable: Observable<any> = this.getTokenViaOAuthForPkiDnUpdate('token', this.encodeDn(dn), updateId);
    return this.processTokenResponse(observable);
  }
}
