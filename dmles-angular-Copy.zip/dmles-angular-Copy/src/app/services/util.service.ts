import {Inject, Injectable} from '@angular/core';
import { ContentConstants } from '../constants/content.constants';
import {CurrencyPipe} from '@angular/common';

// @Inject(CurrencyPipe) private currencyPipe: CurrencyPipe
@Injectable()
export class UtilService {
  constructor(private currencyPipe: CurrencyPipe) { }

    public addZero(i) {
        if (i < 10) {
            i = '0' + i;
        }
        return i;
    }

    public convertCamelCaseToText(camelCaseText) {
        const result = camelCaseText.replace(/([A-Z])/g, ' $1');
        return (result.charAt(0).toUpperCase() + result.slice(1)).trim();
    }

    public convertCurrencyToFloat(currency) {
        if (!currency) {
            currency = '$0.00';
        }
        return Number(currency.replace(/[^0-9\.]+/g, ''));
    }

    public convertFloatToCurrency(amount) {
        if (!amount) {
            amount = 0;
        }
        const currency = this.currencyPipe.transform(amount, 'USD');
        return currency;
    }

    public detectIE(): number {
        const ua = window.navigator.userAgent;

        // Test values; Uncomment to check result …

        // IE 10
        // ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';

        // IE 11
        // ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';

        // IE 12 / Spartan
        // ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko)
        // Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';

        // Edge (IE 12+)
        // ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)
        // Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';

        const msie = ua.indexOf('MSIE ');
        if (msie > 0) {
            // IE 10 or older => return version number
            return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
        }

        const trident = ua.indexOf('Trident/');
        if (trident > 0) {
            // IE 11 => return version number
            const rv = ua.indexOf('rv:');
            return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
        }

        const edge = ua.indexOf('Edge/');
        if (edge > 0) {
            // Edge (IE 12+) => return version number
            return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
        }

        // other browser
        return 0;
    }

    public esBuildSearchStatsStr(numResults: string, time: string) {
        const searchStatsStr: string = numResults + ' item(s) found ( ' + time + ' milliseconds )';
        return searchStatsStr;
    }

    /**
    * Escape special characters that might be embedded in the user-input search string(s)
    * not doing this causes issues for elasticsearch
    */
    public esEscapeSpecialChars(searchInput: string) {
        const escapedInput: string = searchInput.replace(/[!@#$%^&()+=\-[\]\\';,./{}|":<>?~_]/g, '\\$&');
        return escapedInput;
    }

    public getDateInMillis() {
        const d = new Date();
        return d.getTime();
    }

    public getDate(d: Date) {
        const yr = d.getFullYear();
        const mn = this.addZero(d.getMonth());
        const dy = this.addZero(d.getDay());
        return yr + '-' + mn + '-' + dy;
    }

    public getDateTime(dateVar) {
        let d = new Date();
        if (dateVar) {
            d = dateVar;
        }
        const nowDateStr = this.getDate(d);
        const nowTimeStr = this.getTime(d);
        const currFullStr = nowDateStr + ' ' + nowTimeStr;
        return currFullStr;
    }

    public getHashLength(hash) {
        return Object.keys(hash).length;
    }

    public getTime(d) {
        const h = this.addZero(d.getHours());
        const m = this.addZero(d.getMinutes());
        const s = this.addZero(d.getSeconds());
        const ms = d.getMilliseconds();
        return h + ':' + m + ':' + s + '.' + ms;
    }

    // not used
    public getYears(numOfYears) {
        const currDate = new Date();
        const years = [];
        for (let i = 0; i < numOfYears; i++) {
            years.push(currDate.getFullYear() + i);
        }
        return years;
    }

    public isStringFound(searchFor, searchWithin) {
        let isFound = false;
        if (searchWithin.indexOf(searchFor) > -1) {
            isFound = true;
        }
        return isFound;
    }

    public isObjectEmpty(obj: any) {
        let isEmpty = false;
        if (null === obj || '' === obj || this.getHashLength(obj) === 0) {
            isEmpty = true;
        }
        return isEmpty;
    }

    public objectPropsToArray(obj: any): Array<any> {
      const evilResponseProps: any = Object.keys(obj);
      const goodResponse: Array<any> = [];
      for (const prop of evilResponseProps) {
        goodResponse.push(obj[prop]);
      }
      return goodResponse;
    }

  // not used
    public replaceDoubleQuotesWithSlash(stringVar) {
        return stringVar.toString().replace(/"/g, '\\"');
    }

    /* Combines a list of json or JavaScript objects with a list of selected
    * objects from the original list, then, adds a selected
    * field to each object if the comparison field matches.
    *
    * Returns a list of JavaScript objects with the selected field where
    * the comparison is true.
    */
    // not used
    public selectionListCreation(argFullList, argSelectionList, compareField) {
        const fullList = { ...argFullList };
        const selectionList = { ...argSelectionList };
        const comboList = [];

        Object.keys(fullList).forEach((f_value, f_key) => {
            // angular.forEach(fullList, (f_value, f_key) => {
            // console.log(f_key + " : " + f_value);
            const listObj: any = f_value;
            listObj.selected = null;

            Object.keys(selectionList).forEach((s_value, s_key) => {
                // angular.forEach(selectionList, (s_value, s_key) => {
                // JavaScript objects are associative arrays, which makes this possible
                // Similar to dot notation, ex: listObj.name
                const compareListItem = listObj[compareField];
                const compareSelItem = s_value[compareField];
                if (compareListItem === compareSelItem) {
                    listObj.selected = ContentConstants.SELECTED;  // Adds selected value
                }
            });
            comboList.push(listObj);
        });
        return comboList;
    }

    /* Returns a list of all selected JavaScript objects from the selection
    * list created from the selectionListCreation function.
    */
    // not used
    public selectionListGetSelected(argComboList) {
        const comboList = { ...argComboList };
        const selectedList = [];
        Object.keys(comboList).forEach((value, key) => {
            // angular.forEach(comboList, (value, key) => {
            // if (value.selected === ContentConstants.SELECTED) {
                // TODO not sure where selected comes from: fix
             if (value === ContentConstants.SELECTED) {
                selectedList.push(value);
            }
        });
        return selectedList;
    }

    /* Updates the selection list from selected or not.  This works with a
    * standard table or list, but will not update a ng-table.
    */
    // not used
    public selectionListUpdate(selectionList, newItem, compareField) {
        Object.keys(selectionList).forEach((value: any, key) => {
            if (value.name === newItem[compareField]) {
                if (value.selected) {
                    value.selected = null;
                } else {
                    value.selected = ContentConstants.SELECTED;
                }
            }
        });
    }

    // not used
    public sortByName(arrayOfObjects, nameToCompare) {
        if (arrayOfObjects && arrayOfObjects.length > 0 && nameToCompare) {
            return arrayOfObjects.sort((a, b) => {
                const lowerA = a[nameToCompare].toLocaleLowerCase();
                const lowerB = b[nameToCompare].toLocaleLowerCase();
                if (lowerA < lowerB) {
                  return -1;
                } else if (lowerA > lowerB) {
                  return 1;
                } else {
                  return 0;
                }
            });
        } else {
            return arrayOfObjects;
        }
    }


    public sortResults(jList, prop, isAsc) {
        const jListSorted = jList.sort((a, b) => {
            if (isAsc) {
              return (a[prop] > b[prop]) ? 1 : ((a[prop] < b[prop]) ? -1 : 0);
            } else {
              return (b[prop] > a[prop]) ? 1 : ((b[prop] < a[prop]) ? -1 : 0);
            }
        });
        return jListSorted;
    }

    // not used
    public validateEmail(email) {
      // tslint:disable-next-line:max-line-length
      const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(email);
    }

    public isNullOrEmpty(obj: any): boolean {
        let isNullOrEmpty: boolean = false;
        if ((obj === null) || (typeof (obj) === 'undefined')) {
            isNullOrEmpty = true;
        } else if ((typeof (obj) === 'string') && (obj.trim() === '')) {
            isNullOrEmpty = true;
        }
        return isNullOrEmpty;
    }

    public isStringNullOrEmpty(str: string): boolean {
        let isStringNullOrEmpty: boolean = false;
        if (typeof (str) === 'string') {
            if ((str === null) || (str === undefined) || (str.trim() === '')) {
                isStringNullOrEmpty = true;
            }
        }
        return isStringNullOrEmpty;
    }

    public isNullOrUndefined(obj: any): boolean {
        let isNullOrUndefined: boolean = false;
        if ((obj === null) || (typeof (obj) === 'undefined')) {
            isNullOrUndefined = true;
        }
        return isNullOrUndefined;
    }

    public listContainsString(stringList: Array<string>, stringToCheck: string): boolean {
        let listContainsString: boolean;
        let strIndex: number;
        strIndex = stringList.indexOf(stringToCheck);
        listContainsString = (strIndex !== -1);
        return listContainsString;
    }

    public doesArrayContainString(searchString: string, sourceArray: string[]): boolean {
      let hasElement: boolean = false;
      if (sourceArray.indexOf(searchString) > -1) {
        hasElement = true;
      }
      return hasElement;
    }

    public findTheNthOccurrenceInString(sourceString: string, pattern: string, occurrence: number): number {
      const location = sourceString.length;
      let pos = -1;
      while (occurrence-- && pos++ < location){
        pos = sourceString.indexOf(pattern, pos);
        if (pos < 0) {
          break;
        }
      }
      return pos;
    }

}
