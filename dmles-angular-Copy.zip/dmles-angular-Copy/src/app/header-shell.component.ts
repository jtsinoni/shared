import {Component, OnInit} from '@angular/core';
import {AppHeaderService} from './services/app-header.service';

@Component({
  selector: 'app-header-shell',
  template: `<ng-template>
      <ng-container *ngIf="appHeaderService.showFullHeader; then homeHeader"></ng-container>
      <ng-template #homeHeader>

      </ng-template>
    </ng-template>
  `
})
export class HeaderShellComponent implements OnInit {
  // <!--<app-home-header></app-home-header>-->
  constructor(public appHeaderService: AppHeaderService) {

  }

  ngOnInit() {
  }

}
