export class PermEndpoint {

  public id: any = '';
  public businessMethod: string = '';
  public logMessage = '';
  public userMessage = '';

  constructor(obj?: PermEndpoint) {
    this.id = obj && obj.id || '';
    this.businessMethod = obj && obj.businessMethod || '';
    this.logMessage = obj && obj.logMessage || '';
    this.userMessage = obj && obj.userMessage || '';
  }
}
