export class FacetOption {

  public type: string = '';
  public value: string = '';
  public count: number = 0;
  public selected: Boolean = false;

  constructor(obj?: FacetOption) {
    this.type = obj && obj.type || '';
    this.value = obj && obj.value || '';
    this.count = obj && obj.count || 0;
    this.selected = obj && obj.selected || false;
  }

}
