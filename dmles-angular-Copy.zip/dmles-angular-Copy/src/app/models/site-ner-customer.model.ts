export class SiteNerCustomer {

  public id: any;
  public custodianFirstName: string;
  public custodianLastName: string;
  public custodianPhoneNum: string;
  public customerId: string;
  public customerName: string;
  public customerSerial: string;
  public siteDodaac: string;

  constructor(obj?: SiteNerCustomer) {
    this.id = obj && obj.id || '';
    this.custodianFirstName = obj && obj.custodianFirstName || '';
    this.custodianLastName = obj && obj.custodianLastName || '';
    this.custodianPhoneNum = obj && obj.custodianPhoneNum || '';
    this.customerId = obj && obj.customerId || '';
    this.customerName = obj && obj.customerName || '';
    this.customerSerial = obj && obj.customerSerial || '';
    this.siteDodaac = obj && obj.siteDodaac || '';
  }

}
