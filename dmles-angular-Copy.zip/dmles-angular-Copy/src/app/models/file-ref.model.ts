export class FileRef {

  public id: any;
  public uploadDateTime: Date;
  public fileId: string;
  public uploadedFileName: string;
  public fileSize: number;
  public uploadedBy: string;

  constructor(obj?: FileRef) {
    this.id = obj && obj.id || null;
    this.fileId = obj && obj.fileId || '';
    this.uploadDateTime = obj && obj.uploadDateTime || null;
    this.uploadedFileName = obj && obj.uploadedFileName || '';
    this.fileSize = obj && obj.fileSize || null;
    this.uploadedBy = obj && obj.uploadedBy || '';
  }
}
