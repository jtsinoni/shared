export class Customer {

  public id: any;
  public custodianFirstName: string;
  public custodianLastName: string;
  public custodianPhoneNum: string;
  public customerID: string;
  public customerName: string;
  public customerSerial: string;
  public siteDodaac: string;

  constructor(obj?: Customer) {
    this.id = obj && obj.id || '';
    this.custodianFirstName = obj && obj.custodianFirstName || '';
    this.custodianLastName = obj && obj.custodianLastName || '';
    this.custodianPhoneNum = obj && obj.custodianPhoneNum || '';
    this.customerID = obj && obj.customerID || '';
    this.customerName = obj && obj.customerName || '';
    this.customerSerial = obj && obj.customerSerial || '';
    this.siteDodaac = obj && obj.siteDodaac || '';
  }
}
