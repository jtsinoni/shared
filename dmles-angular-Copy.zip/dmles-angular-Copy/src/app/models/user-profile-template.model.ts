import {NodeTypeRef} from './node-type-ref.model';
import {RoleRef} from './role-ref.model';
import {NodeRef} from './node-ref-data.model';

export class UserProfileTemplate {

  public profileExpirationDate: Date;
  public currentNodeRef: NodeRef;
  public managedByNodeRef: NodeRef;
  public nodeTypeRef: NodeTypeRef;
  public scopeNodeRefs: Array<NodeRef> = [];
  public roleRefs: Array<RoleRef> = [];
  public managedByNodeRefName: string = '';
  public assignedPermissions: Array<any> = [];

  constructor() {}
}
