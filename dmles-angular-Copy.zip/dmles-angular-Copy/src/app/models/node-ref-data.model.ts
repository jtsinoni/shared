export class NodeRef {
  public id: string = '';
  public name: string = '';
  public orgId: string = '';
  public hashValue: number = 0;

  constructor() {}
}
