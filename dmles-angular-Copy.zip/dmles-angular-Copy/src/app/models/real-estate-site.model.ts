export class RealEstateSite {

  public id: string;
  public code: string;
  public name: string;

  constructor(obj?: RealEstateSite) {
    this.id = obj && obj.id || '';
    this.code = obj && obj.code || '';
    this.name = obj && obj.name || '';
  }
}
