export class GroupInvitationProfileTableData {

  public profileId: string = '';
  public invitationStatus: string = '';
  public pkiDn: string = '';
  public profileName: string = '';
  public lastName: string = '';
  public firstName: string = '';
  public email: string = '';
  public managedByNodeRefName: string = '';
  public lastLoginDate: Date;
  public updatedDate: Date;

  constructor();
  constructor(obj?: GroupInvitationProfileTableData){
    this.profileId = obj && obj.profileId || null;
    this.invitationStatus = obj && obj.invitationStatus || '';
    this.pkiDn = obj && obj.pkiDn || '';
    this.profileName = obj && obj.profileName || '';
    this.lastName = obj && obj.lastName || '';
    this.firstName = obj && obj.firstName || '';
    this.email = obj && obj.email || '';
    this.managedByNodeRefName = obj && obj.managedByNodeRefName || '';
    this.lastLoginDate = obj && obj.lastLoginDate;
    this.updatedDate = obj && obj.updatedDate;
  }

}
