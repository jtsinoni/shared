import {Invitation} from './invitation.model';
import {PkiDnUpdate} from './pki-dn-update.model';
// import {RealEstateSite} from './real-estate-site.model';
import {NodeTypeRef} from './node-type-ref.model';
import {RoleRef} from './role-ref.model';
import {NodeRef} from './node-ref-data.model';

export class UserProfile {

  public id: any = null;
  public email: string = '';
  public lastLoginDate: Date;
  public previousLoginDate: Date;
  public lastLoginIP: string;
  public previousLoginIP: string;
  public firstName: string = '';
  public lastName: string = '';
  public pkiDn: string = '';
  public phoneNumbers: Array<any> = [];
  public serviceCode: string = '';
  // public regionCode: string = '';
  public profileName: string = '';
  public assignedPermissions: Array<any> = [];
  // public userType: any = null;
  public dodaac: string = '';
  // public current: boolean = false;
  public reasonForAccess: string = '';
  public lockStartDate: Date;
  public lockEndDate: Date;
  public reason: string = '';
  public invitation: Invitation;
  public pkiDnUpdate: PkiDnUpdate;
  public updatedDate: Date;
  public updatedBy: String;
  // public appProfileType: string = '';
  public _isDeleted: boolean;
  public deletedDate: Date;
  public userProfileStatus: string;
  public profileExpirationDate: Date;
  // public realEstateSite: RealEstateSite;

  public currentNodeRef: NodeRef;
  public managedByNodeRef: NodeRef;
  public nodeTypeRef: NodeTypeRef;
  public scopeNodeRefs: Array<NodeRef> = [];
  public roleRefs: Array<RoleRef> = [];
  public managedByNodeRefName: string = '';

  constructor() {
    this.phoneNumbers = new Array();
  }
}
