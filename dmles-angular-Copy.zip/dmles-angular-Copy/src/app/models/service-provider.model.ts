import {RoleRef} from './role-ref.model';

export class ServiceProvider {


  public id: string = '';
  public name: string = '';
  public consumer: Array<RoleRef>;

  constructor(obj?: ServiceProvider) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.consumer = obj && obj.consumer || new Array();

  }
}
