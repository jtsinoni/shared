export class Contact {

  public firstName: String;
  public lastName: String;
  public title: String;
  public mobilePhone: String;
  public workPhone: String;
  public email: String;
  public website: String;

  constructor(obj?: Contact) {
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.title = obj && obj.title || '';
    this.mobilePhone = obj && obj.mobilePhone || '';
    this.workPhone = obj && obj.workPhone || '';
    this.email = obj && obj.email || '';
    this.website = obj && obj.website || '';

  }

}
