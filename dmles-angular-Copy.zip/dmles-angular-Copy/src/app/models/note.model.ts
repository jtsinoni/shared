export class Note {

  public noteText: string;
  public section: string;
  public firstName: string;
  public lastName: string;
  public dateCreated: string;
  public userId: string;

  constructor(obj?: Note) {
    this.noteText = obj && obj.noteText || '';
    this.section = obj && obj.section || '';
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.dateCreated = obj && obj.dateCreated || null;
    this.userId = obj && obj.userId || '';
  }
}
