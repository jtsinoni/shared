export class Node {

  public id: string;
  public guid: string;
  public parent: string;
  public name: string;
  public milServiceId: string;
  public providerCode: string;
  public isPrimaryOrg: Boolean;
  public orgId: string;
  public orgRef: string;
  public parentRef: string;

  constructor(obj?: Node) {
    this.id = obj && obj.id || '';
    this.guid = obj && obj.guid || '';
    this.parent = obj && obj.parent || '';
    this.name = obj && obj.name || '';
    this.milServiceId = obj && obj.milServiceId || '';
    this.providerCode = obj && obj.providerCode || '';
    this.isPrimaryOrg = obj && obj.isPrimaryOrg || false;
    this.orgId = obj && obj.orgId || '';
    this.orgRef = obj && obj.orgRef || '';
    this.parentRef = obj && obj.parentRef || '';
  }
}
