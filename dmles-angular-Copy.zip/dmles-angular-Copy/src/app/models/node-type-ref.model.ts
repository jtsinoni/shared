export class NodeTypeRef {

  public id: any = '';
  public name: string = '';
  public hashValue: number = 0;
  public level: number;

  constructor(obj?: NodeTypeRef) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.hashValue = obj && obj.hashValue || 0;
    this.level = obj && obj.level ;
  }
}
