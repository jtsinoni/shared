export class AssignedPermission {

  public id: any = '';
  public name: string = '';
  public description: string = '';
  public functionalArea: string = '';
  public allowed: Boolean = false;
  public denied: Boolean = false;
  public permissionRef: any = null;
  public permission: any = null;


  constructor(obj?: AssignedPermission) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.description = obj && obj.description || '';
    this.functionalArea = obj && obj.functionalArea || '';
    this.allowed = obj && obj.allowed || false;
    this.denied = obj && obj.denied || false;
    this.permissionRef = obj && obj.permissionRef || null;
    this.permission = obj && obj.permission || null;
  }
}
