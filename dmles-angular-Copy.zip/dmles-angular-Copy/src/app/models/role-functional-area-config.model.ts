export class RoleFunctionalAreaConfig {

  public id: any = '';
  public option: string = '';
  public displayName: string = '';

  constructor(obj?: RoleFunctionalAreaConfig) {
    this.id = obj && obj.id || '';
    this.option = obj && obj.option || '';
    this.displayName = obj && obj.displayName || '';
  }
}
