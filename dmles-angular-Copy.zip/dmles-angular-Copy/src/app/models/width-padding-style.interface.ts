export interface WidthPaddingStyle {
    width: string;
    padding: string;
}
