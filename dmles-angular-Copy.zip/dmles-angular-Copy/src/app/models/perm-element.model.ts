export class PermElement {

  public id: any = '';
  public name: string = '';
  public functionalArea: string = '';

  constructor(obj?: PermElement) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.functionalArea = obj && obj.functionalArea || '';
  }
}
