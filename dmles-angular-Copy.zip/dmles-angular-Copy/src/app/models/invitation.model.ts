export class Invitation {

  public id: string;
  public acceptedDate: Date;
  public deniedDate: Date;
  public expirationDate: Date;
  public sentDate: Date;
  public status;

  constructor(obj?: Invitation) {
    this.id = obj && obj.id || '';
    this.acceptedDate = obj && obj.acceptedDate;
    this.deniedDate = obj && obj.deniedDate;
    this.expirationDate = obj && obj.expirationDate;
    this.sentDate = obj && obj.sentDate;
    this.status = obj && obj.status;
  }
}
