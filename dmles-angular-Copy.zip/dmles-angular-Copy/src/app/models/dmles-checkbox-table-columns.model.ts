import {DmlesPanelTableColumns} from './dmles-panel-table-columns.model';

export class DmlesCheckboxTableColumns extends DmlesPanelTableColumns {
  public tooltip: string;
  public iconClass: string;

  constructor(obj?: DmlesCheckboxTableColumns) {
    super(obj);
    this.tooltip = obj && obj.tooltip || '';
    this.iconClass = obj && obj.iconClass || '';
  }
}
