export class Comment {

  public id: string;
  public comment: string;
  public created: Date;
  public firstName: string;
  public lastName: string;
  public userId: string;

  constructor(obj?: Comment) {
    this.id = obj && obj.id || '';
    this.comment = obj && obj.comment || '';
    this.created = obj && obj.created || null;
    this.firstName = obj && obj.firstName || '';
    this.lastName = obj && obj.lastName || '';
    this.userId = obj && obj.userId || '';
  }
}
