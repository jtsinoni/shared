export class RequestFilter {

  public operator: String = '';
  public filterElement: any = null;

  constructor(obj?: RequestFilter) {
    this.operator = obj && obj.operator || '';
    this.filterElement = obj && obj.filterElement || '';
  }
}
