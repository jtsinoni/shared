export class CategoryOption {

  public optionValue: string = '';
  public isSelected: boolean = false;
  public level: number = 0;

  constructor(obj?: CategoryOption) {
    this.optionValue = obj && obj.optionValue || '';
    this.isSelected = obj && obj.isSelected || false;
    this.level = obj && obj.level || 0;
  }
}
