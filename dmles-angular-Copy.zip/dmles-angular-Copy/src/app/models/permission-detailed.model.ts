import {PermEndpoint} from './perm-endpoint.model';
import {PermState} from './perm-state.model';
import {PermElement} from './perm-element.model';

export class PermissionDetailed {

  public id: any = '';
  public name: string = '';
  public description: string = '';
  public functionalArea: string = '';
  public elements: Array<PermElement> = [];
  public states: Array<PermState> = [];
  public endpoints: Array<PermEndpoint> = [];
  public updatedDate: Date = null;
  public updatedBy: string = '';

  constructor(obj?: PermissionDetailed) {
    this.id = obj && obj.id || '';
    this.name = obj && obj.name || '';
    this.description = obj && obj.description || '';
    this.functionalArea = obj && obj.functionalArea || '';
    this.elements = obj && obj.elements || [];
    this.states = obj && obj.states || [];
    this.endpoints = obj && obj.endpoints || [];
    this.updatedDate = obj && obj.updatedDate || null;
    this.updatedBy = obj && obj.updatedBy || '';
  }
}
