export class AppConfig {
    static BT_BASE_URL: string = 'https://localhost:4431/';
    constructor() {}
}
