import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LoginModule} from './login/login.module';
import {LoginService} from './services/login.service';
import {AccessibilityComponent} from './login/accessibility/accessibility.component';
import {LoginComponent} from './login/login.component';
import {RequestPkiDnUpdateComponent} from './login/update-pki-dn/request-pki-dn-update.component';
import {NavigationService} from './services/navigation.service';
import {ChooseProfileComponent} from './login/choose-profile/choose-profile.component';
import {RouteConstants} from './constants/route.constants';

export const appRoutes: Routes = [
  {path: RouteConstants.CHOOSE_PROFILE.route, canActivate: [NavigationService], component: ChooseProfileComponent},
  {
    path: RouteConstants.REQUEST_PKI_DN_UPDATE.route,
    component: RequestPkiDnUpdateComponent,
    canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.REQUEST_PKI_DN_UPDATE.breadcrumb}
  },
  {path: RouteConstants.ACCESSIBILITY.route, component: AccessibilityComponent, canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.ACCESSIBILITY.breadcrumb}},
  {path:  RouteConstants.LOGIN.route, component: LoginComponent, canActivate: [NavigationService],
    data: {breadcrumb: RouteConstants.LOGIN.breadcrumb}},
  {path: RouteConstants.HOME_ROOT.route, loadChildren: 'app/home/home.module#HomeModule', canActivate: [NavigationService]},
  {path: '', redirectTo: RouteConstants.LOGIN.route, pathMatch: 'full'},
  {path: '**', component: LoginComponent},
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes, {enableTracing: false}),
    LoginModule
  ],
  exports: [RouterModule],
  entryComponents: [
    LoginComponent
  ], providers: [
    LoginService
  ]

})
export class AppRouterModule {
}
